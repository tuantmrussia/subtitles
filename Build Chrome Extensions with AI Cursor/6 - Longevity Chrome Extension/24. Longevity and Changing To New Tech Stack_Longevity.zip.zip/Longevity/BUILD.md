# Build Instructions

## Development

1. Install dependencies:
```bash
npm install
```

2. Start development server:
```bash
npm run dev
```

3. For Chrome extension development, you'll need to:
   - Use a Chrome extension that loads from the dev server, OR
   - Build first and load the dist folder

## Production Build

1. Build the extension:
```bash
npm run build
```

2. Load the extension:
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode"
   - Click "Load unpacked"
   - Select the `dist` folder

## Important Notes

- The `dist` folder contains the built extension files
- Make sure `manifest.json` points to files in `dist/` after building
- Data files (`data/*.js`) need to be copied to `dist/` or included in the build
- Icons should be in `dist/icons/` directory

## File Structure After Build

```
dist/
├── popup.html
├── newtab.html
├── breathing.html
├── longevity-history.html
├── background.js
├── assets/
│   ├── *.js (React bundles)
│   └── *.css (styles)
├── data/ (copied from src)
└── icons/ (copied from icons/)
```

