// Gamification data structure - goals, achievements, and XP rewards

// Predefined goals with categories
const DEFAULT_GOALS = [
  {
    id: 'daily-hydration',
    title: 'Daily Hydration',
    description: 'Complete 8 hydration reminders today',
    category: 'Hydration',
    icon: '💧',
    target: 8,
    unit: 'glasses',
    xpReward: 50,
    type: 'daily',
    resetFrequency: 'daily'
  },
  {
    id: 'daily-movement',
    title: 'Movement Master',
    description: 'Complete 10 movement breaks today',
    category: 'Movement',
    icon: '🚶',
    target: 10,
    unit: 'breaks',
    xpReward: 75,
    type: 'daily',
    resetFrequency: 'daily'
  },
  {
    id: 'weekly-meditation',
    title: 'Mindful Week',
    description: 'Meditate 5 times this week',
    category: 'Mindfulness',
    icon: '🧘‍♀️',
    target: 5,
    unit: 'sessions',
    xpReward: 150,
    type: 'weekly',
    resetFrequency: 'weekly'
  },
  {
    id: 'posture-streak',
    title: 'Perfect Posture',
    description: 'Maintain posture checks for 7 days straight',
    category: 'Posture',
    icon: '🧘',
    target: 7,
    unit: 'days',
    xpReward: 200,
    type: 'streak',
    resetFrequency: 'streak'
  },
  {
    id: 'content-reader',
    title: 'Knowledge Seeker',
    description: 'Read 10 longevity articles',
    category: 'Learning',
    icon: '📚',
    target: 10,
    unit: 'articles',
    xpReward: 100,
    type: 'total',
    resetFrequency: 'never'
  },
  {
    id: 'reminder-setter',
    title: 'Organized Life',
    description: 'Set up 5 custom reminders',
    category: 'Organization',
    icon: '⏰',
    target: 5,
    unit: 'reminders',
    xpReward: 75,
    type: 'total',
    resetFrequency: 'never'
  }
];

// Achievement definitions
const ACHIEVEMENTS = [
  {
    id: 'first-steps',
    title: 'First Steps',
    description: 'Complete your first goal',
    icon: '👣',
    rarity: 'common',
    xpReward: 25,
    condition: { type: 'goals_completed', value: 1 }
  },
  {
    id: 'dedicated',
    title: 'Dedicated',
    description: 'Complete 10 goals',
    icon: '⭐',
    rarity: 'common',
    xpReward: 50,
    condition: { type: 'goals_completed', value: 10 }
  },
  {
    id: 'week-warrior',
    title: 'Week Warrior',
    description: 'Maintain a 7-day streak',
    icon: '🔥',
    rarity: 'rare',
    xpReward: 150,
    condition: { type: 'streak', value: 7 }
  },
  {
    id: 'month-master',
    title: 'Month Master',
    description: 'Maintain a 30-day streak',
    icon: '👑',
    rarity: 'epic',
    xpReward: 500,
    condition: { type: 'streak', value: 30 }
  },
  {
    id: 'speed-reader',
    title: 'Speed Reader',
    description: 'Read 50 articles',
    icon: '📖',
    rarity: 'rare',
    xpReward: 200,
    condition: { type: 'articles_read', value: 50 }
  },
  {
    id: 'hydration-hero',
    title: 'Hydration Hero',
    description: 'Complete 100 hydration reminders',
    icon: '💧',
    rarity: 'rare',
    xpReward: 150,
    condition: { type: 'hydration_completed', value: 100 }
  },
  {
    id: 'level-up',
    title: 'Level Up!',
    description: 'Reach level 5',
    icon: '🎯',
    rarity: 'rare',
    xpReward: 100,
    condition: { type: 'level', value: 5 }
  },
  {
    id: 'veteran',
    title: 'Veteran',
    description: 'Reach level 10',
    icon: '🏆',
    rarity: 'epic',
    xpReward: 500,
    condition: { type: 'level', value: 10 }
  },
  {
    id: 'collector',
    title: 'Collector',
    description: 'Unlock 10 achievements',
    icon: '🏅',
    rarity: 'epic',
    xpReward: 300,
    condition: { type: 'achievements_unlocked', value: 10 }
  },
  {
    id: 'legend',
    title: 'Legend',
    description: 'Maintain a 100-day streak',
    icon: '🌟',
    rarity: 'legendary',
    xpReward: 1000,
    condition: { type: 'streak', value: 100 }
  }
];

// XP required for each level
function getXPForLevel(level) {
  // Exponential growth: 100 * level^1.5
  return Math.floor(100 * Math.pow(level, 1.5));
}

// Calculate total XP needed for a level
function getTotalXPForLevel(level) {
  let total = 0;
  for (let i = 1; i <= level; i++) {
    total += getXPForLevel(i);
  }
  return total;
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { DEFAULT_GOALS, ACHIEVEMENTS, getXPForLevel, getTotalXPForLevel };
}


