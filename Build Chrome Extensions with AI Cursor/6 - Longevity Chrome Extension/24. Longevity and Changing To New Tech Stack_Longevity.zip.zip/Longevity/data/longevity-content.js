// Pre-populated longevity information with scientific references
const LONGEVITY_CONTENT = [
  {
    id: 'if-autophagy',
    title: 'Intermittent Fasting & Autophagy',
    description: 'Intermittent fasting triggers autophagy, a cellular cleaning process that removes damaged components and may contribute to longevity.',
    category: 'Nutrition',
    references: [
      {
        text: 'Autophagy and longevity: molecular mechanisms',
        url: 'https://www.nature.com/articles/s41580-018-0003-4'
      },
      {
        text: 'Fasting triggers autophagy in various tissues',
        url: 'https://www.cell.com/cell-metabolism/fulltext/S1550-4131(17)30612-3'
      }
    ],
    tags: ['fasting', 'autophagy', 'cellular repair']
  },
  {
    id: 'sleep-circadian',
    title: 'Sleep & Circadian Rhythm Optimization',
    description: 'Maintaining a consistent sleep schedule aligned with your circadian rhythm improves sleep quality, cognitive function, and may reduce age-related decline.',
    category: 'Sleep',
    references: [
      {
        text: 'Circadian rhythms and aging',
        url: 'https://www.nature.com/articles/s41514-017-0005-0'
      },
      {
        text: 'Sleep duration and mortality',
        url: 'https://pubmed.ncbi.nlm.nih.gov/29453625/'
      }
    ],
    tags: ['sleep', 'circadian rhythm', 'cognitive health']
  },
  {
    id: 'hiit-cardio',
    title: 'HIIT & Zone 2 Cardio',
    description: 'Combining high-intensity interval training with steady-state zone 2 cardio improves mitochondrial function, cardiovascular health, and metabolic efficiency.',
    category: 'Exercise',
    references: [
      {
        text: 'HIIT improves mitochondrial capacity',
        url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4761413/'
      },
      {
        text: 'Zone 2 training and longevity',
        url: 'https://pubmed.ncbi.nlm.nih.gov/32481252/'
      }
    ],
    tags: ['exercise', 'HIIT', 'cardiovascular', 'mitochondria']
  },
  {
    id: 'strength-training',
    title: 'Strength Training for Longevity',
    description: 'Resistance training preserves muscle mass, bone density, and metabolic health as we age, reducing frailty and maintaining independence.',
    category: 'Exercise',
    references: [
      {
        text: 'Resistance training and aging',
        url: 'https://pubmed.ncbi.nlm.nih.gov/25353145/'
      },
      {
        text: 'Muscle mass and mortality',
        url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5447324/'
      }
    ],
    tags: ['strength training', 'muscle mass', 'bone density']
  },
  {
    id: 'blue-zones-nutrition',
    title: 'Blue Zones Nutrition Patterns',
    description: 'Populations in Blue Zones consume plant-rich diets high in legumes, whole grains, and vegetables, with minimal processed foods.',
    category: 'Nutrition',
    references: [
      {
        text: 'Blue Zones and longevity',
        url: 'https://www.bluezones.com/'
      },
      {
        text: 'Plant-based diets and longevity',
        url: 'https://pubmed.ncbi.nlm.nih.gov/31329220/'
      }
    ],
    tags: ['nutrition', 'plant-based', 'blue zones']
  },
  {
    id: 'polyphenols',
    title: 'Polyphenols & Longevity',
    description: 'Polyphenols found in berries, dark chocolate, green tea, and olive oil have antioxidant and anti-inflammatory properties linked to longevity.',
    category: 'Nutrition',
    references: [
      {
        text: 'Polyphenols and aging',
        url: 'https://pubmed.ncbi.nlm.nih.gov/30092812/'
      },
      {
        text: 'Mediterranean diet polyphenols',
        url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6539817/'
      }
    ],
    tags: ['polyphenols', 'antioxidants', 'inflammation']
  },
  {
    id: 'omega3',
    title: 'Omega-3 Fatty Acids',
    description: 'Omega-3 fatty acids (EPA/DHA) support brain health, reduce inflammation, and may contribute to cardiovascular longevity.',
    category: 'Nutrition',
    references: [
      {
        text: 'Omega-3 and brain aging',
        url: 'https://pubmed.ncbi.nlm.nih.gov/27473895/'
      },
      {
        text: 'Omega-3 and cardiovascular health',
        url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3875260/'
      }
    ],
    tags: ['omega-3', 'brain health', 'cardiovascular']
  },
  {
    id: 'meditation-stress',
    title: 'Meditation & Stress Reduction',
    description: 'Regular meditation practice reduces cortisol levels, improves telomere length, and may slow cellular aging through stress reduction.',
    category: 'Stress Management',
    references: [
      {
        text: 'Meditation and telomere length',
        url: 'https://pubmed.ncbi.nlm.nih.gov/23479355/'
      },
      {
        text: 'Mindfulness and aging',
        url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6437807/'
      }
    ],
    tags: ['meditation', 'stress', 'telomeres']
  },
  {
    id: 'breathing-exercises',
    title: 'Breathing Exercises & HRV',
    description: 'Controlled breathing exercises improve heart rate variability (HRV), a marker of autonomic nervous system health and longevity.',
    category: 'Stress Management',
    references: [
      {
        text: 'HRV and longevity',
        url: 'https://pubmed.ncbi.nlm.nih.gov/28980373/'
      },
      {
        text: 'Breathing exercises and autonomic function',
        url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6137615/'
      }
    ],
    tags: ['breathing', 'HRV', 'autonomic nervous system']
  },
  {
    id: 'cold-exposure',
    title: 'Cold Exposure & Brown Fat',
    description: 'Regular cold exposure activates brown adipose tissue, improves metabolic health, and may enhance longevity through hormetic stress.',
    category: 'Environmental',
    references: [
      {
        text: 'Cold exposure and brown fat',
        url: 'https://pubmed.ncbi.nlm.nih.gov/20029371/'
      },
      {
        text: 'Hormesis and longevity',
        url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4684127/'
      }
    ],
    tags: ['cold exposure', 'brown fat', 'hormesis']
  },
  {
    id: 'heat-exposure',
    title: 'Heat Exposure & Heat Shock Proteins',
    description: 'Sauna use and heat exposure activate heat shock proteins, which help maintain protein folding and cellular function.',
    category: 'Environmental',
    references: [
      {
        text: 'Sauna bathing and mortality',
        url: 'https://pubmed.ncbi.nlm.nih.gov/25705824/'
      },
      {
        text: 'Heat shock proteins and aging',
        url: 'https://pubmed.ncbi.nlm.nih.gov/29724754/'
      }
    ],
    tags: ['sauna', 'heat shock proteins', 'cellular function']
  },
  {
    id: 'social-connections',
    title: 'Social Connections & Longevity',
    description: 'Strong social relationships are associated with longer lifespans, reduced stress, and better mental health outcomes.',
    category: 'Lifestyle',
    references: [
      {
        text: 'Social relationships and mortality',
        url: 'https://pubmed.ncbi.nlm.nih.gov/20668659/'
      },
      {
        text: 'Loneliness and health outcomes',
        url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6106764/'
      }
    ],
    tags: ['social', 'relationships', 'mental health']
  }
];

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
  module.exports = LONGEVITY_CONTENT;
}


