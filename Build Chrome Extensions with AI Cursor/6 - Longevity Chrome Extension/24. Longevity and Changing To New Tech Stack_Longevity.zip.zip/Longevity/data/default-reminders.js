// Pre-populated reminder templates
const DEFAULT_REMINDERS = [
  {
    id: 'hydration',
    title: 'Drink Water',
    description: 'Stay hydrated for optimal cellular function and cognitive performance',
    frequency: 120, // 2 hours
    enabled: true,
    custom: false,
    icon: '💧',
    category: 'Hydration'
  },
  {
    id: 'posture',
    title: 'Posture Check',
    description: 'Maintain proper posture to prevent musculoskeletal issues',
    frequency: 60, // 1 hour
    enabled: true,
    custom: false,
    icon: '🧘',
    category: 'Posture'
  },
  {
    id: 'movement',
    title: 'Movement Break',
    description: 'Take a short walk or stretch to break up sedentary time',
    frequency: 30, // 30 minutes
    enabled: true,
    custom: false,
    icon: '🚶',
    category: 'Movement'
  },
  {
    id: 'meditation',
    title: 'Meditation',
    description: 'Practice mindfulness meditation for stress reduction',
    frequency: 1440, // minutes (daily - 24 hours) - keep default for testing
    enabled: false, // Disabled by default, user can set time
    custom: false,
    icon: '🧘‍♀️',
    category: 'Mindfulness',
    timeOfDay: null // User can set specific time
  },
  {
    id: 'if-window-start',
    title: 'Intermittent Fasting Window Start',
    description: 'Begin your eating window',
    frequency: 1440, // daily
    enabled: false,
    custom: false,
    icon: '🍽️',
    category: 'Nutrition',
    timeOfDay: null // User sets their IF schedule
  },
  {
    id: 'if-window-end',
    title: 'Intermittent Fasting Window End',
    description: 'End your eating window',
    frequency: 1440, // daily
    enabled: false,
    custom: false,
    icon: '⏰',
    category: 'Nutrition',
    timeOfDay: null
  },
  {
    id: 'sleep-prep',
    title: 'Sleep Preparation',
    description: 'Begin winding down 90 minutes before bedtime',
    frequency: 1440, // daily
    enabled: false,
    custom: false,
    icon: '🌙',
    category: 'Sleep',
    timeOfDay: null // User sets their bedtime
  },
  {
    id: 'supplements-morning',
    title: 'Morning Supplements',
    description: 'Take your morning supplements',
    frequency: 1440, // daily
    enabled: false,
    custom: false,
    icon: '💊',
    category: 'Supplements',
    timeOfDay: null
  },
  {
    id: 'supplements-evening',
    title: 'Evening Supplements',
    description: 'Take your evening supplements',
    frequency: 1440, // daily
    enabled: false,
    custom: false,
    icon: '💊',
    category: 'Supplements',
    timeOfDay: null
  },
  {
    id: 'deep-breathing',
    title: 'Deep Breathing Exercise',
    description: 'Practice 5 minutes of deep breathing for HRV improvement',
    frequency: 180, // 3 hours
    enabled: false,
    custom: false,
    icon: '🫁',
    category: 'Breathing'
  }
];

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
  module.exports = DEFAULT_REMINDERS;
}


