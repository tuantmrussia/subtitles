# Quick Fix for Manifest Error

## The Problem
Chrome shows "Manifest file is missing or unreadable" when loading the extension.

## Solution

The manifest.json has been created in the `dist` folder with correct paths. Follow these steps:

### Step 1: Verify Files Exist
Make sure these files exist in the `dist` folder:
- ✅ `dist/manifest.json` (should exist now)
- ✅ `dist/popup.html`
- ✅ `dist/background.js`
- ✅ `dist/icons/` folder with icon files

### Step 2: Reload Extension
1. Go to `chrome://extensions/`
2. Find your extension
3. Click the **reload** button (circular arrow icon)
4. OR remove and re-add the extension:
   - Click "Remove"
   - Click "Load unpacked" again
   - Select the `dist` folder

### Step 3: Check for Errors
1. Click "Details" on your extension
2. Look for any error messages
3. Check the "Errors" section

## If Still Not Working

### Option 1: Manual Verification
1. Open `dist/manifest.json` in a text editor
2. Verify it's valid JSON (no syntax errors)
3. Check that paths don't have `dist/` prefix:
   - ✅ `"service_worker": "background.js"` (correct)
   - ❌ `"service_worker": "dist/background.js"` (wrong)

### Option 2: Rebuild
```bash
npm run build
```

This will:
- Build all React components
- Copy manifest.json to dist/ with correct paths
- Copy data files
- Copy icons

### Option 3: Check Chrome Console
1. Open Chrome DevTools (F12)
2. Go to Console tab
3. Look for manifest-related errors

## Current Manifest Structure

The manifest.json in `dist/` should have:
- `service_worker: "background.js"` (no dist/ prefix)
- `default_popup: "popup.html"` (no dist/ prefix)
- `options_page: "newtab.html"` (no dist/ prefix)
- Icon paths: `"icons/icon16.png"` (relative to dist/)

## Still Having Issues?

1. Make sure you're selecting the **`dist`** folder, not the root folder
2. The folder path should end with `...\Longevity\dist`
3. Try closing and reopening Chrome
4. Check Windows file permissions on the dist folder

