# Longevity Chrome Extension

A Chrome extension that provides scientific-backed longevity information, customizable reminders, and browser history analytics.

## Features

- **Longevity Information**: Pre-populated scientific content with references
- **Customizable Reminders**: Pre-populated and custom reminders with adjustable frequency
- **Browser History Analytics**: Visualize your browsing patterns with Chart.js
- **Breathing Exercises**: Guided 4-7-8 breathing exercise
- **RSS News Feed**: Latest longevity news from Lifespan.io
- **Modern React UI**: Built with React, Chart.js, and Tone.js

## Development Setup

### Prerequisites

- Node.js 18+ and npm

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start development server:
```bash
npm run dev
```

3. Build for production:
```bash
npm run build
```

4. Load the extension:
   - Open Chrome and navigate to `chrome://extensions/`
   - Enable "Developer mode"
   - Click "Load unpacked"
   - Select the `dist` folder (after building) or use a development extension loader

## Project Structure

```
Longevity/
├── src/
│   ├── components/          # Shared React components
│   ├── hooks/               # Custom React hooks
│   ├── pages/               # Page-specific components
│   │   ├── popup/           # Popup interface
│   │   ├── newtab/          # New tab dashboard
│   │   ├── breathing/       # Breathing exercise
│   │   └── history/        # History analytics
│   ├── utils/               # Utilities
│   │   └── audio/           # Tone.js audio manager
│   ├── styles/              # Global styles
│   └── background/          # Background script
├── dist/                    # Built files (generated)
├── data/                    # Data files
├── icons/                   # Extension icons
├── vite.config.js          # Vite configuration
└── manifest.json           # Extension manifest
```

## Technologies

- **React 18**: UI framework
- **Vite**: Build tool
- **Chart.js**: Data visualization
- **Tone.js**: Audio processing
- **Chrome Extensions API**: Extension functionality

## Building

The extension uses Vite to build React components. After running `npm run build`, the `dist` folder will contain all the built files ready to be loaded as a Chrome extension.

## Notes

- Tone.js requires a DOM context and cannot run in service workers. Audio is handled via message passing to page contexts.
- Browser history visualization requires the `history` permission.
- RSS feed fetching requires `host_permissions` for `https://*/*`.
