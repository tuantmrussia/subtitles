# Icons Directory

This directory should contain the following icon files:

- `icon16.png` - 16x16 pixels (for toolbar)
- `icon48.png` - 48x48 pixels (for extension management page)
- `icon128.png` - 128x128 pixels (for Chrome Web Store)

## Creating Icons

You can create simple icons using:
1. Online icon generators (e.g., favicon.io, iconifier.net)
2. Image editing software (Photoshop, GIMP, Figma)
3. SVG to PNG converters

## Suggested Design

- Use a longevity-themed symbol (🌱 plant, ⏰ clock, 💚 heart)
- Keep it simple and recognizable at small sizes
- Use colors that match the extension theme (purple gradient: #667eea to #764ba2)

## Quick Placeholder Solution

For testing, you can create simple colored squares:
- Create 16x16, 48x48, and 128x128 pixel images
- Fill with a solid color (e.g., #667eea)
- Save as PNG files with the names above


