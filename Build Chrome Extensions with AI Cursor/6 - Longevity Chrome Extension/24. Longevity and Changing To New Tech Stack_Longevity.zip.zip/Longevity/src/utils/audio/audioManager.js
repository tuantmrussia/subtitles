import * as Tone from 'tone';

class AudioManager {
  constructor() {
    this.isInitialized = false;
    this.currentAmbientSound = null;
    this.volume = 0.5;
  }

  async initialize() {
    if (this.isInitialized) return;
    
    try {
      await Tone.start();
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize Tone.js:', error);
    }
  }

  async playNotificationSound(type = 'beep') {
    await this.initialize();
    
    const sounds = {
      beep: () => this.playBeep(),
      chime: () => this.playChime(),
      bell: () => this.playBell()
    };

    if (sounds[type]) {
      sounds[type]();
    } else {
      this.playBeep();
    }
  }

  playBeep() {
    const synth = new Tone.Synth().toDestination();
    synth.volume.value = -10;
    
    synth.triggerAttackRelease('C5', '8n');
    setTimeout(() => {
      synth.triggerAttackRelease('C5', '8n');
    }, 250);
  }

  playChime() {
    const synth = new Tone.Synth({
      oscillator: { type: 'sine' },
      envelope: { attack: 0.01, decay: 0.1, sustain: 0.3, release: 0.3 }
    }).toDestination();
    
    synth.volume.value = -10;
    synth.triggerAttackRelease('C5', '4n');
    
    setTimeout(() => {
      synth.triggerRelease();
      const synth2 = new Tone.Synth({
        oscillator: { type: 'sine' },
        envelope: { attack: 0.01, decay: 0.1, sustain: 0.3, release: 0.3 }
      }).toDestination();
      synth2.volume.value = -10;
      synth2.triggerAttackRelease('E5', '4n');
    }, 200);
  }

  playBell() {
    const synth = new Tone.Synth({
      oscillator: { type: 'sine' },
      envelope: { attack: 0.01, decay: 0.5, sustain: 0, release: 0.5 }
    }).toDestination();
    
    synth.volume.value = -5;
    synth.triggerAttackRelease('A5', '2n');
  }

  async playAmbientSound(type, volume = 0.5) {
    await this.initialize();
    
    if (this.currentAmbientSound) {
      this.currentAmbientSound.stop();
    }

    this.volume = volume;
    const sounds = {
      rain: () => this.playRain(),
      ocean: () => this.playOcean(),
      forest: () => this.playForest(),
      fireplace: () => this.playFireplace(),
      'white-noise': () => this.playWhiteNoise(),
      wind: () => this.playWind(),
      cafe: () => this.playCafe(),
      thunder: () => this.playThunder()
    };

    if (sounds[type]) {
      this.currentAmbientSound = sounds[type]();
    }
  }

  playRain() {
    const noise = new Tone.Noise('pink').toDestination();
    const filter = new Tone.Filter({
      frequency: 1000,
      type: 'lowpass',
      Q: 1
    });
    const volume = new Tone.Volume(this.volume * 20 - 20).toDestination();
    
    noise.connect(filter);
    filter.connect(volume);
    noise.start();
    
    return {
      stop: () => {
        noise.stop();
        noise.dispose();
        filter.dispose();
        volume.dispose();
      },
      setVolume: (vol) => {
        volume.volume.value = vol * 20 - 20;
      }
    };
  }

  playOcean() {
    const noise = new Tone.Noise('brown').toDestination();
    const filter = new Tone.Filter({
      frequency: 800,
      type: 'bandpass',
      Q: 2
    });
    const volume = new Tone.Volume(this.volume * 20 - 20).toDestination();
    
    noise.connect(filter);
    filter.connect(volume);
    noise.start();
    
    return {
      stop: () => {
        noise.stop();
        noise.dispose();
        filter.dispose();
        volume.dispose();
      },
      setVolume: (vol) => {
        volume.volume.value = vol * 20 - 20;
      }
    };
  }

  playForest() {
    const noise = new Tone.Noise('pink').toDestination();
    const filter = new Tone.Filter({
      frequency: 2000,
      type: 'lowpass',
      Q: 1
    });
    const volume = new Tone.Volume(this.volume * 20 - 20).toDestination();
    
    noise.connect(filter);
    filter.connect(volume);
    noise.start();
    
    return {
      stop: () => {
        noise.stop();
        noise.dispose();
        filter.dispose();
        volume.dispose();
      },
      setVolume: (vol) => {
        volume.volume.value = vol * 20 - 20;
      }
    };
  }

  playFireplace() {
    const noise = new Tone.Noise('pink').toDestination();
    const filter = new Tone.Filter({
      frequency: 500,
      type: 'lowpass',
      Q: 3
    });
    const volume = new Tone.Volume(this.volume * 20 - 20).toDestination();
    
    noise.connect(filter);
    filter.connect(volume);
    noise.start();
    
    return {
      stop: () => {
        noise.stop();
        noise.dispose();
        filter.dispose();
        volume.dispose();
      },
      setVolume: (vol) => {
        volume.volume.value = vol * 20 - 20;
      }
    };
  }

  playWhiteNoise() {
    const noise = new Tone.Noise('white').toDestination();
    const volume = new Tone.Volume(this.volume * 20 - 20).toDestination();
    
    noise.connect(volume);
    noise.start();
    
    return {
      stop: () => {
        noise.stop();
        noise.dispose();
        volume.dispose();
      },
      setVolume: (vol) => {
        volume.volume.value = vol * 20 - 20;
      }
    };
  }

  playWind() {
    const noise = new Tone.Noise('pink').toDestination();
    const filter = new Tone.Filter({
      frequency: 300,
      type: 'highpass',
      Q: 1
    });
    const volume = new Tone.Volume(this.volume * 20 - 20).toDestination();
    
    noise.connect(filter);
    filter.connect(volume);
    noise.start();
    
    return {
      stop: () => {
        noise.stop();
        noise.dispose();
        filter.dispose();
        volume.dispose();
      },
      setVolume: (vol) => {
        volume.volume.value = vol * 20 - 20;
      }
    };
  }

  playCafe() {
    const noise = new Tone.Noise('pink').toDestination();
    const filter = new Tone.Filter({
      frequency: 1500,
      type: 'bandpass',
      Q: 2
    });
    const volume = new Tone.Volume(this.volume * 20 - 20).toDestination();
    
    noise.connect(filter);
    filter.connect(volume);
    noise.start();
    
    return {
      stop: () => {
        noise.stop();
        noise.dispose();
        filter.dispose();
        volume.dispose();
      },
      setVolume: (vol) => {
        volume.volume.value = vol * 20 - 20;
      }
    };
  }

  playThunder() {
    const noise = new Tone.Noise('brown').toDestination();
    const filter = new Tone.Filter({
      frequency: 200,
      type: 'lowpass',
      Q: 5
    });
    const volume = new Tone.Volume(this.volume * 20 - 15).toDestination();
    
    noise.connect(filter);
    filter.connect(volume);
    noise.start();
    
    return {
      stop: () => {
        noise.stop();
        noise.dispose();
        filter.dispose();
        volume.dispose();
      },
      setVolume: (vol) => {
        volume.volume.value = vol * 20 - 15;
      }
    };
  }

  stopAmbientSound() {
    if (this.currentAmbientSound) {
      this.currentAmbientSound.stop();
      this.currentAmbientSound = null;
    }
  }

  setVolume(volume) {
    this.volume = volume;
    if (this.currentAmbientSound && this.currentAmbientSound.setVolume) {
      this.currentAmbientSound.setVolume(volume);
    }
  }
}

export const audioManager = new AudioManager();

