// Audio listener for Chrome extension messages
// This allows the background script to trigger audio in page contexts
import { audioManager } from './audioManager';

// Listen for messages from background script to play notification sounds
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'playNotificationSound') {
    audioManager.playNotificationSound(request.soundType || 'beep')
      .then(() => {
        sendResponse({ success: true });
      })
      .catch((error) => {
        console.error('Error playing notification sound:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // Keep channel open for async response
  }
});

