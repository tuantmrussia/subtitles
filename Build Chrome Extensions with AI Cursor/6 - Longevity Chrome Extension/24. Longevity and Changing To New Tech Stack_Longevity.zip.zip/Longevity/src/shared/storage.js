// Copy of storage.js utilities for use in React components
// This ensures compatibility with existing code

class StorageManager {
  static async initialize() {
    const data = await chrome.storage.local.get([
      'favorites',
      'userContent',
      'reminders',
      'settings',
      'initialized'
    ]);

    if (!data.initialized) {
      const defaultReminders = await this.loadDefaultReminders();
      await chrome.storage.local.set({
        favorites: [],
        userContent: [],
        reminders: defaultReminders,
        settings: {
          notificationsEnabled: true,
          badgeEnabled: true,
          theme: 'light',
          notificationSound: 'beep'
        },
        initialized: true
      });
    }

    return data;
  }

  static async loadDefaultReminders() {
    return [];
  }

  static async getFavorites() {
    const data = await chrome.storage.local.get('favorites');
    return data.favorites || [];
  }

  static async addFavorite(id) {
    const favorites = await this.getFavorites();
    if (!favorites.includes(id)) {
      favorites.push(id);
      await chrome.storage.local.set({ favorites });
    }
  }

  static async removeFavorite(id) {
    const favorites = await this.getFavorites();
    const filtered = favorites.filter(fav => fav !== id);
    await chrome.storage.local.set({ favorites: filtered });
  }

  static async isFavorite(id) {
    const favorites = await this.getFavorites();
    return favorites.includes(id);
  }

  static async getUserContent() {
    const data = await chrome.storage.local.get('userContent');
    return data.userContent || [];
  }

  static async addUserContent(content) {
    const userContent = await this.getUserContent();
    const newContent = {
      id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      title: content.title,
      link: content.link || '',
      description: content.description || '',
      timestamp: Date.now(),
      category: content.category || 'Custom',
      tags: content.tags || []
    };
    userContent.push(newContent);
    await chrome.storage.local.set({ userContent });
    return newContent;
  }

  static async getReminders() {
    const data = await chrome.storage.local.get('reminders');
    return data.reminders || [];
  }

  static async updateReminder(reminderId, updates) {
    const reminders = await this.getReminders();
    const index = reminders.findIndex(r => r.id === reminderId);
    if (index !== -1) {
      reminders[index] = { ...reminders[index], ...updates };
      await chrome.storage.local.set({ reminders });
      return reminders[index];
    }
    return null;
  }

  static async addCustomReminder(reminder) {
    const reminders = await this.getReminders();
    const newReminder = {
      id: `custom-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      title: reminder.title,
      description: reminder.description || '',
      frequency: reminder.frequency || 60,
      enabled: reminder.enabled !== undefined ? reminder.enabled : true,
      custom: true,
      icon: reminder.icon || '⏰',
      category: reminder.category || 'Custom',
      timeOfDay: reminder.timeOfDay || null,
      lastTriggered: null
    };
    reminders.push(newReminder);
    await chrome.storage.local.set({ reminders });
    return newReminder;
  }

  static async getSettings() {
    const data = await chrome.storage.local.get('settings');
    return data.settings || {
      notificationsEnabled: true,
      badgeEnabled: true,
      theme: 'light',
      notificationSound: 'beep'
    };
  }

  static async updateSettings(updates) {
    const settings = await this.getSettings();
    const newSettings = { ...settings, ...updates };
    await chrome.storage.local.set({ settings: newSettings });
    return newSettings;
  }

  static async getNoiseSettings() {
    const data = await chrome.storage.local.get('noiseSettings');
    return data.noiseSettings || {
      volume: 0.5,
      playing: null
    };
  }

  static async updateNoiseSettings(updates) {
    const settings = await this.getNoiseSettings();
    const newSettings = { ...settings, ...updates };
    await chrome.storage.local.set({ noiseSettings: newSettings });
    return newSettings;
  }

  static async getRSSArticles() {
    const data = await chrome.storage.local.get('rssArticles');
    return data.rssArticles || [];
  }
}

// Make available globally for compatibility
if (typeof window !== 'undefined') {
  window.StorageManager = StorageManager;
}

export default StorageManager;

