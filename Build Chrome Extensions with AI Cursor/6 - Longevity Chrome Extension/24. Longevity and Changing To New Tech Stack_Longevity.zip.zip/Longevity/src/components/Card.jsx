import React from 'react';
import './Card.css';

export const Card = ({ 
  children, 
  className = '',
  variant = 'default',
  onClick,
  ...props 
}) => {
  const classes = `card card-${variant} ${className}`;
  
  return (
    <div 
      className={classes}
      onClick={onClick}
      {...props}
    >
      {children}
    </div>
  );
};

