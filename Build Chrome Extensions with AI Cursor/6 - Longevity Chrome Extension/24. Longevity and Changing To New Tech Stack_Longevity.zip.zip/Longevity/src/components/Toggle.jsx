import React from 'react';
import './Toggle.css';

export const Toggle = ({ 
  checked, 
  onChange, 
  label,
  disabled = false,
  className = '' 
}) => {
  return (
    <label className={`toggle-switch ${className} ${disabled ? 'disabled' : ''}`}>
      {label && <span className="toggle-label">{label}</span>}
      <input
        type="checkbox"
        checked={checked}
        onChange={onChange}
        disabled={disabled}
      />
      <span className="toggle-slider"></span>
    </label>
  );
};

