import React from 'react';
import { Card } from './Card';
import './ChartCard.css';

export const ChartCard = ({ title, children, className = '' }) => {
  return (
    <Card className={`chart-card ${className}`}>
      {title && <h3 className="chart-title">{title}</h3>}
      <div className="chart-content">
        {children}
      </div>
    </Card>
  );
};

