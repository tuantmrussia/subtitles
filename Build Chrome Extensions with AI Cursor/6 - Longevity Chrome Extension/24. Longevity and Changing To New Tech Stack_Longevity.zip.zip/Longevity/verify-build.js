// Quick verification script for dist folder
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const distDir = path.resolve(__dirname, 'dist');

console.log('Verifying dist folder...\n');

const requiredFiles = [
  'manifest.json',
  'popup.html',
  'newtab.html',
  'breathing.html',
  'longevity-history.html',
  'background.js',
  'icons/icon16.png',
  'icons/icon48.png',
  'icons/icon128.png',
  'data/longevity-content.js',
  'data/default-reminders.js'
];

let allGood = true;

requiredFiles.forEach(file => {
  const filePath = path.join(distDir, file);
  if (fs.existsSync(filePath)) {
    console.log(`✓ ${file}`);
  } else {
    console.log(`✗ ${file} - MISSING!`);
    allGood = false;
  }
});

// Verify manifest.json content
const manifestPath = path.join(distDir, 'manifest.json');
if (fs.existsSync(manifestPath)) {
  try {
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    console.log('\n✓ manifest.json is valid JSON');
    
    // Check paths
    const checks = [
      { path: manifest.background?.service_worker, shouldNotContain: 'dist/', name: 'service_worker' },
      { path: manifest.action?.default_popup, shouldNotContain: 'dist/', name: 'default_popup' },
      { path: manifest.options_page, shouldNotContain: 'dist/', name: 'options_page' }
    ];
    
    checks.forEach(check => {
      if (check.path && check.path.includes(check.shouldNotContain)) {
        console.log(`✗ ${check.name} contains 'dist/' prefix - should be fixed`);
        allGood = false;
      } else if (check.path) {
        console.log(`✓ ${check.name}: "${check.path}"`);
      }
    });
  } catch (e) {
    console.log(`✗ manifest.json has JSON syntax error: ${e.message}`);
    allGood = false;
  }
}

console.log('\n' + '='.repeat(50));
if (allGood) {
  console.log('✓ All checks passed! Extension should load correctly.');
  console.log('\nTo load: Go to chrome://extensions/, enable Developer mode,');
  console.log('click "Load unpacked", and select the "dist" folder.');
} else {
  console.log('✗ Some issues found. Please fix them before loading.');
}
console.log('='.repeat(50));

