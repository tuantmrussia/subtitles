const ENGINES = {
  google: {
    name: 'Google',
    buildUrl: (q) => `https://www.google.com/search?q=${q}`,
  },
  bing: {
    name: 'Bing',
    buildUrl: (q) => `https://www.bing.com/search?q=${q}`,
  },
  yandex: {
    name: 'Yandex',
    buildUrl: (q) => `https://yandex.ru/search/?text=${q}`,
  },
  yahoo: {
    name: 'Yahoo!',
    buildUrl: (q) => `https://search.yahoo.com/search?p=${q}`,
  },
  duckduckgo: {
    name: 'DuckDuckGo',
    buildUrl: (q) => `https://duckduckgo.com/?q=${q}`,
  },
  baidu: {
    name: 'Baidu',
    buildUrl: (q) => `https://www.baidu.com/s?wd=${q}`,
  },
  naver: {
    name: 'Naver',
    buildUrl: (q) => `https://search.naver.com/search.naver?query=${q}`,
  },
  ecosia: {
    name: 'Ecosia',
    buildUrl: (q) => `https://www.ecosia.org/search?q=${q}`,
  },
  aol: {
    name: 'AOL',
    buildUrl: (q) => `https://search.aol.com/aol/search?q=${q}`,
  },
  seznam: {
    name: 'Seznam',
    buildUrl: (q) => `https://search.seznam.cz/?q=${q}`,
  },
};

// AI Search Engines
const AI_ENGINES = {
  andisearch: {
    name: 'Andi Search',
    buildUrl: (q) => `https://andisearch.com/`,
  },
  sigmabrowser: {
    name: 'Sigma Browser',
    buildUrl: (q) => `https://app.sigmabrowser.com/chat`,
  },
  chatgpt: {
    name: 'ChatGPT',
    buildUrl: (q) => `https://chatgpt.com/`,
  },
  claude: {
    name: 'Claude',
    buildUrl: (q) => `https://claude.ai/new`,
  },
  consensus: {
    name: 'Consensus',
    buildUrl: (q) => `https://consensus.app/`,
  },
  copilot: {
    name: 'Microsoft Copilot',
    buildUrl: (q) => `https://copilot.microsoft.com/`,
  },
  felo: {
    name: 'Felo',
    buildUrl: (q) => `https://felo.ai/search`,
  },
  gemini: {
    name: 'Google Gemini',
    buildUrl: (q) => `https://gemini.google.com/app`,
  },
  komo: {
    name: 'Komo',
    buildUrl: (q) => `https://komo.ai/`,
  },
  thinkany: {
    name: 'ThinkAny',
    buildUrl: (q) => `https://thinkany.ai/`,
  },
  genspark: {
    name: 'GenSpark',
    buildUrl: (q) => `https://www.genspark.ai/`,
  },
  perplexity: {
    name: 'Perplexity',
    buildUrl: (q) => `https://www.perplexity.ai/`,
  },
  phind: {
    name: 'Phind',
    buildUrl: (q) => `https://www.phind.com/`,
  },
};

// Country-specific engines
const COUNTRY_ENGINES = {
  '123khoj_india': {
    'entireindia_com_1': {
      name: 'Entireindia',
      buildUrl: (q) => `https://www.entireindia.com/yellowpages/india.asp?s=${q}&c=0&xPg=1&xGr=0&w=1`,
    },
    'indiabook_com_3': {
      name: 'Indiabook',
      buildUrl: (q) => `https://www.indiabook.com/cgi-bin/links/search.cgi?query=${q}&x=31&y=8`,
    },
    'indiacatalog_com_4': {
      name: 'Indiacatalog',
      buildUrl: (q) => `http://www.indiacatalog.com/?q=${q}`,
    },
  },
  '1stekeuze_zoekmachine_nl_nethe': {
    'startpage_com_1': {
      name: 'Startpage',
      buildUrl: (q) => `https://www.startpage.com/do/search?q=${q}`,
    },
    'startgoogle_startpagina_nl_0': {
      name: 'Startpagina',
      buildUrl: (q) => `https://startgoogle.startpagina.nl/?origin=homepage&query=${q}&ts=ts2&tab=internet`,
    },
    'vinden_nl_2': {
      name: 'Vinden',
      buildUrl: (q) => `https://www.vinden.nl/search?q=${q}`,
    },
  },
  '2gogo_unite': {
    '1stdirectory_com_2': {
      name: '1stdirectory',
      buildUrl: (q) => `http://www.1stdirectory.com/?q=${q}`,
    },
    '1stdirectory_co_uk_3': {
      name: '1stdirectory UK',
      buildUrl: (q) => `https://1stdirectory.co.uk/search/`,
    },
    'aol_co_uk_0': {
      name: 'AOL UK',
      buildUrl: (q) => `http://www.aol.co.uk/?q=${q}`,
    },
    'search_aol_co_uk_1': {
      name: 'AOL UK Search',
      buildUrl: (q) => `https://search.aol.co.uk/aol/search?q=${q}&s_it=aoluk-homePage50&s_chn=hp&rp=&s_qt=ac`,
    },
    'the-internet-pages_co_uk_7': {
      name: 'Internet Pages UK Search',
      buildUrl: (q) => `https://the-internet-pages.co.uk/search?q=${q}&x=14&y=13`,
    },
    'lifestyle_co_uk_5': {
      name: 'Lifestyle UK Search',
      buildUrl: (q) => `https://lifestyle.co.uk/searchresults.htm?q=${q}`,
    },
  },
  'Afghanistan': {
    'afghan-web_com_1': {
      name: 'Afghan-web',
      buildUrl: (q) => `https://www.afghan-web.com/?s=${q}`,
    },
  },
  'Albania': {
    'albafind_com_0': {
      name: 'Albafind',
      buildUrl: (q) => `http://www.albafind.com/?query_string=${q}`,
    },
    'shqiperia_com_2': {
      name: 'Shqiperia',
      buildUrl: (q) => `http://www.shqiperia.com/?termi=${q}`,
    },
  },
  'Algeria': {
    'arabo_com_1': {
      name: 'Arabo',
      buildUrl: (q) => `https://www.arabo.com/cgi-bin/links/search2.cgi?keywords=${q}&cat_search=`,
    },
  },
  'Azerbaijan': {
    'azer_com_0': {
      name: 'Azer',
      buildUrl: (q) => `http://www.azer.com/?query=${q}`,
    },
    'search_freefind_com_1': {
      name: 'Freefind',
      buildUrl: (q) => `https://search.freefind.com/find.html?id=6179835&pageid=r&mode=ALL&n=0&_charset_=windows-1252&bcd=%F7&query=${q}`,
    },
  },
  'Bahamas': {
    'bahamasb2b_com_1': {
      name: 'Bahamasb2b',
      buildUrl: (q) => `https://www.bahamasb2b.com/?s=${q}`,
    },
  },
  'Bangladesh': {
    'bangladeshdir_com_1': {
      name: 'Bangladeshdir',
      buildUrl: (q) => `https://bangladeshdir.com/?s=${q}`,
    },
    'webbangladesh_com_3': {
      name: 'Webbangladesh',
      buildUrl: (q) => `https://www.webbangladesh.com/search?search=${q}`,
    },
  },
  'Belarus': {
    'belarustourism_by_0': {
      name: 'Belarustourism',
      buildUrl: (q) => `https://belarustourism.by/en/search/?q=${q}&how=d&s=Search`,
    },
  },
  'Belgium': {
    'search-belgium_com_1': {
      name: 'Search-belgium',
      buildUrl: (q) => `https://www.search-belgium.com/search/powersearch.asp?action=search&page=1&Cnt=&category=&q=${q}&powerwide=Zoek`,
    },
  },
  'Bolivia': {
    'enlacesbolivia_net_0': {
      name: 'Enlacesbolivia',
      buildUrl: (q) => `http://www.enlacesbolivia.net/default.asp?gsc.q=${q}`,
    },
  },
  'Brazil': {
    'busca_uol_com_br_0': {
      name: 'UOL Busca',
      buildUrl: (q) => `https://busca.uol.com.br/result.html?term=${q}`,
    },
  },
  'Cameroon': {
    'cameroononline_org_1': {
      name: 'Cameroononline',
      buildUrl: (q) => `https://www.cameroononline.org/?s=${q}`,
    },
  },
  'Cape Verde': {
    'capeverde_com_0': {
      name: 'Capeverde',
      buildUrl: (q) => `https://www.capeverde.com/?s=${q}`,
    },
  },
  'Chile': {
    'terra_cl_1': {
      name: 'Terra',
      buildUrl: (q) => `https://www.terra.cl/noticias/buscar/?buscar=${q}`,
    },
  },
  'China': {
    'so_com_1': {
      name: '360 Search',
      buildUrl: (q) => `https://www.so.com/s?q=${q}`,
    },
    'baidu_com_0': {
      name: 'Baidu',
      buildUrl: (q) => `https://www.baidu.com/s?wd=${q}`,
    },
    'sogou_com_2': {
      name: 'Sogou',
      buildUrl: (q) => `https://www.sogou.com/web?query=${q}`,
    },
    'soso_com_3': {
      name: 'Soso',
      buildUrl: (q) => `http://www.soso.com/?q=${q}`,
    },
    'youdao_com_5': {
      name: 'Youdao',
      buildUrl: (q) => `https://www.youdao.com/result?word=${q}&lang=en`,
    },
  },
  'Cuba': {
    'sld_cu_1': {
      name: 'SLD',
      buildUrl: (q) => `https://www.sld.cu/infosearch_simple_search/?text=${q}&infoSid=62`,
    },
  },
  'Czech Republic': {
    'search_centrum_cz_1': {
      name: 'Centrum',
      buildUrl: (q) => `https://search.centrum.cz/?q=${q}#gsc.tab=0&gsc.q=${q}&gsc.page=1`,
    },
    'klikni_idnes_cz_2': {
      name: 'Idnes',
      buildUrl: (q) => `http://klikni.idnes.cz/?q=${q}`,
    },
    'internet_o2active_cz_3': {
      name: 'O2active',
      buildUrl: (q) => `http://internet.o2active.cz/?q=${q}`,
    },
    'search_seznam_cz_4': {
      name: 'Seznam',
      buildUrl: (q) => `https://search.seznam.cz/?q=${q}`,
    },
  },
  'Denmark': {
    'danskelinks_dk_1': {
      name: 'Danskelinks',
      buildUrl: (q) => `https://www.danskelinks.dk/modellersearch.asp?element=${q}`,
    },
    'hvem-hvor_dk_2': {
      name: 'Hvem-hvor',
      buildUrl: (q) => `http://www.hvem-hvor.dk/?q=${q}`,
    },
    'krak_dk_4': {
      name: 'Krak',
      buildUrl: (q) => `https://www.krak.dk/${q}/firmaer`,
    },
    'linkfeed_dk_6': {
      name: 'Linkfeed',
      buildUrl: (q) => `https://www.linkfeed.dk/?s=${q}`,
    },
    'zooka_dk_8': {
      name: 'Zooka',
      buildUrl: (q) => `https://zooka.dk/?s=${q}`,
    },
  },
  'Estonia': {
    'neti_ee_1': {
      name: 'Neti',
      buildUrl: (q) => `https://www.neti.ee/otsing?q=${q}`,
    },
  },
  'Finland': {
    'finland_fi_1': {
      name: 'Finland',
      buildUrl: (q) => `https://finland.fi/?s=${q}`,
    },
  },
  'France': {
    'alsannuaire_fr_0': {
      name: 'Alsannuaire',
      buildUrl: (q) => `http://www.alsannuaire.fr/alsannuaire/?q=${q}`,
    },
    'cnrs_fr_1': {
      name: 'CNRS',
      buildUrl: (q) => `https://www.cnrs.fr/fr/search?search_api_fulltext=${q}`,
    },
    'indexa_fr_3': {
      name: 'Indexa',
      buildUrl: (q) => `https://indexa.fr/recherche?search-words=${q}&search-filter-rubrique=&search-filter-rubrique-name=&search-filter-location=&search-filter-location-type=`,
    },
  },
  'Germany': {
    'eichsfeld-net_de_0': {
      name: 'Eichsfeld-net',
      buildUrl: (q) => `http://www.eichsfeld-net.de/?q=${q}`,
    },
    'eichsfeldforum_de_1': {
      name: 'Eichsfeldforum',
      buildUrl: (q) => `http://www.eichsfeldforum.de/search.php?keywords=${q}&sid=143000d527505809ade7f703e0c732a9`,
    },
    'fireball_com_3': {
      name: 'Fireball',
      buildUrl: (q) => `https://fireball.com/search/?f=web&q=${q}`,
    },
    'schlaue-seiten_de_5': {
      name: 'Schlaue-seiten',
      buildUrl: (q) => `https://www.schlaue-seiten.de/Inserate/?distance=15&keyword=${q}`,
    },
  },
  'Gibraltar': {
    'gibyellow_gi_1': {
      name: 'Gibyellow',
      buildUrl: (q) => `https://www.gibyellow.gi/k:${q}`,
    },
  },
  'Hungary': {
    'heureka_hu_1': {
      name: 'Heureka',
      buildUrl: (q) => `https://www.heureka.hu/?s=${q}`,
    },
  },
  'Iceland': {
    'finna_is_1': {
      name: 'Finna',
      buildUrl: (q) => `https://www.finna.is/leit/?keyword=${q}&zip_code=`,
    },
    'ja_is_3': {
      name: 'Ja.is',
      buildUrl: (q) => `https://ja.is/?q=${q}`,
    },
    'walhello_com_4': {
      name: 'Walhello',
      buildUrl: (q) => `http://www.walhello.com/mainis.html?q=${q}`,
    },
  },
  'Iran': {
    'iranmehr_com_1': {
      name: 'Iranmehr',
      buildUrl: (q) => `https://www.iranmehr.com/search/search.cgi?query=${q}`,
    },
  },
  'Ireland': {
    'globalirish_com_1': {
      name: 'Globalirish',
      buildUrl: (q) => `https://www.globalirish.com/index.php?q=${q}`,
    },
    'indexireland_com_3': {
      name: 'Indexireland',
      buildUrl: (q) => `https://www.indexireland.com/?q=${q}`,
    },
    'ireland-information_com_6': {
      name: 'Ireland-information',
      buildUrl: (q) => `http://www.ireland-information.com/engine/?q=${q}`,
    },
    'littleireland_ie_7': {
      name: 'Littleireland',
      buildUrl: (q) => `http://www.littleireland.ie/?q=${q}`,
    },
    'search_ie_4': {
      name: 'Search.ie',
      buildUrl: (q) => `http://www.search.ie/?q=${q}`,
    },
  },
  'Israel': {
    'mavensearch_com_1': {
      name: 'Mavensearch',
      buildUrl: (q) => `https://www.mavensearch.com/googlesearchresults.asp?cx=partner-pub-9741901929040647%3A7577061640&cof=FORID%3A10&ie=UTF-8&q=${q}&sa=Search`,
    },
  },
  'Italy': {
    'nuovosito_com_1': {
      name: 'Nuovosito',
      buildUrl: (q) => `https://www.nuovosito.com/?s=${q}`,
    },
  },
  'Japan': {
    'alcarna_net_1': {
      name: 'Alcarna',
      buildUrl: (q) => `http://www.alcarna.net/search.cgi?character=${q}`,
    },
    'service_smt_docomo_ne_jp_5': {
      name: 'Docomo',
      buildUrl: (q) => `https://service.smt.docomo.ne.jp/portal/search/web/result.html?from=goo&utm_source=goo&utm_medium=owned&utm_campaign=gootop_202506&q=${q}&prd_check=1#gsc.tab=0&gsc.q=${q}&gsc.page=1`,
    },
    'websearch_excite_co_jp_3': {
      name: 'Excite',
      buildUrl: (q) => `https://websearch.excite.co.jp/?q=${q}&search-submit-btn=%E6%A4%9C%E7%B4%A2`,
    },
    'search_goo_ne_jp_4': {
      name: 'Goo',
      buildUrl: (q) => `https://search.goo.ne.jp/web.jsp?MT=${q}`,
    },
    'news_infoseek_co_jp_9': {
      name: 'Infoseek',
      buildUrl: (q) => `https://news.infoseek.co.jp/search?type=article&q=${q}`,
    },
    'search_interconnect_co_jp_0': {
      name: 'Interconnect',
      buildUrl: (q) => `http://search.interconnect.co.jp/?q=${q}`,
    },
    'the-search_jp_7': {
      name: 'The-search',
      buildUrl: (q) => `https://www.the-search.jp/zip_code/search.php?q=${q}`,
    },
  },
  'Lithuania': {
    'delfi_lt_1': {
      name: 'Delfi',
      buildUrl: (q) => `https://www.delfi.lt/paieska?search=${q}`,
    },
  },
  'Luxembourg': {
    'editus_lu_3': {
      name: 'Editus',
      buildUrl: (q) => `https://www.editus.lu/en/search?q=${q}&w=`,
    },
    'luxweb_com_2': {
      name: 'Luxweb',
      buildUrl: (q) => `http://www.luxweb.com/info.html?q=${q}`,
    },
    'rtl_lu_1': {
      name: 'RTL',
      buildUrl: (q) => `https://www.rtl.lu/search?q=${q}`,
    },
  },
  'Mexico': {
    'mexicoweb_com_mx_1': {
      name: 'Mexicoweb',
      buildUrl: (q) => `https://www.mexicoweb.com.mx/busca/busca.cgi?query=${q}&Image.x=47&Image.y=11`,
    },
  },
  'Nepal': {
    'nepal_com_1': {
      name: 'Nepal',
      buildUrl: (q) => `https://www.nepal.com/search/?q=${q}`,
    },
  },
  'New Zealand': {
    'searchnz_co_nz_0': {
      name: 'SearchNZ',
      buildUrl: (q) => `http://www.searchnz.co.nz/?q=${q}`,
    },
  },
  'Nicaragua': {
    'nicaragua_com_1': {
      name: 'Nicaragua',
      buildUrl: (q) => `https://www.nicaragua.com/search/?q=${q}`,
    },
  },
  'Nigeria': {
    'finelib_com_1': {
      name: 'Finelib',
      buildUrl: (q) => `https://www.finelib.com/search.php?q=${q}&x=0&y=0`,
    },
    'nigeriaworld_com_3': {
      name: 'Nigeriaworld',
      buildUrl: (q) => `https://nigeriaworld.com/cgi-bin/search/search.pl?Terms=${q}`,
    },
  },
  'Norway': {
    'kvasir_no_1': {
      name: 'Kvasir',
      buildUrl: (q) => `https://www.kvasir.no/alle/${q}`,
    },
  },
  'Peru': {
    'maskay_com_1': {
      name: 'Maskay',
      buildUrl: (q) => `https://www.maskay.com/resultados.php?buscar=${q}`,
    },
  },
  'Poland': {
    'katalog_gery_pl_0': {
      name: 'Gery',
      buildUrl: (q) => `http://katalog.gery.pl/?q=${q}`,
    },
    'szukaj_gooru_pl_3': {
      name: 'Gooru',
      buildUrl: (q) => `https://szukaj.gooru.pl/?szukaj=${q}`,
    },
    'szukaj_interia_pl_9': {
      name: 'Interia',
      buildUrl: (q) => `https://szukaj.interia.pl/internet?q=${q}#gsc.tab=0&gsc.q=${q}&gsc.page=1`,
    },
    'szukaj_onet_pl_6': {
      name: 'Onet',
      buildUrl: (q) => `https://szukaj.onet.pl/?q=${q}`,
    },
    'szukaj_wp_pl_5': {
      name: 'WP',
      buildUrl: (q) => `https://szukaj.wp.pl/szukaj.html?q=${q}#gsc.tab=0&gsc.q=${q}&gsc.page=1`,
    },
  },
  'Romania': {
    'acasa_ro_1': {
      name: 'Acasa',
      buildUrl: (q) => `https://acasa.ro/search/do?search_str=${q}&submit=Cauta`,
    },
    'rol_ro_3': {
      name: 'Rol',
      buildUrl: (q) => `https://rol.ro/?s=${q}`,
    },
  },
  'Russia': {
    'filesearch_ru_2': {
      name: 'Filesearch',
      buildUrl: (q) => `http://www.filesearch.ru/?q=${q}`,
    },
    'mail_ru_1': {
      name: 'Mail.ru',
      buildUrl: (q) => `https://mail.ru/search?search_source=mailru_desktop_safe&msid=1&encoded_text=AACs8u9KUmNAaIru4Hkim3uSKiOW1kZTzDYW-SfBXb3fpHuc5v6AU_k3xupM1XTdJ3gqa4utwMuYC-asmHlp&serp_path=%2Fsearch%2F&text&type=web`,
    },
    'adresa_murman_ru_5': {
      name: 'Murman',
      buildUrl: (q) => `https://adresa.murman.ru/search/?find=${q}`,
    },
    'refer_ru_6': {
      name: 'Refer',
      buildUrl: (q) => `http://www.refer.ru/?q=${q}`,
    },
    'yandex_ru_8': {
      name: 'Yandex',
      buildUrl: (q) => `https://yandex.ru/search/?text=${q}`,
    },
  },
  'Slovakia': {
    'zoznam_sk_1': {
      name: 'Zoznam',
      buildUrl: (q) => `https://www.zoznam.sk/hladaj.fcgi?co=odkazy&s=${q}&s-utf8=${q}`,
    },
  },
  'South Korea': {
    'search_daum_net_0': {
      name: 'Daum',
      buildUrl: (q) => `https://search.daum.net/search?q=${q}`,
    },
    'search_naver_com_1': {
      name: 'Naver',
      buildUrl: (q) => `https://search.naver.com/search.naver?query=${q}`,
    },
  },
  'Spain': {
    'asturies_com_0': {
      name: 'Asturies',
      buildUrl: (q) => `https://asturies.com/search/node/${q}`,
    },
  },
  'Switzerland': {
    'search_ch_0': {
      name: 'Search.ch',
      buildUrl: (q) => `http://www.search.ch/?q=${q}`,
    },
    'swisscows_com_1': {
      name: 'Swisscows',
      buildUrl: (q) => `https://swisscows.com/en/web?query=${q}`,
    },
  },
  'Taiwan': {
    'search_yam_com_1': {
      name: 'Yam',
      buildUrl: (q) => `https://search.yam.com/Search/All?q=${q}`,
    },
  },
  'Thailand': {
    'chiangmai-online_com_0': {
      name: 'Chiangmai-online',
      buildUrl: (q) => `http://www.chiangmai-online.com/?q=${q}`,
    },
    'search_sanook_com_2': {
      name: 'Sanook',
      buildUrl: (q) => `https://search.sanook.com/?q=${q}`,
    },
  },
  'Turkey': {
    'mynet_com_1': {
      name: 'Mynet',
      buildUrl: (q) => `https://www.mynet.com/haberler/${q}`,
    },
  },
  'Ukraine': {
    'news_bigmir_net_1': {
      name: 'Bigmir',
      buildUrl: (q) => `https://news.bigmir.net/ua/search?s=${q}`,
    },
    'city_zp_ua_3': {
      name: 'City ZP',
      buildUrl: (q) => `https://city.zp.ua/search?q=${q}`,
    },
  },
  'United States': {
    'azoos_com_1': {
      name: 'Azoos',
      buildUrl: (q) => `https://www.azoos.com/search.php?search=${q}&action.x=28&action.y=15`,
    },
    'findouter_com_10': {
      name: 'Findouter',
      buildUrl: (q) => `http://www.findouter.com/USA/?q=${q}`,
    },
    'homepageseek_com_3': {
      name: 'Homepageseek',
      buildUrl: (q) => `https://homepageseek.com/results.htm?cx=partner-pub-1990995315281506%3A9355103136&cof=FORID%3A10&ie=UTF-8&q=${q}&sa=Search`,
    },
    'jayde_com_5': {
      name: 'Jayde',
      buildUrl: (q) => `https://www.jayde.com/sch.html?q=${q}`,
    },
    'search_sciway_net_9': {
      name: 'Sciway',
      buildUrl: (q) => `https://search.sciway.net/?cx=000697809214878659044%3A46oruutogqo&cof=FORID%3A10%3BNB%3A1&ie=UTF-8&sq=${q}&sa=`,
    },
    'scrubtheweb_com_7': {
      name: 'Scrubtheweb',
      buildUrl: (q) => `https://scrubtheweb.com/search/1/${q}`,
    },
    'zerx_com_12': {
      name: 'Zerx',
      buildUrl: (q) => `https://www.zerx.com/cgi-bin/search.pl?search=${q}`,
    },
  },
  'Vietnam': {
    'coccoc_com_0': {
      name: 'Coccoc',
      buildUrl: (q) => `https://coccoc.com/search?query=${q}`,
    },
    'viet_net_2': {
      name: 'Viet',
      buildUrl: (q) => `https://www.viet.net/cgi-bin/vietsearch?db=default&q=${q}&x=31&y=15&ru=https%3A%2F%2Fwww.vietgate.net%2F&rt=Return+to+VietGATE+Homepage`,
    },
  },
  'Virgin Islands': {
    'listingsus_com_1': {
      name: 'Listingsus',
      buildUrl: (q) => `https://listingsus.com/common/search.asp?term=${q}`,
    },
  },
};



const COUNTRY_TO_CONTINENT = {
  '123khoj_india': 'Asia',
  '1stekeuze_zoekmachine_nl_nethe': 'Europe',
  '2gogo_unite': 'Europe',
  'Afghanistan': 'Asia',
  'Albania': 'Europe',
  'Algeria': 'Africa',
  'Azerbaijan': 'Asia',
  'Bahamas': 'North America',
  'Bangladesh': 'Asia',
  'Belarus': 'Europe',
  'Belgium': 'Europe',
  'Bolivia': 'South America',
  'Brazil': 'South America',
  'Cameroon': 'Africa',
  'Cape Verde': 'Africa',
  'Chile': 'South America',
  'China': 'Asia',
  'Cuba': 'North America',
  'Czech Republic': 'Europe',
  'Denmark': 'Europe',
  'Estonia': 'Europe',
  'Finland': 'Europe',
  'France': 'Europe',
  'Germany': 'Europe',
  'Gibraltar': 'Europe',
  'Hungary': 'Europe',
  'Iceland': 'Europe',
  'Iran': 'Asia',
  'Ireland': 'Europe',
  'Israel': 'Asia',
  'Italy': 'Europe',
  'Japan': 'Asia',
  'Lithuania': 'Europe',
  'Luxembourg': 'Europe',
  'Mexico': 'North America',
  'Nepal': 'Asia',
  'New Zealand': 'Oceania',
  'Nicaragua': 'North America',
  'Nigeria': 'Africa',
  'Norway': 'Europe',
  'Peru': 'South America',
  'Poland': 'Europe',
  'Romania': 'Europe',
  'Russia': 'Europe',
  'Slovakia': 'Europe',
  'South Korea': 'Asia',
  'Spain': 'Europe',
  'Switzerland': 'Europe',
  'Taiwan': 'Asia',
  'Thailand': 'Asia',
  'Turkey': 'Asia',
  'Ukraine': 'Europe',
  'United States': 'North America',
  'Vietnam': 'Asia',
  'Virgin Islands': 'North America',
};

// Country name to flag emoji mapping
const COUNTRY_FLAGS = {
  '123khoj_india': '🇮🇳',
  '1stekeuze_zoekmachine_nl_nethe': '🇳🇱',
  '2gogo_unite': '🇬🇧',
  'Afghanistan': '🇦🇫',
  'Albania': '🇦🇱',
  'Algeria': '🇩🇿',
  'Azerbaijan': '🇦🇿',
  'Bahamas': '🇧🇸',
  'Bangladesh': '🇧🇩',
  'Belarus': '🇧🇾',
  'Belgium': '🇧🇪',
  'Bolivia': '🇧🇴',
  'Brazil': '🇧🇷',
  'Cameroon': '🇨🇲',
  'Cape Verde': '🇨🇻',
  'Chile': '🇨🇱',
  'China': '🇨🇳',
  'Cuba': '🇨🇺',
  'Czech Republic': '🇨🇿',
  'Denmark': '🇩🇰',
  'Estonia': '🇪🇪',
  'Finland': '🇫🇮',
  'France': '🇫🇷',
  'Germany': '🇩🇪',
  'Gibraltar': '🇬🇮',
  'Hungary': '🇭🇺',
  'Iceland': '🇮🇸',
  'Iran': '🇮🇷',
  'Ireland': '🇮🇪',
  'Israel': '🇮🇱',
  'Italy': '🇮🇹',
  'Japan': '🇯🇵',
  'Lithuania': '🇱🇹',
  'Luxembourg': '🇱🇺',
  'Mexico': '🇲🇽',
  'Nepal': '🇳🇵',
  'New Zealand': '🇳🇿',
  'Nicaragua': '🇳🇮',
  'Nigeria': '🇳🇬',
  'Norway': '🇳🇴',
  'Peru': '🇵🇪',
  'Poland': '🇵🇱',
  'Romania': '🇷🇴',
  'Russia': '🇷🇺',
  'Slovakia': '🇸🇰',
  'South Korea': '🇰🇷',
  'Spain': '🇪🇸',
  'Switzerland': '🇨🇭',
  'Taiwan': '🇹🇼',
  'Thailand': '🇹🇭',
  'Turkey': '🇹🇷',
  'Ukraine': '🇺🇦',
  'United States': '🇺🇸',
  'Vietnam': '🇻🇳',
  'Virgin Islands': '🇻🇬',
};

function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'root',
      title: 'Search with …',
      contexts: ['selection', 'page'],
    });

    // Countries submenu - FIRST (at the top)
    chrome.contextMenus.create({
      id: 'countries_root',
      parentId: 'root',
      title: 'By Country',
      contexts: ['selection', 'page'],
    });

    // AI Search Engines submenu - SECOND
    chrome.contextMenus.create({
      id: 'ai_root',
      parentId: 'root',
      title: 'AI Search Engines',
      contexts: ['selection', 'page'],
    });

    Object.entries(AI_ENGINES).forEach(([id, engine]) => {
      chrome.contextMenus.create({
        id: `ai|${id}`,
        parentId: 'ai_root',
        title: engine.name,
        contexts: ['selection', 'page'],
      });
    });

    // Regular engines - LAST (after By Country and AI Search Engines)
    Object.entries(ENGINES).forEach(([id, engine]) => {
      chrome.contextMenus.create({
        id,
        parentId: 'root',
        title: engine.name,
        contexts: ['selection', 'page'],
      });
    });

    // Organize countries by continent
    // Filter out countries with no custom engines
    const validCountries = Object.entries(COUNTRY_ENGINES)
      .filter(([, engines]) => Object.keys(engines).length > 0);
    
    // Group countries by continent
    const countriesByContinent = {};
    const unmappedCountries = [];
    validCountries.forEach(([countryName]) => {
      const continent = COUNTRY_TO_CONTINENT[countryName];
      if (!continent) {
        unmappedCountries.push(countryName);
        return;
      }
      if (!countriesByContinent[continent]) {
        countriesByContinent[continent] = [];
      }
      countriesByContinent[continent].push(countryName);
    });
    
    // Debug: Log unmapped countries
    if (unmappedCountries.length > 0) {
      console.warn('Unmapped countries:', unmappedCountries);
    }
    
    // Sort continents alphabetically
    const continents = Object.keys(countriesByContinent).sort((a, b) => a.localeCompare(b));
    
    // Debug: Log continents and their countries
    console.log('Continents found:', continents);
    continents.forEach(continent => {
      console.log(`${continent}: ${countriesByContinent[continent].length} countries`);
    });
    
    // Create continent submenus first, then countries
    let continentIndex = 0;
    let menuCreationStopped = false;
    
    function createNextContinent() {
      if (menuCreationStopped || continentIndex >= continents.length) {
        console.log('All continents created successfully');
        return;
      }
      
      const continent = continents[continentIndex];
      const continentId = `continent_${continent}`;
      
      chrome.contextMenus.create({
        id: continentId,
        parentId: 'countries_root',
        title: continent,
        contexts: ['selection', 'page'],
      }, (created) => {
        if (chrome.runtime.lastError) {
          console.error(`Error creating continent menu for ${continent}:`, chrome.runtime.lastError.message);
          // Check if it's a limit error
          if (chrome.runtime.lastError.message && chrome.runtime.lastError.message.includes('limit')) {
            console.warn(`Menu item limit reached. Stopping menu creation.`);
            menuCreationStopped = true;
            return;
          }
          continentIndex++;
          createNextContinent();
          return;
        }
        
        // Sort countries within continent alphabetically
        const countries = countriesByContinent[continent].sort((a, b) => a.localeCompare(b));
        
        // Create country menu items sequentially (not concurrently)
        let countryIndex = 0;
        
        function createNextCountry() {
          if (menuCreationStopped || countryIndex >= countries.length) {
            // All countries for this continent created, move to next continent
            continentIndex++;
            createNextContinent();
            return;
          }
          
          const country = countries[countryIndex];
          const countryId = `country_${country}`;
          const flag = COUNTRY_FLAGS[country] || '';
          const countryTitle = flag ? `${flag} ${country}` : country;
          
          chrome.contextMenus.create({
            id: countryId,
            parentId: continentId,
            title: countryTitle,
            contexts: ['selection', 'page'],
          }, (created) => {
            if (chrome.runtime.lastError) {
              console.error(`Error creating country menu for ${country}:`, chrome.runtime.lastError.message);
              // Check if it's a limit error
              if (chrome.runtime.lastError.message && chrome.runtime.lastError.message.includes('limit')) {
                console.warn(`Menu item limit reached. Stopping menu creation.`);
                menuCreationStopped = true;
                return;
              }
              // Continue to next country even if this one fails
              countryIndex++;
              createNextCountry();
              return;
            }
            
            // Sort engines within each country alphabetically by name
            const engines = COUNTRY_ENGINES[country];
            const engineEntries = Object.entries(engines).sort(([, a], [, b]) => a.name.localeCompare(b.name));
            
            // Create engine menu items sequentially
            let engineIndex = 0;
            
            function createNextEngine() {
              if (menuCreationStopped || engineIndex >= engineEntries.length) {
                // All engines for this country created, move to next country
                countryIndex++;
                createNextCountry();
                return;
              }
              
              const [engineId, engine] = engineEntries[engineIndex];
              
              chrome.contextMenus.create({
                id: `country|${country}|${engineId}`,
                parentId: countryId,
                title: engine.name,
                contexts: ['selection', 'page'],
              }, (created) => {
                if (chrome.runtime.lastError) {
                  console.error(`Error creating engine menu for ${country}|${engineId}:`, chrome.runtime.lastError.message);
                  // Check if it's a limit error
                  if (chrome.runtime.lastError.message && chrome.runtime.lastError.message.includes('limit')) {
                    console.warn(`Menu item limit reached. Stopping menu creation.`);
                    menuCreationStopped = true;
                    return;
                  }
                }
                
                // Move to next engine
                engineIndex++;
                createNextEngine();
              });
            }
            
            createNextEngine();
          });
        }
        
        createNextCountry();
      });
    }
    
    createNextContinent();
  });
}

chrome.runtime.onInstalled.addListener(() => {
  createMenus();
});

chrome.runtime.onStartup.addListener(() => {
  createMenus();
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab || !ENGINES[info.menuItemId]) return;

  let query = (info.selectionText || '').trim();

  if (!query) {
    try {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const input = window.prompt('Enter a search query');
          return (input || '').trim();
        },
      });
      query = result || '';
    } catch (e) {
      // If injection fails (e.g., Chrome page), silently ignore
      query = '';
    }
  }

  if (!query) return;

  const target = ENGINES[info.menuItemId];
  const url = target.buildUrl(encodeURIComponent(query));
  await chrome.tabs.create({ url, active: true });
});

// Handle clicks for AI engines
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab) return;
  if (!info.menuItemId.startsWith('ai|')) return;

  let query = (info.selectionText || '').trim();
  if (!query) {
    try {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const input = window.prompt('Enter a search query');
          return (input || '').trim();
        },
      });
      query = result || '';
    } catch (e) {
      query = '';
    }
  }
  if (!query) return;

  // Extract engineId from menuItemId format: ai|engineId
  const parts = info.menuItemId.split('|');
  if (parts.length < 2) return; // Invalid format
  
  const engineId = parts.slice(1).join('|'); // Join in case engineId contains |
  
  // Look up engine in AI_ENGINES
  if (!AI_ENGINES[engineId]) return;
  
  const engine = AI_ENGINES[engineId];
  const url = engine.buildUrl(encodeURIComponent(query));
  await chrome.tabs.create({ url, active: true });
});

// Handle clicks for country engines as well
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab) return;
  if (!info.menuItemId.startsWith('country|')) return;

  let query = (info.selectionText || '').trim();
  if (!query) {
    try {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const input = window.prompt('Enter a search query');
          return (input || '').trim();
        },
      });
      query = result || '';
    } catch (e) {
      query = '';
    }
  }
  if (!query) return;

  // Extract country and engineId from menuItemId format: country|CountryName|engineId
  const parts = info.menuItemId.split('|');
  if (parts.length < 3) return; // Invalid format
  
  const country = parts[1];
  const engineKey = parts.slice(2).join('|'); // Join in case engineId contains |
  
  // Look up engine in the specific country
  const engines = COUNTRY_ENGINES[country];
  if (!engines || !engines[engineKey]) return;
  
  const engine = engines[engineKey];
  const url = engine.buildUrl(encodeURIComponent(query));
  await chrome.tabs.create({ url, active: true });
});



