# OSINT Multi-Engine Search (Chrome MV3 Extension)

Right-click any page to search selected text. If no selection, you will be prompted to enter a query. Results open in a new tab.

## Engines
Ask, Baidu, Bing, GoodSearch, Google, i-Intelligence, Marginalia, AOL, Searcha, Entireweb, LinkedIn, Lycos, Naver, Sogou

## Install (Load Unpacked)
1. Open Chrome and go to `chrome://extensions`.
2. Enable Developer mode.
3. Click Load unpacked and select this folder.

## Usage
- Select text → right-click → “Search with …” → pick engine.
- No selection → right-click → “Search with …” → pick engine → enter query when prompted.

## Files
- `manifest.json`
- `background.js`

## Notes
Some engines (e.g., LinkedIn) may require you to be logged in.





