# Quick Installation Guide

## Step 1: Generate Icons

Before loading the extension, you need to create the icon files:

### Option A: Using the HTML Generator (Recommended)
1. Open `icons/icon-generator.html` in your web browser
2. Click "Generate All Icons"
3. Click each download button (16x16, 48x48, 128x128)
4. Save the files in the `icons/` folder as:
   - `icon16.png`
   - `icon48.png`
   - `icon128.png`

### Option B: Using Online Tools
1. Visit [Favicon Generator](https://www.favicon-generator.org/) or similar
2. Upload or create a 128x128 icon
3. Download the generated icons
4. Rename and place them in the `icons/` folder

### Option C: Create Your Own
- Create three PNG files: 16x16, 48x48, and 128x128 pixels
- Name them: `icon16.png`, `icon48.png`, `icon128.png`
- Place them in the `icons/` folder

## Step 2: Load Extension in Chrome

1. Open Chrome browser
2. Go to `chrome://extensions/`
3. Enable **Developer mode** (toggle in top-right)
4. Click **Load unpacked**
5. Select the `OriginalData` folder (the folder containing `manifest.json`)
6. The extension should now appear in your extensions list

## Step 3: Pin the Extension (Optional)

1. Click the puzzle piece icon (🧩) in Chrome's toolbar
2. Find "Finitimus - Publication Date Finder"
3. Click the pin icon to keep it visible

## Step 4: Test It!

1. Visit any news article or blog post
2. Click the Finitimus icon in your toolbar
3. Click "Find Publication Date"
4. The publication date should appear!

## Troubleshooting

**Icons not showing?**
- Make sure all three icon files exist in the `icons/` folder
- Check that file names are exactly: `icon16.png`, `icon48.png`, `icon128.png`
- Ensure files are valid PNG images

**Extension won't load?**
- Check the browser console (F12) for errors
- Verify `manifest.json` is valid JSON
- Make sure all required files are present

**Extension not working?**
- Make sure you're on a regular webpage (not `chrome://` pages)
- Try refreshing the page
- Check that the page has fully loaded

## Need Help?

Check the main `README.md` for more detailed information.


