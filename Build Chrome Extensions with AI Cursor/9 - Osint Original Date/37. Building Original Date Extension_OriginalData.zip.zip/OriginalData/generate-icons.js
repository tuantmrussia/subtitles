// Simple Node.js script to generate icons
// Run with: node generate-icons.js
// Requires: npm install canvas (or use the HTML generator instead)

const fs = require('fs');
const path = require('path');

// Create a simple SVG icon that can be converted to PNG
const iconSvg = `<svg width="128" height="128" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
    </linearGradient>
  </defs>
  <rect width="128" height="128" fill="url(#grad)" rx="20"/>
  <rect x="20" y="30" width="88" height="68" fill="white" rx="4"/>
  <rect x="20" y="30" width="88" height="20" fill="#5568d3" rx="4"/>
  <circle cx="40" cy="40" r="6" fill="white"/>
  <circle cx="88" cy="40" r="6" fill="white"/>
  <text x="64" y="75" font-family="Arial, sans-serif" font-size="28" font-weight="bold" fill="#667eea" text-anchor="middle">15</text>
</svg>`;

// Note: This script requires the 'canvas' package for Node.js
// For easier icon generation, use icons/icon-generator.html in a browser
// Or use online tools like https://www.favicon-generator.org/

console.log('Icon generation script');
console.log('For best results, use icons/icon-generator.html in your browser');
console.log('Or use online tools to create PNG icons from the SVG above');

// Save SVG as reference
fs.writeFileSync(path.join(__dirname, 'icons', 'icon.svg'), iconSvg);
console.log('SVG icon saved to icons/icon.svg');


