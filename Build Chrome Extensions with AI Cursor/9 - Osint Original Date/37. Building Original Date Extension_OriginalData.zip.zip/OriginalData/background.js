// Background service worker for Original Data
// Manifest V3 uses service workers instead of background pages

chrome.runtime.onInstalled.addListener(() => {
  console.log('Original Data extension installed');
});

// Handle extension icon click (if needed for future features)
chrome.action.onClicked.addListener((tab) => {
  // The popup handles the main functionality
  // This can be used for additional features like keyboard shortcuts
});

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'log') {
    console.log('[Original Data]', request.message);
    sendResponse({ success: true });
  } else if (request.action === 'showNotification') {
    showNotification(request.type, request.message, request.title);
    setBadge(request.type, sender.tab?.id);
    sendResponse({ success: true });
  } else if (request.action === 'setBadge') {
    setBadge(request.type, sender.tab?.id);
    sendResponse({ success: true });
  } else if (request.action === 'clearBadge') {
    clearBadge(sender.tab?.id);
    sendResponse({ success: true });
  } else if (request.action === 'autoDetectResult') {
    // Handle automatic detection from content script
    handleAutoDetectResult(request.result, sender.tab?.id);
    sendResponse({ success: true });
  }
  return true; // Keep channel open for async response
});

// Handle automatic detection results from content script
function handleAutoDetectResult(result, tabId) {
  if (!tabId) {
    return; // Can't set badge without tab ID
  }

  if (result && result.date) {
    // Data found - show success badge
    setBadge('success', tabId);
    
    // Optionally show a notification (you can remove this if you only want badges)
    // showNotification('success', `Publication date found: ${result.date}`, 'Data Found');
  } else {
    // No data found - show error badge
    // Only show error badge for certain sites, or show it for all
    // For now, we'll show it for all sites that can't be scraped
    setBadge('error', tabId);
  }
}

// Function to show Chrome notifications
function showNotification(type, message, title = 'Original Data') {
  // Set different icons/prefixes based on notification type
  let notificationTitle = title;
  if (type === 'success') {
    notificationTitle = '✅ ' + title;
  } else if (type === 'error') {
    notificationTitle = '⚠️ ' + title;
  }

  chrome.notifications.create({
    type: 'basic',
    iconUrl: chrome.runtime.getURL('icons/icon48.png'),
    title: notificationTitle,
    message: message,
    priority: 1
  }, (notificationId) => {
    if (chrome.runtime.lastError) {
      console.error('Error showing notification:', chrome.runtime.lastError);
    } else {
      // Auto-close notification after 5 seconds
      setTimeout(() => {
        chrome.notifications.clear(notificationId);
      }, 5000);
    }
  });
}

// Function to set badge on extension icon
function setBadge(type, tabId = null) {
  const badgeConfig = {
    text: '',
    color: '#4285F4' // Default blue
  };

  if (type === 'success') {
    badgeConfig.text = '✓';
    badgeConfig.color = '#34A853'; // Green
  } else if (type === 'error') {
    badgeConfig.text = '!';
    badgeConfig.color = '#EA4335'; // Red
  }

  if (tabId) {
    // Set badge for specific tab
    chrome.action.setBadgeText({ text: badgeConfig.text, tabId: tabId });
    chrome.action.setBadgeBackgroundColor({ color: badgeConfig.color, tabId: tabId });
  } else {
    // Set badge globally
    chrome.action.setBadgeText({ text: badgeConfig.text });
    chrome.action.setBadgeBackgroundColor({ color: badgeConfig.color });
  }

  // Auto-clear badge after 10 seconds
  setTimeout(() => {
    clearBadge(tabId);
  }, 10000);
}

// Function to clear badge
function clearBadge(tabId = null) {
  if (tabId) {
    chrome.action.setBadgeText({ text: '', tabId: tabId });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

