// Content script
// This script runs on all pages and can be used for additional functionality
// Automatically detects publication dates when pages load

// Listen for messages from popup or background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'detectDate') {
    const result = detectPublicationDate();
    sendResponse(result);
    return true; // Keep channel open for async response
  }
});

// Track if we've already detected for this page to avoid duplicate badges
let hasDetected = false;
let detectionTimeout = null;

// Automatically detect date when page loads
function autoDetectOnLoad() {
  // Reset detection flag when navigating to a new page
  hasDetected = false;
  
  // Clear any pending detection
  if (detectionTimeout) {
    clearTimeout(detectionTimeout);
  }
  
  // Wait for DOM to be ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      detectionTimeout = setTimeout(performAutoDetection, 1500);
    });
  } else {
    // DOM is already ready, but wait a bit for dynamic content
    detectionTimeout = setTimeout(performAutoDetection, 1500);
  }
}

// Perform automatic detection and notify background
function performAutoDetection() {
  // Skip if already detected or if it's a Chrome internal page
  if (hasDetected) {
    return;
  }
  
  if (window.location.protocol === 'chrome:' || 
      window.location.protocol === 'chrome-extension:' ||
      window.location.protocol === 'edge:') {
    return;
  }

  hasDetected = true;
  const result = detectPublicationDate();
  
  // Send result to background script
  chrome.runtime.sendMessage({
    action: 'autoDetectResult',
    result: result,
    url: window.location.href
  }, (response) => {
    if (chrome.runtime.lastError) {
      // Extension context might be invalid, ignore
      console.log('Could not send auto-detect result:', chrome.runtime.lastError);
    }
  });
}

// Handle navigation in SPAs (Single Page Applications)
let lastUrl = location.href;

// Check for URL changes periodically (for SPAs)
setInterval(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    hasDetected = false;
    autoDetectOnLoad();
  }
}, 1000);

// Listen for popstate (back/forward navigation)
window.addEventListener('popstate', () => {
  hasDetected = false;
  autoDetectOnLoad();
});

// Start auto-detection
autoDetectOnLoad();

// Re-export the detection function for use in popup injection
function detectPublicationDate() {
  const dateDetectors = [
    // Meta tags - Open Graph
    () => {
      const ogDate = document.querySelector('meta[property="article:published_time"]');
      if (ogDate) return { date: ogDate.content, source: 'Open Graph meta tag' };
      
      const ogModified = document.querySelector('meta[property="article:modified_time"]');
      if (ogModified) return { date: ogModified.content, source: 'Open Graph modified time' };
      
      return null;
    },
    
    // Meta tags - Standard
    () => {
      const metaDate = document.querySelector('meta[name="publishdate"]') || 
                      document.querySelector('meta[name="pubdate"]') ||
                      document.querySelector('meta[name="publication_date"]') ||
                      document.querySelector('meta[name="date"]') ||
                      document.querySelector('meta[name="DC.date"]') ||
                      document.querySelector('meta[property="datePublished"]');
      if (metaDate) return { date: metaDate.content || metaDate.getAttribute('content'), source: 'Meta tag' };
      return null;
    },
    
    // Schema.org JSON-LD
    () => {
      const scripts = document.querySelectorAll('script[type="application/ld+json"]');
      for (const script of scripts) {
        try {
          const data = JSON.parse(script.textContent);
          const findDate = (obj) => {
            if (typeof obj !== 'object' || obj === null) return null;
            if (obj.datePublished) return obj.datePublished;
            if (obj.dateCreated) return obj.dateCreated;
            if (obj.publishedTime) return obj.publishedTime;
            for (const key in obj) {
              const result = findDate(obj[key]);
              if (result) return result;
            }
            return null;
          };
          const date = findDate(data);
          if (date) return { date, source: 'Schema.org JSON-LD' };
        } catch (e) {
          // Invalid JSON, skip
        }
      }
      return null;
    },
    
    // HTML5 time element
    () => {
      const timeEl = document.querySelector('time[datetime]');
      if (timeEl) {
        const datetime = timeEl.getAttribute('datetime');
        if (datetime) return { date: datetime, source: 'HTML5 time element' };
      }
      return null;
    },
    
    // Data attributes
    () => {
      const dataDate = document.querySelector('[data-published]') ||
                      document.querySelector('[data-pubdate]') ||
                      document.querySelector('[data-date-published]');
      if (dataDate) {
        const date = dataDate.getAttribute('data-published') ||
                    dataDate.getAttribute('data-pubdate') ||
                    dataDate.getAttribute('data-date-published');
        if (date) return { date, source: 'Data attribute' };
      }
      return null;
    },
    
    // WordPress specific
    () => {
      const wpDate = document.querySelector('.entry-date, .published, .post-date');
      if (wpDate) {
        const datetime = wpDate.getAttribute('datetime') || wpDate.getAttribute('title');
        if (datetime) return { date: datetime, source: 'WordPress date element' };
        const text = wpDate.textContent.trim();
        if (text) {
          const parsed = new Date(text);
          if (!isNaN(parsed.getTime())) return { date: parsed.toISOString(), source: 'WordPress date text' };
        }
      }
      return null;
    },
    
    // URL pattern
    () => {
      const url = window.location.href;
      const patterns = [
        /(\d{4})\/(\d{2})\/(\d{2})/,
        /(\d{4})-(\d{2})-(\d{2})/,
        /(\d{4})\/(\d{2})/,
      ];
      for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match) {
          try {
            const dateStr = match[0].replace(/\//g, '-');
            const date = new Date(dateStr);
            if (!isNaN(date.getTime())) {
              return { date: date.toISOString(), source: 'URL pattern' };
            }
          } catch (e) {
            // Invalid date
          }
        }
      }
      return null;
    },
    
    // Content analysis
    () => {
      const article = document.querySelector('article, main, [role="main"]');
      if (article) {
        const text = article.textContent;
        const datePatterns = [
          /(?:published|date|posted)[:\s]+([A-Za-z]+\s+\d{1,2},?\s+\d{4})/i,
          /(\d{1,2}\/\d{1,2}\/\d{4})/,
          /(\d{4}-\d{2}-\d{2})/,
        ];
        for (const pattern of datePatterns) {
          const match = text.match(pattern);
          if (match) {
            try {
              const date = new Date(match[1]);
              if (!isNaN(date.getTime())) {
                return { date: date.toISOString(), source: 'Content analysis' };
              }
            } catch (e) {
              // Invalid date
            }
          }
        }
      }
      return null;
    },
    
    // Aggressive text scanning - scan visible elements for date patterns
    () => {
      // Get all visible text elements, prioritizing top of page
      const selectors = [
        'h1, h2, h3, h4, h5, h6',  // Headings
        'header',                   // Header sections
        'p',                        // Paragraphs
        'div',                      // Divs
        'span',                     // Spans
        'time',                     // Time elements (even without datetime)
        '[class*="date"]',          // Elements with "date" in class
        '[class*="published"]',     // Elements with "published" in class
        '[id*="date"]',             // Elements with "date" in id
        '[id*="published"]'         // Elements with "published" in id
      ];
      
      // Collect elements, avoiding duplicates using Set
      const elementSet = new Set();
      for (const selector of selectors) {
        const found = document.querySelectorAll(selector);
        found.forEach(el => elementSet.add(el));
      }
      
      // Convert to array and sort by position on page (top to bottom)
      const elements = Array.from(elementSet);
      elements.sort((a, b) => {
        const rectA = a.getBoundingClientRect();
        const rectB = b.getBoundingClientRect();
        return rectA.top - rectB.top;
      });
      
      // Comprehensive date patterns
      const datePatterns = [
        // "Nov 17, 2025" or "November 17, 2025" or "Nov 17 2025"
        /\b([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{4})\b/,
        // "17 Nov 2025" or "17 November 2025"
        /\b(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})\b/,
        // "2025-11-17" or "2025/11/17"
        /\b(\d{4})[-/](\d{1,2})[-/](\d{1,2})\b/,
        // "11/17/2025" or "11-17-2025" (US format)
        /\b(\d{1,2})[-/](\d{1,2})[-/](\d{4})\b/,
        // "17/11/2025" or "17-11-2025" (EU format)
        /\b(\d{1,2})[-/](\d{1,2})[-/](\d{4})\b/,
        // ISO format with time
        /\b(\d{4}-\d{2}-\d{2})T?\d{0,2}:?\d{0,2}:?\d{0,2}/,
      ];
      
      // Check elements from top to bottom, limit to first 50 to avoid performance issues
      for (let i = 0; i < Math.min(elements.length, 50); i++) {
        const element = elements[i];
        const text = element.textContent.trim();
        
        // Skip if element is too large (likely contains entire page content)
        if (text.length > 5000) continue;
        
        // Skip if element is not visible
        const rect = element.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) continue;
        
        for (const pattern of datePatterns) {
          const match = text.match(pattern);
          if (match) {
            try {
              let dateStr = match[0];
              
              // Try to parse the date
              const date = new Date(dateStr);
              
              // Validate: date should be reasonable (not too far in past/future)
              const now = new Date();
              const yearDiff = Math.abs(date.getFullYear() - now.getFullYear());
              
              // Accept dates between 1990 and 2100
              if (!isNaN(date.getTime()) && 
                  date.getFullYear() >= 1990 && 
                  date.getFullYear() <= 2100 &&
                  yearDiff < 150) {
                return { date: date.toISOString(), source: 'Text element scanning' };
              }
            } catch (e) {
              // Invalid date, continue
            }
          }
        }
      }
      
      return null;
    }
  ];

  for (const detector of dateDetectors) {
    try {
      const result = detector();
      if (result && result.date) {
        return result;
      }
    } catch (e) {
      // Continue to next detector
    }
  }

  return { date: null, source: null };
}

