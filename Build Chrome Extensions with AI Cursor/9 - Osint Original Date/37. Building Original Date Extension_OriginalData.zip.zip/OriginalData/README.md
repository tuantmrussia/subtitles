# Finitimus - Publication Date Finder

A modern Chrome extension that helps you find publication dates for articles and web content with a single click. Built with Manifest V3 and modern web technologies.

## Features

- 🔍 **One-Click Detection**: Find publication dates instantly
- 📅 **Multiple Detection Methods**: Uses various techniques to find dates:
  - Open Graph meta tags
  - Standard meta tags
  - Schema.org JSON-LD structured data
  - HTML5 time elements
  - Data attributes
  - WordPress-specific elements
  - URL pattern analysis
  - Content analysis
- 🎨 **Modern UI**: Beautiful, gradient-based interface
- ⚡ **Fast & Lightweight**: Optimized for performance
- 🔒 **Privacy-Focused**: Only analyzes the current tab, no data collection

## Installation

### From Source

1. **Clone or download this repository**
   ```bash
   git clone <repository-url>
   cd OriginalData
   ```

2. **Generate Icons** (if not already present)
   - Open `icons/icon-generator.html` in your browser
   - Click "Generate All Icons" and download the three icon sizes
   - Save them as `icon16.png`, `icon48.png`, and `icon128.png` in the `icons/` folder
   - Alternatively, create your own icons (16x16, 48x48, 128x128 pixels)

3. **Load the Extension in Chrome**
   - Open Chrome and navigate to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top-right corner)
   - Click "Load unpacked"
   - Select the `OriginalData` folder
   - The extension should now appear in your extensions list

4. **Pin the Extension** (Optional)
   - Click the puzzle piece icon in Chrome's toolbar
   - Find "Finitimus" and click the pin icon to keep it visible

## Usage

1. Navigate to any webpage with an article or content
2. Click the Finitimus extension icon in your toolbar
3. Click the "Find Publication Date" button
4. The publication date will be displayed along with the detection method used

## How It Works

Finitimus uses multiple detection strategies in order of reliability:

1. **Open Graph Meta Tags**: Checks for `article:published_time` or `article:modified_time`
2. **Standard Meta Tags**: Looks for various date-related meta tags
3. **Schema.org JSON-LD**: Parses structured data for `datePublished` or `dateCreated`
4. **HTML5 Time Elements**: Finds `<time datetime="">` elements
5. **Data Attributes**: Checks for `data-published`, `data-pubdate`, etc.
6. **WordPress Elements**: Detects WordPress-specific date classes
7. **URL Patterns**: Analyzes URL for date patterns (YYYY/MM/DD)
8. **Content Analysis**: Searches article content for date patterns

## File Structure

```
OriginalData/
├── manifest.json          # Extension manifest (Manifest V3)
├── popup.html             # Popup UI HTML
├── popup.css              # Popup styling
├── popup.js               # Popup logic and date detection
├── content.js             # Content script
├── background.js          # Service worker
├── icons/                 # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   ├── icon128.png
│   └── icon-generator.html
└── README.md             # This file
```

## Development

### Technologies Used

- **Manifest V3**: Latest Chrome extension standard
- **Vanilla JavaScript**: No frameworks, fast and lightweight
- **Modern CSS**: Gradients, animations, responsive design
- **Chrome APIs**: `chrome.tabs`, `chrome.scripting`, `chrome.runtime`

### Building/Customizing

1. Modify `popup.css` to change the appearance
2. Edit `popup.js` to add new detection methods
3. Update `manifest.json` for permissions or metadata
4. Test in Chrome's developer mode

## Limitations

- Cannot analyze Chrome internal pages (`chrome://`, `chrome-extension://`)
- Some websites may not have publication date metadata
- Date format parsing may vary by locale
- Content analysis is a fallback and may be less accurate

## Privacy

- **No data collection**: The extension doesn't collect or transmit any data
- **Local processing**: All date detection happens locally in your browser
- **Minimal permissions**: Only requires access to the active tab
- **No tracking**: No analytics, no external requests

## Troubleshooting

**Extension not working?**
- Make sure you're on a regular webpage (not Chrome internal pages)
- Check that the page has loaded completely
- Try refreshing the page and clicking the extension again

**No date found?**
- The page may not contain publication date metadata
- Try a different article or website
- Some sites don't include publication dates

**Icons not showing?**
- Make sure all three icon files (16x16, 48x48, 128x128) are in the `icons/` folder
- Use the icon generator or create your own PNG files

## Version History

### v2.0.0 (Current)
- Complete rewrite with Manifest V3
- Modern UI design
- Multiple detection methods
- Improved error handling
- Better date formatting

### v1.31.9 (Original)
- Last updated: March 11, 2015
- Legacy Manifest V2 version

## Contributing

Feel free to submit issues, fork the repository, and create pull requests for any improvements.

## License

This project is open source and available for modification and distribution.

## Credits

Inspired by the original Finitimus extension. Rebuilt with modern technologies and best practices.

---

**Note**: This is a modernized version of the original Finitimus extension. The original extension (v1.31.9) was last updated in 2015 and used Manifest V2. This version uses Manifest V3 and includes improvements in functionality, security, and user experience.


