document.addEventListener('DOMContentLoaded', () => {
  const resultDiv = document.getElementById('result');
  const errorDiv = document.getElementById('error');
  const loadingDiv = document.getElementById('loading');
  const dateDisplay = document.getElementById('dateDisplay');
  const dateSource = document.getElementById('dateSource');
  const errorMessage = document.getElementById('errorMessage');
  const dateFormatSelect = document.getElementById('dateFormat');
  
  let currentDateInfo = null; // Store the detected date info

  // Function to perform the date detection
  const performDetection = async () => {
    // Reset UI
    resultDiv.classList.add('hidden');
    errorDiv.classList.add('hidden');
    loadingDiv.classList.remove('hidden');

    try {
      // Get the active tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab || !tab.url) {
        throw new Error('Unable to access current tab');
      }

      // Check if it's a valid web page
      if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://') || tab.url.startsWith('edge://')) {
        throw new Error('This extension cannot analyze Chrome internal pages');
      }

      // Inject content script and get date
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: detectPublicationDate
      });

      loadingDiv.classList.add('hidden');

      if (results && results[0] && results[0].result) {
        const dateInfo = results[0].result;
        
        if (dateInfo.date) {
          // Store the date info for format changes
          currentDateInfo = dateInfo;
          
          // Get saved format preference
          chrome.storage.sync.get(['dateFormat'], (result) => {
            const format = result.dateFormat || 'default';
            const formattedDate = formatDate(dateInfo.date, format);
            dateDisplay.textContent = formattedDate;
            dateSource.textContent = `Found via: ${dateInfo.source}`;
            resultDiv.classList.remove('hidden');
            
            // Set the format selector value
            if (dateFormatSelect) {
              dateFormatSelect.value = format;
            }
            
            // Show success notification and badge
            chrome.runtime.sendMessage({
              action: 'showNotification',
              type: 'success',
              title: 'Data Found',
              message: `Publication date found: ${formattedDate}`
            });
            
            // Set badge directly on extension icon
            chrome.action.setBadgeText({ text: '✓', tabId: tab.id });
            chrome.action.setBadgeBackgroundColor({ color: '#34A853', tabId: tab.id });
            
            // Clear badge after 10 seconds
            setTimeout(() => {
              chrome.action.setBadgeText({ text: '', tabId: tab.id });
            }, 10000);
          });
        } else {
          showError('No publication date found on this page. The page may not contain date metadata.');
          
          // Show error notification and badge
          chrome.runtime.sendMessage({
            action: 'showNotification',
            type: 'error',
            title: 'No Data Found',
            message: 'Unable to find publication date on this page. The page may not be scrapable.'
          });
          
          // Set badge directly on extension icon
          chrome.action.setBadgeText({ text: '!', tabId: tab.id });
          chrome.action.setBadgeBackgroundColor({ color: '#EA4335', tabId: tab.id });
          
          // Clear badge after 10 seconds
          setTimeout(() => {
            chrome.action.setBadgeText({ text: '', tabId: tab.id });
          }, 10000);
        }
      } else {
        showError('Unable to analyze this page. Please try again.');
        
        // Show error notification and badge
        chrome.runtime.sendMessage({
          action: 'showNotification',
          type: 'error',
          title: 'Analysis Failed',
          message: 'Unable to analyze this page. It may not be scrapable.'
        });
        
        // Set badge directly on extension icon
        chrome.action.setBadgeText({ text: '!', tabId: tab.id });
        chrome.action.setBadgeBackgroundColor({ color: '#EA4335', tabId: tab.id });
        
        // Clear badge after 10 seconds
        setTimeout(() => {
          chrome.action.setBadgeText({ text: '', tabId: tab.id });
        }, 10000);
      }
    } catch (error) {
      loadingDiv.classList.add('hidden');
      showError(error.message || 'An error occurred while detecting the publication date.');
      
      // Show error notification
      chrome.runtime.sendMessage({
        action: 'showNotification',
        type: 'error',
        title: 'Error',
        message: error.message || 'An error occurred while detecting the publication date.'
      });
      
      // Try to set badge if we have tab info
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && tab.id) {
          chrome.action.setBadgeText({ text: '!', tabId: tab.id });
          chrome.action.setBadgeBackgroundColor({ color: '#EA4335', tabId: tab.id });
          
          // Clear badge after 10 seconds
          setTimeout(() => {
            chrome.action.setBadgeText({ text: '', tabId: tab.id });
          }, 10000);
        }
      } catch (e) {
        // If we can't get tab, badge won't be set
        console.log('Could not set badge:', e);
      }
    }
  };

  // Auto-trigger detection when popup opens
  performDetection();

  function showError(message) {
    errorMessage.textContent = message;
    errorDiv.classList.remove('hidden');
  }

  // Load saved format preference
  chrome.storage.sync.get(['dateFormat'], (result) => {
    if (result.dateFormat) {
      dateFormatSelect.value = result.dateFormat;
    }
  });

  // Handle format change
  dateFormatSelect.addEventListener('change', (e) => {
    const selectedFormat = e.target.value;
    chrome.storage.sync.set({ dateFormat: selectedFormat });
    if (currentDateInfo && currentDateInfo.date) {
      const formattedDate = formatDate(currentDateInfo.date, selectedFormat);
      dateDisplay.textContent = formattedDate;
    }
  });

  function formatDate(dateString, format = 'default') {
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return dateString; // Return original if invalid
      }
      
      const day = date.getDate();
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      const hours = date.getHours();
      const minutes = date.getMinutes();
      const seconds = date.getSeconds();
      
      // Check if time information is available in the original string
      // Time is considered available if the string explicitly contains time patterns
      const hasTimeInfo = (dateString.includes('T') && dateString.match(/T\d{2}:\d{2}/)) || // ISO format with time
                          (/\d{1,2}:\d{2}/.test(dateString) && !dateString.match(/^\d{4}-\d{2}-\d{2}$/)) || // Has time pattern but not just date
                          dateString.includes('AM') || dateString.includes('PM') ||
                          dateString.includes('am') || dateString.includes('pm') ||
                          dateString.includes('GMT') || dateString.includes('UTC') ||
                          dateString.match(/\d{1,2}:\d{2}:\d{2}/); // Has seconds
      
      // Format time string if available
      const formatTime = () => {
        if (!hasTimeInfo) return '';
        const pad = (n) => n.toString().padStart(2, '0');
        return ` ${pad(hours)}:${pad(minutes)}`;
      };
      
      // Pad with zeros
      const pad = (n) => n.toString().padStart(2, '0');
      
      switch (format) {
        case 'dd-mm-yyyy':
          return `${pad(day)}-${pad(month)}-${year}${formatTime()}`;
        
        case 'mm-dd-yyyy':
          return `${pad(month)}-${pad(day)}-${year}${formatTime()}`;
        
        case 'yyyy-mm-dd':
          return `${year}-${pad(month)}-${pad(day)}${formatTime()}`;
        
        case 'dd/mm/yyyy':
          return `${pad(day)}/${pad(month)}/${year}${formatTime()}`;
        
        case 'mm/dd/yyyy':
          return `${pad(month)}/${pad(day)}/${year}${formatTime()}`;
        
        case 'thai-buddhist':
          // Thai Buddhist calendar: add 543 years (no time for calendar conversions)
          const thaiYear = year + 543;
          return `${pad(day)}-${pad(month)}-${thaiYear}`;
        
        case 'hijri':
          return formatHijriDate(date);
        
        case 'japanese':
          return formatJapaneseDate(date);
        
        case 'chinese':
          return formatChineseDate(date);
        
        case 'default':
        default:
          const options = { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric'
          };
          let formatted = date.toLocaleDateString('en-US', options);
          
          // Add time if available
          if (hasTimeInfo) {
            const timeOptions = {
              hour: '2-digit',
              minute: '2-digit'
            };
            formatted += ` at ${date.toLocaleTimeString('en-US', timeOptions)}`;
          }
          
          return formatted;
      }
    } catch (e) {
      return dateString;
    }
  }

  // Convert Gregorian date to Hijri (Islamic) date
  function formatHijriDate(date) {
    // More accurate Hijri calendar conversion
    // Hijri epoch: July 16, 622 CE (Gregorian) = Muharram 1, 1 AH
    const gregorianEpoch = new Date(622, 6, 16); // July 16, 622
    const daysSinceEpoch = Math.floor((date - gregorianEpoch) / (1000 * 60 * 60 * 24));
    
    // Hijri year calculation (average year length is 354.367 days)
    let hijriYear = Math.floor(daysSinceEpoch / 354.367) + 1;
    
    // Calculate remaining days in the Hijri year
    let remainingDays = daysSinceEpoch - Math.floor((hijriYear - 1) * 354.367);
    
    // Determine if it's a leap year (Hijri leap years occur in a 30-year cycle)
    const leapYears = [2, 5, 7, 10, 13, 16, 18, 21, 24, 26, 29];
    const yearInCycle = ((hijriYear - 1) % 30) + 1;
    const isLeapYear = leapYears.includes(yearInCycle);
    const yearLength = isLeapYear ? 355 : 354;
    
    // Adjust if remaining days exceed year length
    if (remainingDays >= yearLength) {
      hijriYear++;
      remainingDays -= yearLength;
    }
    
    // Calculate month and day
    const hijriMonthLengths = [30, 29, 30, 29, 30, 29, 30, 29, 30, 29, 30, isLeapYear ? 30 : 29];
    let hijriMonth = 1;
    let hijriDay = remainingDays + 1;
    
    for (let i = 0; i < hijriMonthLengths.length; i++) {
      if (hijriDay <= hijriMonthLengths[i]) {
        hijriMonth = i + 1;
        break;
      }
      hijriDay -= hijriMonthLengths[i];
    }
    
    const hijriMonths = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الثاني', 'جمادى الأولى', 'جمادى الثانية', 
                        'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];
    
    const monthName = hijriMonths[hijriMonth - 1];
    
    return `${hijriDay} ${monthName} ${hijriYear} هـ`;
  }

  // Format date in Japanese era format
  function formatJapaneseDate(date) {
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const day = date.getDate();
    
    // Determine Japanese era
    let eraName = '';
    let eraYear = year;
    
    if (year >= 2019) {
      eraName = '令和';
      eraYear = year - 2018;
    } else if (year >= 1989) {
      eraName = '平成';
      eraYear = year - 1988;
    } else if (year >= 1926) {
      eraName = '昭和';
      eraYear = year - 1925;
    } else if (year >= 1912) {
      eraName = '大正';
      eraYear = year - 1911;
    } else if (year >= 1868) {
      eraName = '明治';
      eraYear = year - 1867;
    } else {
      eraName = '西暦';
      eraYear = year;
    }
    
    const months = ['', '1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];
    
    if (eraName === '西暦') {
      return `${year}年${months[month]}${day}日`;
    } else {
      return `${eraName}${eraYear === 1 ? '元' : eraYear}年${months[month]}${day}日`;
    }
  }

  // Format date in Chinese format
  function formatChineseDate(date) {
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const day = date.getDate();
    
    return `${year}年${month}月${day}日`;
  }
});

// This function will be injected into the page
function detectPublicationDate() {
  const dateDetectors = [
    // Meta tags - Open Graph
    () => {
      const ogDate = document.querySelector('meta[property="article:published_time"]');
      if (ogDate) return { date: ogDate.content, source: 'Open Graph meta tag' };
      
      const ogModified = document.querySelector('meta[property="article:modified_time"]');
      if (ogModified) return { date: ogModified.content, source: 'Open Graph modified time' };
      
      return null;
    },
    
    // Meta tags - Standard
    () => {
      const metaDate = document.querySelector('meta[name="publishdate"]') || 
                      document.querySelector('meta[name="pubdate"]') ||
                      document.querySelector('meta[name="publication_date"]') ||
                      document.querySelector('meta[name="date"]') ||
                      document.querySelector('meta[name="DC.date"]') ||
                      document.querySelector('meta[property="datePublished"]');
      if (metaDate) return { date: metaDate.content || metaDate.getAttribute('content'), source: 'Meta tag' };
      return null;
    },
    
    // Schema.org JSON-LD
    () => {
      const scripts = document.querySelectorAll('script[type="application/ld+json"]');
      for (const script of scripts) {
        try {
          const data = JSON.parse(script.textContent);
          const findDate = (obj) => {
            if (typeof obj !== 'object' || obj === null) return null;
            if (obj.datePublished) return obj.datePublished;
            if (obj.dateCreated) return obj.dateCreated;
            if (obj.publishedTime) return obj.publishedTime;
            for (const key in obj) {
              const result = findDate(obj[key]);
              if (result) return result;
            }
            return null;
          };
          const date = findDate(data);
          if (date) return { date, source: 'Schema.org JSON-LD' };
        } catch (e) {
          // Invalid JSON, skip
        }
      }
      return null;
    },
    
    // HTML5 time element
    () => {
      const timeEl = document.querySelector('time[datetime]');
      if (timeEl) {
        const datetime = timeEl.getAttribute('datetime');
        if (datetime) return { date: datetime, source: 'HTML5 time element' };
      }
      return null;
    },
    
    // Data attributes
    () => {
      const dataDate = document.querySelector('[data-published]') ||
                      document.querySelector('[data-pubdate]') ||
                      document.querySelector('[data-date-published]');
      if (dataDate) {
        const date = dataDate.getAttribute('data-published') ||
                    dataDate.getAttribute('data-pubdate') ||
                    dataDate.getAttribute('data-date-published');
        if (date) return { date, source: 'Data attribute' };
      }
      return null;
    },
    
    // WordPress specific
    () => {
      const wpDate = document.querySelector('.entry-date, .published, .post-date');
      if (wpDate) {
        const datetime = wpDate.getAttribute('datetime') || wpDate.getAttribute('title');
        if (datetime) return { date: datetime, source: 'WordPress date element' };
        const text = wpDate.textContent.trim();
        if (text) {
          const parsed = new Date(text);
          if (!isNaN(parsed.getTime())) return { date: parsed.toISOString(), source: 'WordPress date text' };
        }
      }
      return null;
    },
    
    // URL pattern (YYYY/MM/DD or similar)
    () => {
      const url = window.location.href;
      const patterns = [
        /(\d{4})\/(\d{2})\/(\d{2})/,
        /(\d{4})-(\d{2})-(\d{2})/,
        /(\d{4})\/(\d{2})/,
      ];
      for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match) {
          try {
            const dateStr = match[0].replace(/\//g, '-');
            const date = new Date(dateStr);
            if (!isNaN(date.getTime())) {
              return { date: date.toISOString(), source: 'URL pattern' };
            }
          } catch (e) {
            // Invalid date
          }
        }
      }
      return null;
    },
    
    // Content analysis - look for date patterns in article content
    () => {
      const article = document.querySelector('article, main, [role="main"]');
      if (article) {
        const text = article.textContent;
        // Look for patterns like "Published: March 15, 2024" or "Date: 2024-03-15"
        const datePatterns = [
          /(?:published|date|posted)[:\s]+([A-Za-z]+\s+\d{1,2},?\s+\d{4})/i,
          /(\d{1,2}\/\d{1,2}\/\d{4})/,
          /(\d{4}-\d{2}-\d{2})/,
        ];
        for (const pattern of datePatterns) {
          const match = text.match(pattern);
          if (match) {
            try {
              const date = new Date(match[1]);
              if (!isNaN(date.getTime())) {
                return { date: date.toISOString(), source: 'Content analysis' };
              }
            } catch (e) {
              // Invalid date
            }
          }
        }
      }
      return null;
    },
    
    // Aggressive text scanning - scan visible elements for date patterns
    () => {
      // Get all visible text elements, prioritizing top of page
      const selectors = [
        'h1, h2, h3, h4, h5, h6',  // Headings
        'header',                   // Header sections
        'p',                        // Paragraphs
        'div',                      // Divs
        'span',                     // Spans
        'time',                     // Time elements (even without datetime)
        '[class*="date"]',          // Elements with "date" in class
        '[class*="published"]',     // Elements with "published" in class
        '[id*="date"]',             // Elements with "date" in id
        '[id*="published"]'         // Elements with "published" in id
      ];
      
      // Collect elements, avoiding duplicates using Set
      const elementSet = new Set();
      for (const selector of selectors) {
        const found = document.querySelectorAll(selector);
        found.forEach(el => elementSet.add(el));
      }
      
      // Convert to array and sort by position on page (top to bottom)
      const elements = Array.from(elementSet);
      elements.sort((a, b) => {
        const rectA = a.getBoundingClientRect();
        const rectB = b.getBoundingClientRect();
        return rectA.top - rectB.top;
      });
      
      // Comprehensive date patterns
      const datePatterns = [
        // "Nov 17, 2025" or "November 17, 2025" or "Nov 17 2025"
        /\b([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{4})\b/,
        // "17 Nov 2025" or "17 November 2025"
        /\b(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})\b/,
        // "2025-11-17" or "2025/11/17"
        /\b(\d{4})[-/](\d{1,2})[-/](\d{1,2})\b/,
        // "11/17/2025" or "11-17-2025" (US format)
        /\b(\d{1,2})[-/](\d{1,2})[-/](\d{4})\b/,
        // "17/11/2025" or "17-11-2025" (EU format)
        /\b(\d{1,2})[-/](\d{1,2})[-/](\d{4})\b/,
        // ISO format with time
        /\b(\d{4}-\d{2}-\d{2})T?\d{0,2}:?\d{0,2}:?\d{0,2}/,
      ];
      
      // Check elements from top to bottom, limit to first 50 to avoid performance issues
      for (let i = 0; i < Math.min(elements.length, 50); i++) {
        const element = elements[i];
        const text = element.textContent.trim();
        
        // Skip if element is too large (likely contains entire page content)
        if (text.length > 5000) continue;
        
        // Skip if element is not visible
        const rect = element.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) continue;
        
        for (const pattern of datePatterns) {
          const match = text.match(pattern);
          if (match) {
            try {
              let dateStr = match[0];
              
              // Try to parse the date
              const date = new Date(dateStr);
              
              // Validate: date should be reasonable (not too far in past/future)
              const now = new Date();
              const yearDiff = Math.abs(date.getFullYear() - now.getFullYear());
              
              // Accept dates between 1990 and 2100
              if (!isNaN(date.getTime()) && 
                  date.getFullYear() >= 1990 && 
                  date.getFullYear() <= 2100 &&
                  yearDiff < 150) {
                return { date: date.toISOString(), source: 'Text element scanning' };
              }
            } catch (e) {
              // Invalid date, continue
            }
          }
        }
      }
      
      return null;
    }
  ];

  // Try each detector in order
  for (const detector of dateDetectors) {
    try {
      const result = detector();
      if (result && result.date) {
        return result;
      }
    } catch (e) {
      // Continue to next detector
    }
  }

  return { date: null, source: null };
}

