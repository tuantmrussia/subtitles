// Popup Script - Table Display Only

// State
let extractedTables = [];
let extractedLinks = [];
let fileTypeCounts = {
  htm: 0,
  xml: 0,
  jpg: 0,
  gif: 0,
  png: 0
};
// DOM Elements
const elements = {
  tableCount: document.getElementById('tableCount'),
  tablesList: document.getElementById('tablesList'),
  exportTablesBtn: document.getElementById('exportTablesBtn'),
  loadingMessage: document.getElementById('loadingMessage'),
  noTablesMessage: document.getElementById('noTablesMessage'),
  // Quick Download Dialog elements
  quickDownloadCheckboxes: document.querySelectorAll('.file-type-checkbox input[type="checkbox"]'),
  fileCounts: document.querySelectorAll('.file-count'),
  quickDownloadDirectory: document.getElementById('quickDownloadDirectory'),
  addItemsToListBtn: document.getElementById('addItemsToListBtn'),
  downloadNowBtn: document.getElementById('downloadNowBtn'),
  itemCounts: document.querySelectorAll('.item-count'),
  // Scraping mode elements
  toggleScrapingModeBtn: document.getElementById('toggleScrapingModeBtn')
};

// Initialize - automatically load tables when popup opens
document.addEventListener('DOMContentLoaded', async () => {
  await loadQuickDownloadLinks();
  await loadTables();
  setupQuickDownloadHandlers();
  setupScrapingModeHandlers();
});

// Quick Download Dialog Functions
async function loadQuickDownloadLinks() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) return;

    const tab = tabs[0];
    if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
      return;
    }

    // Extract links from the page
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractLinksFromPage
    });

    if (results && results[0] && results[0].result) {
      extractedLinks = results[0].result;
      updateFileTypeCounts();
      updateQuickDownloadUI();
    }
  } catch (error) {
    console.error('Error loading quick download links:', error);
  }
}

function extractLinksFromPage() {
  const links = [];
  const seen = new Set();
  const baseUrl = window.location.href;

  // Extract <a> tags
  document.querySelectorAll('a[href]').forEach(anchor => {
    const href = anchor.getAttribute('href');
    if (href) {
      try {
        const absoluteUrl = new URL(href, baseUrl).href;
        if (!seen.has(absoluteUrl) && !absoluteUrl.startsWith('javascript:') && 
            !absoluteUrl.startsWith('mailto:') && !absoluteUrl.startsWith('tel:')) {
          seen.add(absoluteUrl);
          links.push(absoluteUrl);
        }
      } catch (e) {
        // Invalid URL, skip
      }
    }
  });

  // Extract <img> tags
  document.querySelectorAll('img[src], img[data-src]').forEach(img => {
    const src = img.getAttribute('src') || img.getAttribute('data-src');
    if (src) {
      try {
        const absoluteUrl = new URL(src, baseUrl).href;
        if (!seen.has(absoluteUrl)) {
          seen.add(absoluteUrl);
          links.push(absoluteUrl);
        }
      } catch (e) {
        // Invalid URL, skip
      }
    }
  });

  // Extract <link> tags (for stylesheets, etc.)
  document.querySelectorAll('link[href]').forEach(link => {
    const href = link.getAttribute('href');
    if (href) {
      try {
        const absoluteUrl = new URL(href, baseUrl).href;
        if (!seen.has(absoluteUrl)) {
          seen.add(absoluteUrl);
          links.push(absoluteUrl);
        }
      } catch (e) {
        // Invalid URL, skip
      }
    }
  });

  return links;
}

function getFileExtension(url) {
  try {
    const urlObj = new URL(url);
    const pathname = urlObj.pathname;
    const extension = pathname.split('.').pop().toLowerCase();
    return extension.split('?')[0]; // Remove query parameters
  } catch (e) {
    return '';
  }
}

function updateFileTypeCounts() {
  // Reset counts
  fileTypeCounts = {
    htm: 0,
    xml: 0,
    jpg: 0,
    gif: 0,
    png: 0
  };

  // Count files by type
  extractedLinks.forEach(url => {
    const ext = getFileExtension(url);
    if (ext === 'htm' || ext === 'html') {
      fileTypeCounts.htm++;
    } else if (ext === 'xml') {
      fileTypeCounts.xml++;
    } else if (ext === 'jpg' || ext === 'jpeg') {
      fileTypeCounts.jpg++;
    } else if (ext === 'gif') {
      fileTypeCounts.gif++;
    } else if (ext === 'png') {
      fileTypeCounts.png++;
    }
  });
}

function updateQuickDownloadUI() {
  // Update file counts
  elements.fileCounts.forEach(countEl => {
    const type = countEl.getAttribute('data-type');
    if (fileTypeCounts[type] !== undefined) {
      countEl.textContent = fileTypeCounts[type];
    }
  });

  // Update button counts
  const selectedCount = getSelectedLinks().length;
  elements.itemCounts.forEach(itemCount => {
    itemCount.textContent = `[${selectedCount}]`;
  });
}

function getSelectedFileTypes() {
  const selected = [];
  elements.quickDownloadCheckboxes.forEach(checkbox => {
    if (checkbox.checked) {
      const type = checkbox.getAttribute('data-type');
      selected.push(type);
    }
  });
  return selected;
}

function getSelectedLinks() {
  const selectedTypes = getSelectedFileTypes();
  const selectedLinks = [];

  extractedLinks.forEach(url => {
    const ext = getFileExtension(url);
    let matches = false;

    if (selectedTypes.includes('htm') && (ext === 'htm' || ext === 'html')) {
      matches = true;
    } else if (selectedTypes.includes('xml') && ext === 'xml') {
      matches = true;
    } else if (selectedTypes.includes('jpg') && (ext === 'jpg' || ext === 'jpeg')) {
      matches = true;
    } else if (selectedTypes.includes('gif') && ext === 'gif') {
      matches = true;
    } else if (selectedTypes.includes('png') && ext === 'png') {
      matches = true;
    }

    if (matches) {
      selectedLinks.push(url);
    }
  });

  return selectedLinks;
}

function setupQuickDownloadHandlers() {
  // Update counts when checkboxes change
  elements.quickDownloadCheckboxes.forEach(checkbox => {
    checkbox.addEventListener('change', () => {
      updateQuickDownloadUI();
    });
  });

  // Handle "ADD ITEMS TO LIST" button
  elements.addItemsToListBtn.addEventListener('click', handleAddItemsToList);

  // Handle "DOWNLOAD NOW" button
  elements.downloadNowBtn.addEventListener('click', handleDownloadNow);
}

async function handleAddItemsToList() {
  const selectedLinks = getSelectedLinks();
  if (selectedLinks.length === 0) {
    showToast('No files selected', 'error');
    return;
  }

  try {
    // Get existing download queue from storage
    const storage = await chrome.storage.local.get(['downloadQueue']);
    const queue = storage.downloadQueue || [];

    // Add new items to queue
    const directory = elements.quickDownloadDirectory.value.trim();
    selectedLinks.forEach(url => {
      queue.push({
        url,
        filename: url.split('/').pop(),
        directory: directory || undefined,
        timestamp: Date.now()
      });
    });

    // Save updated queue
    await chrome.storage.local.set({ downloadQueue: queue });
    showToast(`Added ${selectedLinks.length} item(s) to download queue`);
  } catch (error) {
    console.error('Error adding items to list:', error);
    showToast('Error adding items to list: ' + error.message, 'error');
  }
}

async function handleDownloadNow() {
  const selectedLinks = getSelectedLinks();
  if (selectedLinks.length === 0) {
    showToast('No files selected', 'error');
    return;
  }

  try {
    const directory = elements.quickDownloadDirectory.value.trim();
    let downloadCount = 0;

    for (const url of selectedLinks) {
      try {
        const filename = url.split('/').pop().split('?')[0];
        const downloadOptions = {
          url: url,
          filename: directory ? `${directory}/${filename}` : filename,
          saveAs: false
        };

        await chrome.downloads.download(downloadOptions);
        downloadCount++;
      } catch (error) {
        console.error(`Error downloading ${url}:`, error);
      }
    }

    showToast(`Started downloading ${downloadCount} file(s)`);
  } catch (error) {
    console.error('Error downloading files:', error);
    showToast('Error downloading files: ' + error.message, 'error');
  }
}

async function loadTables() {
  elements.loadingMessage.style.display = 'block';
  elements.tablesList.style.display = 'none';
  elements.exportTablesBtn.style.display = 'none';
  elements.noTablesMessage.style.display = 'none';

  try {
    // Get current active tab
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) {
      showNoTables();
      return;
    }

    const tabId = tabs[0].id;
    const tab = tabs[0];

    // Check if we can access the tab
    if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
      showNoTables('Cannot extract from Chrome internal pages');
      return;
    }

    // Try to get tables from storage first (from automatic extraction)
    const storageData = await chrome.storage.local.get(['currentPageTables', 'currentPageUrl']);
    if (storageData.currentPageTables && storageData.currentPageUrl === tab.url) {
      extractedTables = storageData.currentPageTables;
      if (extractedTables.length > 0) {
        displayTables();
        elements.loadingMessage.style.display = 'none';
        return;
      }
    }

    // If not in storage, extract directly
    let response = null;
    try {
      response = await chrome.tabs.sendMessage(tabId, { action: 'extractTables' });
    } catch (error) {
      // Content script might not be loaded, use fallback
      console.log('Content script not available, using fallback method');
    }
    
    if (response && response.success && response.tables) {
      extractedTables = response.tables;
      displayTables();
      elements.loadingMessage.style.display = 'none';
      return;
    }

    // Fallback: Try to inject content script and retry
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['content/content-script.js']
      });
      
      await new Promise(resolve => setTimeout(resolve, 200));
      
      try {
        response = await chrome.tabs.sendMessage(tabId, { action: 'extractTables' });
        if (response && response.success && response.tables) {
          extractedTables = response.tables;
          displayTables();
          elements.loadingMessage.style.display = 'none';
          return;
        }
      } catch (e) {
        console.log('Message still failed after injection, using inline extraction');
      }
    } catch (injectError) {
      console.log('Could not inject content script, using inline extraction');
    }

    // Final fallback: Inline extraction
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: extractTablesInline
    });

    if (results && results.length > 0 && results[0] && Array.isArray(results[0].result)) {
      extractedTables = results[0].result;
      if (extractedTables.length > 0) {
        displayTables();
        elements.loadingMessage.style.display = 'none';
      } else {
        showNoTables();
      }
    } else {
      showNoTables();
    }
  } catch (error) {
    console.error('Error loading tables:', error);
    showNoTables('Error loading tables: ' + (error.message || 'Unknown error'));
  }
}

function showNoTables(message = 'No tables found on this page.') {
  elements.loadingMessage.style.display = 'none';
  elements.tablesList.style.display = 'none';
  elements.exportTablesBtn.style.display = 'none';
  elements.noTablesMessage.style.display = 'block';
  elements.noTablesMessage.textContent = message;
  elements.tableCount.textContent = '0';
}

function displayTables() {
  elements.tableCount.textContent = extractedTables.length.toString();
  
  if (extractedTables.length === 0) {
    showNoTables();
    return;
  }

  elements.tablesList.style.display = 'block';
  elements.exportTablesBtn.style.display = 'block';
  elements.tablesList.innerHTML = '';

  extractedTables.forEach((table, index) => {
    const item = document.createElement('div');
    item.className = 'table-item';
    item.dataset.index = index;

    const title = document.createElement('div');
    title.className = 'table-title';
    title.textContent = table.title || `Table ${index + 1}`;

    const info = document.createElement('div');
    info.className = 'table-info';
    info.textContent = `${table.rowCount} rows × ${table.columnCount} columns`;

    item.appendChild(title);
    item.appendChild(info);
    
    item.addEventListener('click', () => {
      // Export single table
      try {
        ExcelExporter.exportTableToExcel(table, `${table.title || `table_${index + 1}`}.xlsx`);
        showToast(`Exported ${table.title}`);
      } catch (error) {
        showToast('Error exporting table: ' + error.message, 'error');
      }
    });

    elements.tablesList.appendChild(item);
  });
}

// Export all tables button
elements.exportTablesBtn.addEventListener('click', handleExportTables);

function handleExportTables() {
  if (extractedTables.length === 0) {
    showToast('No tables to export', 'error');
    return;
  }

  try {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      const pageTitle = tab.title || 'tables';
      const filename = `${pageTitle.replace(/[^a-z0-9]/gi, '_').substring(0, 50)}_tables.xlsx`;
      
      ExcelExporter.exportTablesToExcel(extractedTables, filename);
      showToast(`Exported ${extractedTables.length} table(s) to Excel`);
    });
  } catch (error) {
    console.error('Error exporting tables:', error);
    showToast('Error exporting tables: ' + error.message, 'error');
  }
}

function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = `toast show ${type}`;
  
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

// ==================== Scraping Mode Functions ====================

function setupScrapingModeHandlers() {
  // Start scraping mode button - closes popup and enables scraping
  elements.toggleScrapingModeBtn.addEventListener('click', startScrapingMode);
}

async function startScrapingMode() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) {
      showToast('No active tab found', 'error');
      return;
    }

    const tab = tabs[0];
    if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
      showToast('Cannot scrape Chrome internal pages', 'error');
      return;
    }

    // Send message to content script to enable scraping mode
    try {
      await chrome.tabs.sendMessage(tab.id, {
        action: 'toggleScrapingMode',
        enabled: true
      });
    } catch (error) {
      // Content script might not be loaded, try to inject it
      console.log('Content script not available, injecting...');
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content/content-script.js']
      });
      
      await new Promise(resolve => setTimeout(resolve, 200));
      
      await chrome.tabs.sendMessage(tab.id, {
        action: 'toggleScrapingMode',
        enabled: true
      });
    }
    
    // Close the popup window
    window.close();
  } catch (error) {
    console.error('Error starting scraping mode:', error);
    showToast('Error starting scraping mode: ' + error.message, 'error');
  }
}

// Inline table extraction function (fallback when content script unavailable)
function extractTablesInline() {
  const allTables = document.querySelectorAll('table');
  const topLevelTables = Array.from(allTables).filter(table => {
    let parent = table.parentElement;
    while (parent && parent !== document.body) {
      if (parent.tagName === 'TABLE') {
        return false;
      }
      parent = parent.parentElement;
    }
    return true;
  });

  const tables = [];
  
  topLevelTables.forEach((tableElement, index) => {
    try {
      const style = window.getComputedStyle(tableElement);
      if (style.display === 'none' || style.visibility === 'hidden') {
        return;
      }

      const rows = [];
      const headers = [];
      
      const thead = tableElement.querySelector('thead');
      const headerRows = [];
      
      if (thead) {
        const theadRows = thead.querySelectorAll('tr');
        theadRows.forEach(row => {
          if (row.offsetParent !== null) {
            headerRows.push(row);
          }
        });
      }
      
      if (headerRows.length === 0) {
        const allRows = tableElement.querySelectorAll('tr');
        for (let i = 0; i < Math.min(3, allRows.length); i++) {
          const row = allRows[i];
          if (row.offsetParent === null) continue;
          const thCount = row.querySelectorAll('th').length;
          const tdCount = row.querySelectorAll('td').length;
          if (thCount > 0 && thCount >= tdCount) {
            headerRows.push(row);
          } else if (headerRows.length > 0) {
            break;
          }
        }
      }
      
      if (headerRows.length > 0) {
        const headerCells = [];
        headerRows.forEach(headerRow => {
          const cells = headerRow.querySelectorAll('th, td');
          cells.forEach(cell => {
            if (cell.offsetParent !== null) {
              const text = cleanCellTextInline(cell);
              const colspan = parseInt(cell.getAttribute('colspan') || '1');
              headerCells.push(text);
              for (let i = 1; i < colspan; i++) {
                headerCells.push('');
              }
            }
          });
        });
        if (headerCells.length > headers.length) {
          headers.length = 0;
          headers.push(...headerCells);
        }
      }
      
      const tbody = tableElement.querySelector('tbody') || tableElement;
      const allRows = Array.from(tbody.querySelectorAll('tr'));
      const activeRowspans = new Map();
      
      allRows.forEach((row) => {
        if (headerRows.includes(row)) return;
        if (row.offsetParent === null) return;
        
        const rowClass = row.className || '';
        if (rowClass.includes('navbox') || rowClass.includes('metadata') || 
            rowClass.includes('mw-empty-elt') || rowClass.includes('sortbottom')) {
          return;
        }
        
        const cells = Array.from(row.querySelectorAll('td, th'));
        if (cells.length === 0) return;
        
        const rowData = [];
        let colIndex = 0;
        
        cells.forEach(cell => {
          if (cell.offsetParent === null) return;
          
          while (activeRowspans.has(colIndex)) {
            const rowspan = activeRowspans.get(colIndex);
            rowData.push(rowspan.value);
            rowspan.remainingRows--;
            if (rowspan.remainingRows <= 0) {
              activeRowspans.delete(colIndex);
            }
            colIndex++;
          }
          
          const text = cleanCellTextInline(cell);
          const colspan = parseInt(cell.getAttribute('colspan') || '1');
          const rowspan = parseInt(cell.getAttribute('rowspan') || '1');
          
          rowData.push(text);
          colIndex++;
          
          for (let i = 1; i < colspan; i++) {
            while (activeRowspans.has(colIndex)) {
              const rowspan = activeRowspans.get(colIndex);
              rowData.push(rowspan.value);
              rowspan.remainingRows--;
              if (rowspan.remainingRows <= 0) {
                activeRowspans.delete(colIndex);
              }
              colIndex++;
            }
            rowData.push('');
            colIndex++;
          }
          
          if (rowspan > 1) {
            const startCol = colIndex - colspan;
            for (let i = 0; i < colspan; i++) {
              const col = startCol + i;
              activeRowspans.set(col, {
                value: i === 0 ? text : '',
                remainingRows: rowspan - 1
              });
            }
          }
        });
        
        const maxCol = Math.max(...Array.from(activeRowspans.keys()).concat([colIndex - 1]));
        while (colIndex <= maxCol && activeRowspans.has(colIndex)) {
          const rowspan = activeRowspans.get(colIndex);
          rowData.push(rowspan.value);
          rowspan.remainingRows--;
          if (rowspan.remainingRows <= 0) {
            activeRowspans.delete(colIndex);
          }
          colIndex++;
        }
        
        if (rowData.length > 0) {
          rows.push(rowData);
        }
      });
      
      if (headers.length === 0 && rows.length > 0) {
        const maxColCount = Math.max(...rows.map(r => r.length));
        for (let i = 0; i < maxColCount; i++) {
          headers.push(`Column ${i + 1}`);
        }
      }
      
      const normalizedRows = rows.map(row => {
        const normalized = [...row];
        while (normalized.length < headers.length) {
          normalized.push('');
        }
        return normalized.slice(0, headers.length);
      });
      
      const caption = tableElement.querySelector('caption');
      let title = caption ? cleanCellTextInline(caption) : `Table ${index + 1}`;
      
      if (!caption || title === `Table ${index + 1}`) {
        let prevSibling = tableElement.previousElementSibling;
        let attempts = 0;
        while (prevSibling && attempts < 3) {
          if (prevSibling.tagName && prevSibling.tagName.match(/^H[1-6]$/)) {
            title = cleanCellTextInline(prevSibling);
            break;
          }
          prevSibling = prevSibling.previousElementSibling;
          attempts++;
        }
      }
      
      if (normalizedRows.length > 0) {
        tables.push({
          index,
          title: title.trim() || `Table ${index + 1}`,
          headers: headers.length > 0 ? headers : Array(normalizedRows[0].length).fill(0).map((_, i) => `Column ${i + 1}`),
          rows: normalizedRows,
          columnCount: headers.length || (normalizedRows[0] ? normalizedRows[0].length : 0),
          rowCount: normalizedRows.length
        });
      }
    } catch (e) {
      console.warn('Error extracting table:', e);
    }
  });
  
  return tables;
  
  function cleanCellTextInline(cell) {
    if (!cell || cell.offsetParent === null) return '';
    
    const nestedTable = cell.querySelector('table');
    if (nestedTable) return '[Nested Table]';
    
    const clone = cell.cloneNode(true);
    ['script', 'style', 'noscript', '.reference', '.mw-references-wrap',
     '.mw-editsection', '.sortkey', '.sorttext', '.hidden', '[style*="display:none"]'].forEach(selector => {
      clone.querySelectorAll(selector).forEach(el => el.remove());
    });
    
    clone.querySelectorAll('img').forEach(img => {
      const alt = img.getAttribute('alt') || img.getAttribute('title') || '';
      if (alt) {
        const textNode = document.createTextNode(`[Image: ${alt}]`);
        img.parentNode.replaceChild(textNode, img);
      } else {
        img.remove();
      }
    });
    
    clone.querySelectorAll('a').forEach(link => {
      const linkText = link.textContent.trim();
      const href = link.getAttribute('href') || '';
      const title = link.getAttribute('title') || '';
      if (!linkText || linkText === href) {
        if (title) {
          link.textContent = title;
        } else if (href && !href.startsWith('#')) {
          const hrefText = href.split('/').pop().replace(/_/g, ' ');
          link.textContent = decodeURIComponent(hrefText);
        }
      }
    });
    
    clone.querySelectorAll('sup, sub').forEach(el => {
      const text = el.textContent.trim();
      if (text) {
        el.textContent = `(${text})`;
      }
    });
    
    let text = clone.textContent || clone.innerText || '';
    text = text.replace(/\s+/g, ' ').trim();
    text = text.replace(/\[\d+\]/g, '');
    text = text.replace(/\[edit\]/g, '');
    text = text.replace(/\[show\]/g, '');
    text = text.replace(/\s{2,}/g, ' ').trim();
    
    return text;
  }
}
