// Content Script for Automatic Table Extraction

// Automatically extract tables when page loads
let extractedTables = null;

function extractTablesOnLoad() {
  try {
    extractedTables = extractTablesFromPage();
    // Store tables in storage for popup to access
    chrome.storage.local.set({ 
      currentPageTables: extractedTables,
      currentPageUrl: window.location.href
    });
  } catch (error) {
    console.error('Error extracting tables:', error);
  }
}

// Extract tables when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', extractTablesOnLoad);
} else {
  extractTablesOnLoad();
}

// Also extract tables when page content changes (for SPAs)
let lastUrl = window.location.href;
let extractionTimeout = null;

function debouncedExtractTables() {
  const currentUrl = window.location.href;
  if (currentUrl !== lastUrl) {
    lastUrl = currentUrl;
    if (extractionTimeout) {
      clearTimeout(extractionTimeout);
    }
    extractionTimeout = setTimeout(extractTablesOnLoad, 1000); // Wait a bit for content to load
  }
}

// Monitor URL changes for SPAs
const urlObserver = new MutationObserver(debouncedExtractTables);
if (document.body) {
  urlObserver.observe(document.body, { childList: true, subtree: false });
}

// Also listen for popstate events (back/forward navigation)
window.addEventListener('popstate', () => {
  debouncedExtractTables();
});

// Scraping mode state
let scrapingModeActive = false;
let scrapingModePaused = false; // Track if scraping is temporarily paused (e.g., when hovering sidebar)
let highlightOverlay = null;
let selectedElement = null;
let sidebarPanel = null;
let similarElementsList = [];

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'extractTables') {
    try {
      const tables = extractTablesFromPage();
      sendResponse({ success: true, tables });
    } catch (error) {
      sendResponse({ success: false, error: error.message });
    }
    return true; // Keep channel open for async response
  }
  
  if (message.action === 'toggleScrapingMode') {
    scrapingModeActive = message.enabled;
    if (scrapingModeActive) {
      enableScrapingMode();
    } else {
      disableScrapingMode();
    }
    sendResponse({ success: true });
    return true;
  }
  
  if (message.action === 'extractElementData') {
    try {
      const selector = message.selector;
      const element = document.querySelector(selector);
      if (element) {
        const data = extractElementData(element);
        sendResponse({ success: true, data });
      } else {
        sendResponse({ success: false, error: 'Element not found' });
      }
    } catch (error) {
      sendResponse({ success: false, error: error.message });
    }
    return true;
  }
  
  return false;
});

/**
 * Enable scraping mode - allows user to select elements
 */
function enableScrapingMode() {
  // Create overlay for highlighting
  highlightOverlay = document.createElement('div');
  highlightOverlay.id = 'scraper-highlight-overlay';
  highlightOverlay.style.cssText = `
    position: fixed;
    border: 2px solid #2196F3;
    background: rgba(33, 150, 243, 0.1);
    pointer-events: none;
    z-index: 999998;
    display: none;
    box-sizing: border-box;
  `;
  document.body.appendChild(highlightOverlay);
  
  // Add hover and click listeners
  document.addEventListener('mousemove', handleMouseMove, true);
  document.addEventListener('click', handleElementClick, true);
  document.addEventListener('keydown', handleKeyPress, true);
  
  // Change cursor
  document.body.style.cursor = 'crosshair';
  
  // Add instruction banner (keep it visible)
  showScrapingBanner();
  
  // Create sidebar panel
  createSidebarPanel();
}

/**
 * Disable scraping mode
 */
function disableScrapingMode() {
  // Remove overlay
  if (highlightOverlay) {
    highlightOverlay.remove();
    highlightOverlay = null;
  }
  
  // Remove event listeners
  document.removeEventListener('mousemove', handleMouseMove, true);
  document.removeEventListener('click', handleElementClick, true);
  document.removeEventListener('keydown', handleKeyPress, true);
  
  // Reset cursor
  document.body.style.cursor = '';
  
  // Remove banner
  hideScrapingBanner();
  
  // Remove sidebar panel
  removeSidebarPanel();
  
  // Clear selected element
  selectedElement = null;
  similarElementsList = [];
}

/**
 * Temporarily pause scraping mode (e.g., when hovering sidebar)
 */
function pauseScrapingMode() {
  if (!scrapingModeActive || scrapingModePaused) return;
  
  scrapingModePaused = true;
  
  // Hide overlay
  if (highlightOverlay) {
    highlightOverlay.style.display = 'none';
  }
  
  // Remove event listeners temporarily
  document.removeEventListener('mousemove', handleMouseMove, true);
  document.removeEventListener('click', handleElementClick, true);
  
  // Change cursor back to normal
  document.body.style.cursor = '';
  
  // Update banner with paused state (change color to orange)
  const banner = document.getElementById('scraper-banner');
  if (banner) {
    banner.style.background = '#FF9800';
    banner.textContent = 'Scraping Mode Paused - Hovering Sidebar | Move mouse away to resume';
  }
}

/**
 * Resume scraping mode (e.g., when leaving sidebar)
 */
function resumeScrapingMode() {
  if (!scrapingModeActive || !scrapingModePaused) return;
  
  scrapingModePaused = false;
  
  // Re-add event listeners
  document.addEventListener('mousemove', handleMouseMove, true);
  document.addEventListener('click', handleElementClick, true);
  
  // Change cursor back to crosshair
  document.body.style.cursor = 'crosshair';
  
  // Update banner with active state
  const banner = document.getElementById('scraper-banner');
  if (banner) {
    // Check if we're in selecting mode (similar elements found)
    if (similarElementsList.length > 0) {
      updateScrapingBannerForSelecting();
    } else {
      banner.style.background = '#2196F3';
      banner.textContent = 'Selecting Mode Active - Click on any element to find similar elements | Press ESC to exit';
    }
  }
}

/**
 * Update scraping banner text dynamically
 */
function updateScrapingBanner(text) {
  let banner = document.getElementById('scraper-banner');
  if (banner) {
    banner.textContent = text;
  } else {
    // Create banner if it doesn't exist
    showScrapingBanner();
    banner = document.getElementById('scraper-banner');
    if (banner) {
      banner.textContent = text;
    }
  }
}

/**
 * Handle mouse movement to highlight elements
 */
function handleMouseMove(e) {
  if (!scrapingModeActive || scrapingModePaused) return;
  
  e.stopPropagation();
  const element = e.target;
  
  // Skip if hovering over overlay, banner, or sidebar
  if (element.id === 'scraper-highlight-overlay' || element.id === 'scraper-banner' ||
      element.closest('#scraper-sidebar')) {
    return;
  }
  
  // Skip script, style, and other non-content elements
  if (element.tagName === 'SCRIPT' || element.tagName === 'STYLE' || 
      element.tagName === 'NOSCRIPT' || element.id === 'scraper-banner') {
    return;
  }
  
  const rect = element.getBoundingClientRect();
  highlightOverlay.style.display = 'block';
  highlightOverlay.style.left = `${rect.left + window.scrollX}px`;
  highlightOverlay.style.top = `${rect.top + window.scrollY}px`;
  highlightOverlay.style.width = `${rect.width}px`;
  highlightOverlay.style.height = `${rect.height}px`;
}

/**
 * Handle element click to select and extract
 */
function handleElementClick(e) {
  if (!scrapingModeActive || scrapingModePaused) return;
  
  e.preventDefault();
  e.stopPropagation();
  
  const element = e.target;
  
  // Skip if clicking on overlay, banner, or sidebar
  if (element.id === 'scraper-highlight-overlay' || element.id === 'scraper-banner' ||
      element.closest('#scraper-sidebar')) {
    return;
  }
  
  // Skip script, style, and other non-content elements
  if (element.tagName === 'SCRIPT' || element.tagName === 'STYLE' || 
      element.tagName === 'NOSCRIPT') {
    return;
  }
  
  selectedElement = element;
  const selector = generateSelector(element);
  const data = extractElementData(element);
  
  const scrapedItem = {
    id: Date.now(),
    timestamp: new Date().toISOString(),
    selector: selector,
    tagName: element.tagName,
    className: element.className || '',
    elementId: element.id || '',
    data: data
  };
  
  // Save to storage
  saveScrapedItemToStorage(scrapedItem);
  
  // Send data to popup (if it's open)
  chrome.runtime.sendMessage({
    action: 'elementScraped',
    selector: selector,
    data: data,
    tagName: element.tagName,
    className: element.className || '',
    id: element.id || ''
  }).catch(() => {
    // Popup might be closed, that's okay
  });
  
  // Visual feedback
  showSelectionFeedback(element);
  
  // Find similar elements (but don't scrape automatically - let user choose)
  findSimilarElements(element);
}

/**
 * Handle key press (ESC to exit scraping mode)
 */
function handleKeyPress(e) {
  if (!scrapingModeActive) return;
  
  if (e.key === 'Escape') {
    e.preventDefault();
    e.stopPropagation();
    scrapingModeActive = false;
    disableScrapingMode();
    
    // Notify popup if it's open
    chrome.runtime.sendMessage({
      action: 'scrapingModeDisabled'
    }).catch(() => {
      // Popup might be closed, that's okay
    });
  }
}

/**
 * Generate a CSS selector for an element
 */
function generateSelector(element) {
  if (element.id) {
    return `#${element.id}`;
  }
  
  if (element.className) {
    const classes = element.className.split(' ').filter(c => c).join('.');
    if (classes) {
      const tagName = element.tagName.toLowerCase();
      const selector = `${tagName}.${classes}`;
      // Check if selector is unique
      if (document.querySelectorAll(selector).length === 1) {
        return selector;
      }
    }
  }
  
  // Use path-based selector
  const path = [];
  let current = element;
  while (current && current !== document.body) {
    let selector = current.tagName.toLowerCase();
    if (current.id) {
      selector += `#${current.id}`;
      path.unshift(selector);
      break;
    }
    if (current.className) {
      const classes = current.className.split(' ').filter(c => c).slice(0, 1).join('.');
      if (classes) {
        selector += `.${classes}`;
      }
    }
    
    const siblings = Array.from(current.parentElement?.children || []);
    const index = siblings.indexOf(current);
    if (siblings.length > 1) {
      selector += `:nth-child(${index + 1})`;
    }
    
    path.unshift(selector);
    current = current.parentElement;
  }
  
  return path.join(' > ');
}

/**
 * Extract data from an element
 */
function extractElementData(element) {
  const data = {
    tagName: element.tagName.toLowerCase(),
    text: '',
    html: '',
    attributes: {},
    children: [],
    links: [],
    images: []
  };
  
  // Extract text content (cleaned)
  const clone = element.cloneNode(true);
  ['script', 'style', 'noscript'].forEach(tag => {
    clone.querySelectorAll(tag).forEach(el => el.remove());
  });
  data.text = clone.textContent.trim().replace(/\s+/g, ' ');
  
  // Extract HTML (limited to prevent huge data)
  if (clone.innerHTML.length < 10000) {
    data.html = clone.innerHTML;
  } else {
    data.html = '[Content too large]';
  }
  
  // Extract attributes
  Array.from(element.attributes).forEach(attr => {
    data.attributes[attr.name] = attr.value;
  });
  
  // Extract links
  clone.querySelectorAll('a[href]').forEach(link => {
    const href = link.getAttribute('href');
    const text = link.textContent.trim();
    if (href && !href.startsWith('javascript:')) {
      try {
        const absoluteUrl = new URL(href, window.location.href).href;
        data.links.push({
          url: absoluteUrl,
          text: text || href
        });
      } catch (e) {
        data.links.push({
          url: href,
          text: text || href
        });
      }
    }
  });
  
  // Extract images
  clone.querySelectorAll('img[src], img[data-src]').forEach(img => {
    const src = img.getAttribute('src') || img.getAttribute('data-src');
    const alt = img.getAttribute('alt') || '';
    if (src) {
      try {
        const absoluteUrl = new URL(src, window.location.href).href;
        data.images.push({
          url: absoluteUrl,
          alt: alt
        });
      } catch (e) {
        data.images.push({
          url: src,
          alt: alt
        });
      }
    }
  });
  
  // Extract child elements info
  Array.from(element.children).slice(0, 20).forEach(child => {
    data.children.push({
      tagName: child.tagName.toLowerCase(),
      className: child.className || '',
      id: child.id || '',
      textPreview: child.textContent.trim().substring(0, 50)
    });
  });
  
  return data;
}

/**
 * Show visual feedback when element is selected
 */
function showSelectionFeedback(element) {
  const originalOutline = element.style.outline;
  const originalOutlineOffset = element.style.outlineOffset;
  
  element.style.outline = '3px solid #4CAF50';
  element.style.outlineOffset = '2px';
  
  setTimeout(() => {
    element.style.outline = originalOutline;
    element.style.outlineOffset = originalOutlineOffset;
  }, 1000);
}

/**
 * Show scraping mode banner (always visible when scraping mode is active)
 */
function showScrapingBanner() {
  // Remove existing banner if any
  hideScrapingBanner();
  
  const banner = document.createElement('div');
  banner.id = 'scraper-banner';
  banner.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background: #2196F3;
    color: white;
    padding: 12px;
    text-align: center;
    font-weight: 600;
    font-size: 14px;
    z-index: 999999;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    transition: background 0.3s ease;
  `;
  banner.textContent = 'Selecting Mode Active - Click on any element to find similar elements | Press ESC to exit';
  document.body.appendChild(banner);
}

/**
 * Hide scraping mode banner
 */
function hideScrapingBanner() {
  const banner = document.getElementById('scraper-banner');
  if (banner) {
    banner.remove();
  }
}

/**
 * Update banner to show selecting mode
 */
function updateScrapingBannerForSelecting() {
  let banner = document.getElementById('scraper-banner');
  if (!banner) {
    // Create banner if it doesn't exist
    showScrapingBanner();
    banner = document.getElementById('scraper-banner');
  }
  
  if (banner) {
    banner.style.background = '#4CAF50';
    banner.textContent = 'Selecting Mode Active - Select elements from sidebar and click "Scrape Selected" to download | Press ESC to exit';
  }
}

/**
 * Find similar elements and show them in sidebar (without auto-scraping)
 */
function findSimilarElements(referenceElement) {
  // Get element characteristics
  const tagName = referenceElement.tagName.toLowerCase();
  const classes = referenceElement.className ? referenceElement.className.split(' ').filter(c => c) : [];
  const parentTag = referenceElement.parentElement ? referenceElement.parentElement.tagName.toLowerCase() : '';
  const parentClasses = referenceElement.parentElement && referenceElement.parentElement.className 
    ? referenceElement.parentElement.className.split(' ').filter(c => c) 
    : [];
  
  // Find similar elements
  let similarElements = [];
  
  // Strategy 1: Same tag with same classes
  if (classes.length > 0) {
    const classSelector = `${tagName}.${classes.join('.')}`;
    similarElements = Array.from(document.querySelectorAll(classSelector));
  } else {
    // Strategy 2: Same tag with same parent structure
    if (parentTag) {
      const parentSelector = parentClasses.length > 0 
        ? `${parentTag}.${parentClasses.join('.')} > ${tagName}`
        : `${parentTag} > ${tagName}`;
      similarElements = Array.from(document.querySelectorAll(parentSelector));
    } else {
      // Strategy 3: Just same tag
      similarElements = Array.from(document.querySelectorAll(tagName));
    }
  }
  
  // Filter out the reference element and elements that are too different
  const seenElements = new Set([referenceElement]);
  similarElements = similarElements.filter(el => {
    // Skip if already seen
    if (seenElements.has(el)) return false;
    
    // Skip if element is nested inside reference element or vice versa
    if (referenceElement.contains(el) || el.contains(referenceElement)) {
      return false;
    }
    
    // Check if element structure is similar
    const elClasses = el.className ? el.className.split(' ').filter(c => c) : [];
    
    // If reference has classes, similar element should have at least one matching class
    if (classes.length > 0 && elClasses.length > 0) {
      const hasMatchingClass = classes.some(c => elClasses.includes(c));
      if (!hasMatchingClass) return false;
    }
    
    // Check if parent structure is similar
    if (parentTag && el.parentElement) {
      const elParentTag = el.parentElement.tagName.toLowerCase();
      if (elParentTag !== parentTag) {
        // Check if parent classes match
        const elParentClasses = el.parentElement.className 
          ? el.parentElement.className.split(' ').filter(c => c)
          : [];
        if (parentClasses.length > 0 && elParentClasses.length > 0) {
          const hasMatchingParentClass = parentClasses.some(c => elParentClasses.includes(c));
          if (!hasMatchingParentClass) return false;
        }
      }
    }
    
    // Check if this element is nested inside any already selected similar element
    let isNested = false;
    for (const seenEl of seenElements) {
      if (seenEl !== referenceElement && (seenEl.contains(el) || el.contains(seenEl))) {
        isNested = true;
        break;
      }
    }
    if (isNested) return false;
    
    seenElements.add(el);
    return true;
  });
  
  // Limit to reasonable number (max 50 similar elements)
  similarElements = similarElements.slice(0, 50);
  
  // Store similar elements for sidebar display
  similarElementsList = similarElements.map((el, index) => {
    const selector = generateSelector(el);
    const previewText = el.textContent ? el.textContent.trim().substring(0, 100) : '';
    return {
      element: el,
      selector: selector,
      tagName: el.tagName.toLowerCase(),
      className: el.className || '',
      elementId: el.id || '',
      previewText: previewText + (el.textContent && el.textContent.trim().length > 100 ? '...' : ''),
      index: index
    };
  });
  
  if (similarElementsList.length > 0) {
    // Update sidebar with similar elements
    updateSidebarPanel();
    
    // Update banner to show selecting mode
    updateScrapingBannerForSelecting();
    
    // Show notification
    showSimilarElementsFound(similarElementsList.length);
  }
}

/**
 * Scrape selected similar elements
 */
function scrapeSelectedSimilarElements(selectedIndices) {
  if (!selectedIndices || selectedIndices.length === 0) {
    return;
  }
  
  const scrapedItems = [];
  
  selectedIndices.forEach((index, i) => {
    const item = similarElementsList[index];
    if (!item) return;
    
    if (scrapingModeActive && item.element) {
      const data = extractElementData(item.element);
      
      const scrapedItem = {
        id: Date.now() + i,
        timestamp: new Date().toISOString(),
        selector: item.selector,
        tagName: item.element.tagName,
        className: item.className,
        elementId: item.elementId,
        data: data
      };
      
      scrapedItems.push(scrapedItem);
      saveScrapedItemToStorage(scrapedItem);
      
      // Visual feedback
      showSelectionFeedback(item.element);
      
      // Notify popup
      chrome.runtime.sendMessage({
        action: 'elementScraped',
        selector: item.selector,
        data: data,
        tagName: item.element.tagName,
        className: item.className,
        id: item.elementId
      }).catch(() => {});
    }
  });
  
  // Download scraped data as JSON file
  if (scrapedItems.length > 0) {
    const jsonData = JSON.stringify(scrapedItems, null, 2);
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const filename = `scraped_elements_${Date.now()}.json`;
    
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

/**
 * Show notification when similar elements are found
 */
function showSimilarElementsFound(count) {
  const notification = document.createElement('div');
  notification.id = 'similar-elements-notification';
  notification.style.cssText = `
    position: fixed;
    top: 60px;
    left: 50%;
    transform: translateX(-50%);
    background: #4CAF50;
    color: white;
    padding: 12px 24px;
    border-radius: 4px;
    font-weight: 600;
    font-size: 14px;
    z-index: 1000000;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    animation: slideDown 0.3s ease-out;
  `;
  notification.textContent = `Found ${count} similar element(s) - Check sidebar to select and scrape`;
  document.body.appendChild(notification);
  
  setTimeout(() => {
    if (notification.parentElement) {
      notification.style.animation = 'slideUp 0.3s ease-out';
      setTimeout(() => notification.remove(), 300);
    }
  }, 3000);
}

/**
 * Autodetect data types in similar elements
 */
function autodetectDataTypes() {
  if (similarElementsList.length === 0) {
    showNotification('No elements to analyze. Click on an element first.', 'error');
    return;
  }
  
  // Analyze each element's text content
  const dataTypes = [];
  const typePatterns = {
    email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    phone: /^[\+]?[(]?[0-9]{1,4}[)]?[-\s\.]?[(]?[0-9]{1,4}[)]?[-\s\.]?[0-9]{1,9}$/,
    url: /^https?:\/\/.+/,
    date: /^\d{1,4}[-\/]\d{1,2}[-\/]\d{1,4}$|^\d{1,2}\/\d{1,2}\/\d{2,4}$/,
    price: /^\$?\d+\.?\d*$|^\d+\.?\d*\s*[A-Z]{3}$/,
    number: /^-?\d+\.?\d*$/,
    zipcode: /^\d{5}(-\d{4})?$/,
    creditCard: /^\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}$/
  };
  
  similarElementsList.forEach((item, index) => {
    const text = item.element.textContent.trim();
    if (!text) return;
    
    const detectedTypes = [];
    
    // Check for each data type
    if (typePatterns.email.test(text)) {
      detectedTypes.push('Email');
    } else if (typePatterns.phone.test(text)) {
      detectedTypes.push('Phone');
    } else if (typePatterns.url.test(text)) {
      detectedTypes.push('URL');
    } else if (typePatterns.date.test(text)) {
      detectedTypes.push('Date');
    } else if (typePatterns.price.test(text)) {
      detectedTypes.push('Price');
    } else if (typePatterns.zipcode.test(text)) {
      detectedTypes.push('Zip Code');
    } else if (typePatterns.creditCard.test(text)) {
      detectedTypes.push('Credit Card');
    } else if (typePatterns.number.test(text) && text.length < 20) {
      detectedTypes.push('Number');
    } else if (text.length > 50) {
      detectedTypes.push('Text/Description');
    } else {
      detectedTypes.push('Text');
    }
    
    // Check for links
    if (item.element.querySelectorAll('a[href]').length > 0) {
      detectedTypes.push('Has Links');
    }
    
    // Check for images
    if (item.element.querySelectorAll('img').length > 0) {
      detectedTypes.push('Has Images');
    }
    
    dataTypes.push({
      index: index,
      types: detectedTypes.join(', '),
      text: text.substring(0, 50) + (text.length > 50 ? '...' : '')
    });
  });
  
  // Show results in a notification or update sidebar items
  const typeCounts = {};
  dataTypes.forEach(dt => {
    dt.types.split(', ').forEach(type => {
      typeCounts[type] = (typeCounts[type] || 0) + 1;
    });
  });
  
  const summary = Object.entries(typeCounts)
    .map(([type, count]) => `${type}: ${count}`)
    .join(', ');
  
  showNotification(`Detected data types: ${summary}`, 'success');
  
  // Update sidebar items to show detected types
  const sidebarItems = sidebarPanel.querySelectorAll('.scraper-sidebar-item');
  sidebarItems.forEach((item, index) => {
    const dataTypeInfo = dataTypes.find(dt => dt.index === index);
    if (dataTypeInfo) {
      // Find or create a data type indicator
      let typeIndicator = item.querySelector('.scraper-sidebar-item-type');
      if (!typeIndicator) {
        typeIndicator = document.createElement('div');
        typeIndicator.className = 'scraper-sidebar-item-type';
        typeIndicator.style.cssText = `
          font-size: 10px;
          color: #4CAF50;
          font-weight: 600;
          margin-top: 4px;
          padding: 2px 6px;
          background: #e8f5e9;
          border-radius: 3px;
          display: inline-block;
        `;
        const preview = item.querySelector('.scraper-sidebar-item-preview');
        if (preview) {
          preview.parentNode.insertBefore(typeIndicator, preview);
        }
      }
      typeIndicator.textContent = `📊 ${dataTypeInfo.types}`;
    }
  });
}

/**
 * Show a notification message
 */
function showNotification(message, type = 'success') {
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 60px;
    left: 50%;
    transform: translateX(-50%);
    background: ${type === 'error' ? '#f44336' : '#4CAF50'};
    color: white;
    padding: 12px 24px;
    border-radius: 4px;
    font-weight: 600;
    font-size: 14px;
    z-index: 1000001;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    max-width: 400px;
    text-align: center;
  `;
  notification.textContent = message;
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.transition = 'opacity 0.3s';
    notification.style.opacity = '0';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

/**
 * Create sidebar panel for previewing and scraping similar elements
 */
function createSidebarPanel() {
  sidebarPanel = document.createElement('div');
  sidebarPanel.id = 'scraper-sidebar';
  sidebarPanel.innerHTML = `
    <div class="scraper-sidebar-header">
      <h3>Scraping Elements</h3>
      <div class="scraper-sidebar-header-actions">
        <button id="scraper-autodetect-btn" class="scraper-btn-autodetect" title="Autodetect Data Types">Autodetect</button>
      </div>
    </div>
    <div class="scraper-sidebar-content">
      <div id="scraper-sidebar-empty" class="scraper-sidebar-empty">
        <p>Click on an element to find similar ones</p>
      </div>
      <div id="scraper-sidebar-list" class="scraper-sidebar-list" style="display: none;"></div>
    </div>
    <div class="scraper-sidebar-footer" style="display: none;">
      <button id="scraper-select-all" class="scraper-btn-secondary">Select All</button>
      <button id="scraper-scrape-selected" class="scraper-btn-primary">Scrape Selected</button>
    </div>
  `;
  
  sidebarPanel.style.cssText = `
    position: fixed;
    top: 0;
    right: 0;
    width: 280px;
    height: 100vh;
    background: white;
    box-shadow: -2px 0 10px rgba(0,0,0,0.1);
    z-index: 999997;
    display: flex;
    flex-direction: column;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    overflow: hidden;
  `;
  
  // Add styles
  const style = document.createElement('style');
  style.textContent = `
    #scraper-sidebar .scraper-sidebar-header {
      padding: 16px;
      background: #2196F3;
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #1976D2;
    }
    #scraper-sidebar .scraper-sidebar-header h3 {
      margin: 0;
      font-size: 16px;
      font-weight: 600;
    }
    #scraper-sidebar .scraper-sidebar-header-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    #scraper-sidebar .scraper-btn-autodetect {
      background: rgba(255,255,255,0.2);
      border: 1px solid rgba(255,255,255,0.4);
      color: white;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      padding: 6px 10px;
      border-radius: 4px;
      transition: all 0.2s;
      white-space: nowrap;
      min-width: fit-content;
      box-sizing: border-box;
    }
    #scraper-sidebar .scraper-btn-autodetect:hover {
      background: rgba(255,255,255,0.3);
      border-color: rgba(255,255,255,0.5);
    }
    #scraper-sidebar .scraper-sidebar-content {
      flex: 1;
      overflow-y: auto;
      padding: 12px;
    }
    #scraper-sidebar .scraper-sidebar-empty {
      text-align: center;
      color: #999;
      padding: 40px 20px;
      font-size: 14px;
    }
    #scraper-sidebar .scraper-sidebar-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    #scraper-sidebar .scraper-sidebar-item {
      border: 2px solid #e0e0e0;
      border-radius: 6px;
      padding: 12px;
      cursor: pointer;
      transition: all 0.2s;
      background: white;
    }
    #scraper-sidebar .scraper-sidebar-item:hover {
      border-color: #2196F3;
      background: #f5f5f5;
    }
    #scraper-sidebar .scraper-sidebar-item.selected {
      border-color: #4CAF50;
      background: #e8f5e9;
    }
    #scraper-sidebar .scraper-sidebar-item-header {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 8px;
    }
    #scraper-sidebar .scraper-sidebar-item-checkbox {
      width: 18px;
      height: 18px;
      cursor: pointer;
      accent-color: #4CAF50;
    }
    #scraper-sidebar .scraper-sidebar-item-tag {
      font-family: 'Courier New', monospace;
      font-size: 12px;
      color: #2196F3;
      font-weight: 600;
    }
    #scraper-sidebar .scraper-sidebar-item-preview {
      font-size: 12px;
      color: #666;
      line-height: 1.4;
      margin-top: 6px;
      word-wrap: break-word;
    }
    #scraper-sidebar .scraper-sidebar-footer {
      padding: 12px;
      border-top: 1px solid #e0e0e0;
      display: flex;
      gap: 8px;
      background: #f9f9f9;
    }
    #scraper-sidebar .scraper-btn-primary,
    #scraper-sidebar .scraper-btn-secondary {
      flex: 1;
      padding: 10px;
      border: none;
      border-radius: 4px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    }
    #scraper-sidebar .scraper-btn-primary {
      background: #4CAF50;
      color: white;
    }
    #scraper-sidebar .scraper-btn-primary:hover:not(:disabled) {
      background: #45a049;
    }
    #scraper-sidebar .scraper-btn-primary:disabled {
      background: #cccccc;
      color: #666666;
      cursor: not-allowed;
      opacity: 0.5;
    }
    #scraper-sidebar .scraper-btn-secondary {
      background: #e0e0e0;
      color: #333;
    }
    #scraper-sidebar .scraper-btn-secondary:hover {
      background: #d0d0d0;
    }
    #scraper-sidebar .scraper-sidebar-count {
      font-size: 11px;
      color: #999;
      margin-top: 4px;
      margin-bottom: 2px;
      font-weight: 500;
    }
  `;
  document.head.appendChild(style);
  
  document.body.appendChild(sidebarPanel);
  
  // Add hover listeners to sidebar to pause/resume scraping mode
  sidebarPanel.addEventListener('mouseenter', () => {
    pauseScrapingMode();
  });
  
  sidebarPanel.addEventListener('mouseleave', () => {
    resumeScrapingMode();
  });
  
  // Add event listeners
  document.getElementById('scraper-autodetect-btn').addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    autodetectDataTypes();
  });
  
  document.getElementById('scraper-select-all').addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const checkboxes = sidebarPanel.querySelectorAll('.scraper-sidebar-item-checkbox');
    if (checkboxes.length === 0) return;
    
    const allChecked = Array.from(checkboxes).every(cb => cb.checked);
    checkboxes.forEach(cb => {
      cb.checked = !allChecked;
      const item = cb.closest('.scraper-sidebar-item');
      if (cb.checked) {
        item.classList.add('selected');
        // Highlight element on page
        const index = parseInt(item.dataset.index);
        if (similarElementsList[index] && similarElementsList[index].element) {
          similarElementsList[index].element.style.outline = '2px solid #4CAF50';
          similarElementsList[index].element.style.outlineOffset = '2px';
        }
      } else {
        item.classList.remove('selected');
        // Remove highlight
        const index = parseInt(item.dataset.index);
        if (similarElementsList[index] && similarElementsList[index].element) {
          similarElementsList[index].element.style.outline = '';
          similarElementsList[index].element.style.outlineOffset = '';
        }
      }
    });
    updateScrapeSelectedButtonState();
  });
  
  const scrapeSelectedBtn = document.getElementById('scraper-scrape-selected');
  scrapeSelectedBtn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const checkboxes = sidebarPanel.querySelectorAll('.scraper-sidebar-item-checkbox:checked');
    const selectedIndices = Array.from(checkboxes).map(cb => 
      parseInt(cb.closest('.scraper-sidebar-item').dataset.index)
    );
    
    if (selectedIndices.length === 0) {
      alert('Please select at least one element to scrape');
      return;
    }
    
    scrapeSelectedSimilarElements(selectedIndices);
    
    // Show success message
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 60px;
      left: 50%;
      transform: translateX(-50%);
      background: #4CAF50;
      color: white;
      padding: 12px 24px;
      border-radius: 4px;
      font-weight: 600;
      font-size: 14px;
      z-index: 1000001;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    `;
    notification.textContent = `Scraping ${selectedIndices.length} element(s)...`;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.remove();
    }, 2000);
  });
  
  // Function to update scrape selected button state
  function updateScrapeSelectedButtonState() {
    if (!sidebarPanel) return;
    const scrapeSelectedBtn = document.getElementById('scraper-scrape-selected');
    if (!scrapeSelectedBtn) return;
    const checkboxes = sidebarPanel.querySelectorAll('.scraper-sidebar-item-checkbox:checked');
    const hasSelection = checkboxes.length > 0;
    scrapeSelectedBtn.disabled = !hasSelection;
  }
  
  // Store the update function for use in updateSidebarPanel
  window.updateScrapeSelectedButtonState = updateScrapeSelectedButtonState;
  
  // Initial button state update
  updateScrapeSelectedButtonState();
}

/**
 * Update sidebar panel with similar elements
 */
function updateSidebarPanel() {
  if (!sidebarPanel) return;
  
  const emptyDiv = document.getElementById('scraper-sidebar-empty');
  const listDiv = document.getElementById('scraper-sidebar-list');
  const footerDiv = sidebarPanel.querySelector('.scraper-sidebar-footer');
  
  if (similarElementsList.length === 0) {
    emptyDiv.style.display = 'block';
    listDiv.style.display = 'none';
    footerDiv.style.display = 'none';
    return;
  }
  
  emptyDiv.style.display = 'none';
  listDiv.style.display = 'flex';
  footerDiv.style.display = 'flex';
  
  listDiv.innerHTML = '';
  
  similarElementsList.forEach((item, index) => {
    const itemDiv = document.createElement('div');
    itemDiv.className = 'scraper-sidebar-item';
    itemDiv.dataset.index = index;
    
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'scraper-sidebar-item-checkbox';
    checkbox.addEventListener('change', (e) => {
      if (e.target.checked) {
        itemDiv.classList.add('selected');
        // Highlight element on page
        item.element.style.outline = '2px solid #4CAF50';
        item.element.style.outlineOffset = '2px';
      } else {
        itemDiv.classList.remove('selected');
        item.element.style.outline = '';
        item.element.style.outlineOffset = '';
      }
      // Update scrape selected button state
      if (window.updateScrapeSelectedButtonState) {
        window.updateScrapeSelectedButtonState();
      }
    });
    
    itemDiv.addEventListener('click', (e) => {
      if (e.target !== checkbox) {
        checkbox.checked = !checkbox.checked;
        checkbox.dispatchEvent(new Event('change'));
      }
    });
    
    // Highlight element on hover
    itemDiv.addEventListener('mouseenter', () => {
      item.element.style.outline = '2px solid #2196F3';
      item.element.style.outlineOffset = '2px';
      item.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
    
    itemDiv.addEventListener('mouseleave', () => {
      if (!checkbox.checked) {
        item.element.style.outline = '';
        item.element.style.outlineOffset = '';
      }
    });
    
    const header = document.createElement('div');
    header.className = 'scraper-sidebar-item-header';
    
    const tagSpan = document.createElement('span');
    tagSpan.className = 'scraper-sidebar-item-tag';
    tagSpan.textContent = `${item.tagName}${item.elementId ? '#' + item.elementId : ''}${item.className ? '.' + item.className.split(' ')[0] : ''}`;
    
    header.appendChild(checkbox);
    header.appendChild(tagSpan);
    
    const count = document.createElement('div');
    count.className = 'scraper-sidebar-count';
    const textLength = item.element.textContent ? item.element.textContent.trim().length : 0;
    count.textContent = `${textLength} chars`;
    
    const preview = document.createElement('div');
    preview.className = 'scraper-sidebar-item-preview';
    preview.textContent = item.previewText || '[No text content]';
    
    itemDiv.appendChild(header);
    itemDiv.appendChild(count);
    itemDiv.appendChild(preview);
    
    listDiv.appendChild(itemDiv);
  });
  
  // Update scrape selected button state after items are added
  if (window.updateScrapeSelectedButtonState) {
    window.updateScrapeSelectedButtonState();
  }
}

/**
 * Show toggle button to reopen sidebar
 */
function showSidebarToggleButton() {
  // Remove existing toggle button if any
  const existingToggle = document.getElementById('scraper-sidebar-toggle');
  if (existingToggle) {
    existingToggle.remove();
  }
  
  const toggleBtn = document.createElement('button');
  toggleBtn.id = 'scraper-sidebar-toggle';
  toggleBtn.innerHTML = '📋';
  toggleBtn.title = 'Show Scraping Elements';
  toggleBtn.style.cssText = `
    position: fixed;
    right: 20px;
    top: 50%;
    transform: translateY(-50%);
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: #2196F3;
    color: white;
    border: none;
    font-size: 24px;
    cursor: pointer;
    z-index: 999996;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    transition: all 0.2s;
  `;
  
  toggleBtn.addEventListener('mouseenter', () => {
    toggleBtn.style.transform = 'translateY(-50%) scale(1.1)';
    toggleBtn.style.background = '#1976D2';
  });
  
  toggleBtn.addEventListener('mouseleave', () => {
    toggleBtn.style.transform = 'translateY(-50%) scale(1)';
    toggleBtn.style.background = '#2196F3';
  });
  
  toggleBtn.addEventListener('click', () => {
    if (sidebarPanel) {
      sidebarPanel.style.display = 'flex';
      toggleBtn.remove();
    }
  });
  
  document.body.appendChild(toggleBtn);
}

/**
 * Remove sidebar panel
 */
function removeSidebarPanel() {
  if (sidebarPanel && sidebarPanel.parentElement) {
    sidebarPanel.remove();
    sidebarPanel = null;
  }
  
  // Remove toggle button if exists
  const toggleBtn = document.getElementById('scraper-sidebar-toggle');
  if (toggleBtn) {
    toggleBtn.remove();
  }
}

/**
 * Save scraped item to storage
 */
async function saveScrapedItemToStorage(scrapedItem) {
  try {
    const storageKey = `scrapedItems_${window.location.href}`;
    const storage = await chrome.storage.local.get([storageKey]);
    const existingItems = storage[storageKey] || [];
    existingItems.push(scrapedItem);
    await chrome.storage.local.set({ [storageKey]: existingItems });
  } catch (error) {
    console.error('Error saving scraped item:', error);
  }
}

/**
 * Extract all tables from current page
 */
function extractTablesFromPage() {
  const tables = [];
  // Filter out nested tables (tables inside other tables)
  const allTables = document.querySelectorAll('table');
  const topLevelTables = Array.from(allTables).filter(table => {
    // Check if this table is nested inside another table
    let parent = table.parentElement;
    while (parent && parent !== document.body) {
      if (parent.tagName === 'TABLE') {
        return false; // This is a nested table
      }
      parent = parent.parentElement;
    }
    return true; // This is a top-level table
  });
  
  topLevelTables.forEach((table, index) => {
    try {
      const tableData = extractTableData(table, index);
      if (tableData && tableData.rows.length > 0) {
        tables.push(tableData);
      }
    } catch (error) {
      console.warn(`Error extracting table ${index}:`, error);
    }
  });
  
  return tables;
}

/**
 * Extract data from a single table element
 * Handles rowspans, colspans, and complex Wikipedia table structures
 */
function extractTableData(tableElement, index = 0) {
  const rows = [];
  const headers = [];
  
  // Skip hidden tables or tables with no visible content
  const style = window.getComputedStyle(tableElement);
  if (style.display === 'none' || style.visibility === 'hidden') {
    return null;
  }
  
  // Find all header rows (thead or rows with th elements)
  const thead = tableElement.querySelector('thead');
  const headerRows = [];
  
  if (thead) {
    const theadRows = thead.querySelectorAll('tr');
    theadRows.forEach(row => {
      if (row.offsetParent !== null) { // Check if row is visible
        headerRows.push(row);
      }
    });
  }
  
  // Also check first few rows for header cells if no thead
  if (headerRows.length === 0) {
    const allRows = tableElement.querySelectorAll('tr');
    for (let i = 0; i < Math.min(3, allRows.length); i++) {
      const row = allRows[i];
      if (row.offsetParent === null) continue; // Skip hidden rows
      const thCount = row.querySelectorAll('th').length;
      const tdCount = row.querySelectorAll('td').length;
      // If row has mostly th elements, treat as header
      if (thCount > 0 && thCount >= tdCount) {
        headerRows.push(row);
      } else if (headerRows.length > 0) {
        // Stop if we've found headers and this row doesn't look like a header
        break;
      }
    }
  }
  
  // Extract headers from header rows
  if (headerRows.length > 0) {
    // For multiple header rows, combine them
    const headerCells = [];
    headerRows.forEach(headerRow => {
      const cells = headerRow.querySelectorAll('th, td');
      cells.forEach(cell => {
        if (cell.offsetParent !== null) { // Only visible cells
          const text = cleanCellText(cell);
          const colspan = parseInt(cell.getAttribute('colspan') || '1');
          const rowspan = parseInt(cell.getAttribute('rowspan') || '1');
          
          // Add the cell text
          headerCells.push(text);
          // Add empty cells for colspan
          for (let i = 1; i < colspan; i++) {
            headerCells.push('');
          }
        }
      });
    });
    
    // Use the longest header row as the header
    if (headerCells.length > headers.length) {
      headers.length = 0;
      headers.push(...headerCells);
    }
  }
  
  // Extract all data rows
  const tbody = tableElement.querySelector('tbody') || tableElement;
  const allRows = Array.from(tbody.querySelectorAll('tr'));
  
  // Track active rowspans: map of column index -> {value, remainingRows}
  const activeRowspans = new Map();
  let dataRowIndex = 0;
  
  allRows.forEach((row, rowIndex) => {
    // Skip header rows that were already processed
    if (headerRows.includes(row)) {
      return;
    }
    
    // Skip hidden rows
    if (row.offsetParent === null) {
      return;
    }
    
    // Skip rows that are clearly not data rows (e.g., navigation rows)
    const rowClass = row.className || '';
    if (rowClass.includes('navbox') || rowClass.includes('metadata') || 
        rowClass.includes('mw-empty-elt') || rowClass.includes('sortbottom')) {
      return;
    }
    
    const cells = Array.from(row.querySelectorAll('td, th'));
    if (cells.length === 0) {
      return;
    }
    
    const rowData = [];
    let colIndex = 0;
    
    // Process cells in order
    cells.forEach(cell => {
      // Skip hidden cells
      if (cell.offsetParent === null) {
        return;
      }
      
      // Check if this column is occupied by a rowspan from a previous row
      while (activeRowspans.has(colIndex)) {
        const rowspan = activeRowspans.get(colIndex);
        rowData.push(rowspan.value);
        rowspan.remainingRows--;
        if (rowspan.remainingRows <= 0) {
          activeRowspans.delete(colIndex);
        }
        colIndex++;
      }
      
      const text = cleanCellText(cell);
      const colspan = parseInt(cell.getAttribute('colspan') || '1');
      const rowspan = parseInt(cell.getAttribute('rowspan') || '1');
      
      // Add the cell text
      rowData.push(text);
      colIndex++;
      
      // Handle colspan - add empty cells (but these don't have rowspan)
      for (let i = 1; i < colspan; i++) {
        // Check if this column is occupied by a rowspan
        while (activeRowspans.has(colIndex)) {
          const rowspan = activeRowspans.get(colIndex);
          rowData.push(rowspan.value);
          rowspan.remainingRows--;
          if (rowspan.remainingRows <= 0) {
            activeRowspans.delete(colIndex);
          }
          colIndex++;
        }
        rowData.push('');
        colIndex++;
      }
      
      // Handle rowspan - track it for future rows
      if (rowspan > 1) {
        // The first column of this cell will have the rowspan
        const startCol = colIndex - colspan;
        for (let i = 0; i < colspan; i++) {
          const col = startCol + i;
          if (i === 0) {
            // First column gets the value
            activeRowspans.set(col, {
              value: text,
              remainingRows: rowspan - 1
            });
          } else {
            // Other columns in colspan are empty but still span rows
            activeRowspans.set(col, {
              value: '',
              remainingRows: rowspan - 1
            });
          }
        }
      }
    });
    
    // Fill any remaining rowspan columns
    const maxCol = Math.max(...Array.from(activeRowspans.keys()).concat([colIndex - 1]));
    while (colIndex <= maxCol && activeRowspans.has(colIndex)) {
      const rowspan = activeRowspans.get(colIndex);
      rowData.push(rowspan.value);
      rowspan.remainingRows--;
      if (rowspan.remainingRows <= 0) {
        activeRowspans.delete(colIndex);
      }
      colIndex++;
    }
    
    if (rowData.length > 0) {
      rows.push(rowData);
      dataRowIndex++;
    }
  });

  // If no headers found, generate default headers based on max columns
  if (headers.length === 0 && rows.length > 0) {
    const maxColCount = Math.max(...rows.map(r => r.length));
    for (let i = 0; i < maxColCount; i++) {
      headers.push(`Column ${i + 1}`);
    }
  }
  
  // Normalize row lengths to match header count
  const normalizedRows = rows.map(row => {
    const normalized = [...row];
    while (normalized.length < headers.length) {
      normalized.push('');
    }
    return normalized.slice(0, headers.length);
  });

  // Get table caption or title
  const caption = tableElement.querySelector('caption');
  let title = caption ? cleanCellText(caption) : `Table ${index + 1}`;
  
  // Try to get title from nearby heading or table class
  if (!caption || title === `Table ${index + 1}`) {
    // Check for nearby heading
    let prevSibling = tableElement.previousElementSibling;
    let attempts = 0;
    while (prevSibling && attempts < 3) {
      if (prevSibling.tagName && prevSibling.tagName.match(/^H[1-6]$/)) {
        title = cleanCellText(prevSibling);
        break;
      }
      prevSibling = prevSibling.previousElementSibling;
      attempts++;
    }
    
    // Check for table class that might indicate purpose
    const tableClass = tableElement.className || '';
    if (tableClass.includes('wikitable') || tableClass.includes('sortable')) {
      // Try to find a nearby anchor or id
      const id = tableElement.id;
      if (id) {
        const anchor = document.querySelector(`a[href="#${id}"]`);
        if (anchor) {
          title = cleanCellText(anchor) || title;
        }
      }
    }
  }

  return {
    index,
    title: title.trim() || `Table ${index + 1}`,
    headers: headers.length > 0 ? headers : normalizedRows[0] ? Array(normalizedRows[0].length).fill(0).map((_, i) => `Column ${i + 1}`) : [],
    rows: normalizedRows,
    columnCount: headers.length || (normalizedRows[0] ? normalizedRows[0].length : 0),
    rowCount: normalizedRows.length
  };
}

/**
 * Clean and normalize cell text
 * Improved to handle Wikipedia's complex cell structures
 */
function cleanCellText(cell) {
  if (!cell) return '';
  
  // Skip hidden cells
  if (cell.offsetParent === null) {
    return '';
  }
  
  // Remove nested tables (replace with placeholder)
  const nestedTable = cell.querySelector('table');
  if (nestedTable) {
    return '[Nested Table]';
  }
  
  // Clone the cell to avoid modifying the original
  const clone = cell.cloneNode(true);
  
  // Remove unwanted elements
  const unwantedSelectors = [
    'script', 'style', 'noscript', '.reference', '.mw-references-wrap',
    '.mw-editsection', '.sortkey', '.sorttext', '.hidden', '[style*="display:none"]'
  ];
  unwantedSelectors.forEach(selector => {
    clone.querySelectorAll(selector).forEach(el => el.remove());
  });
  
  // Handle images - extract alt text or title
  clone.querySelectorAll('img').forEach(img => {
    const alt = img.getAttribute('alt') || img.getAttribute('title') || '';
    if (alt) {
      const textNode = document.createTextNode(`[Image: ${alt}]`);
      img.parentNode.replaceChild(textNode, img);
    } else {
      img.remove();
    }
  });
  
  // Handle links - prefer link text, but keep href if useful
  clone.querySelectorAll('a').forEach(link => {
    const linkText = link.textContent.trim();
    const href = link.getAttribute('href') || '';
    const title = link.getAttribute('title') || '';
    
    // If link text is empty or same as href, use title or href
    if (!linkText || linkText === href) {
      if (title) {
        link.textContent = title;
      } else if (href && !href.startsWith('#')) {
        // Keep meaningful hrefs
        const hrefText = href.split('/').pop().replace(/_/g, ' ');
        link.textContent = decodeURIComponent(hrefText);
      }
    }
  });
  
  // Handle superscripts and subscripts (common in Wikipedia)
  clone.querySelectorAll('sup, sub').forEach(el => {
    const text = el.textContent.trim();
    if (text) {
      el.textContent = `(${text})`;
    }
  });
  
  // Get text content
  let text = clone.textContent || clone.innerText || '';
  
  // Clean up whitespace
  text = text.replace(/\s+/g, ' ').trim();
  
  // Remove common Wikipedia artifacts
  text = text.replace(/\[\d+\]/g, ''); // Remove citation numbers like [1]
  text = text.replace(/\[edit\]/g, ''); // Remove edit links
  text = text.replace(/\[show\]/g, ''); // Remove show/hide links
  
  // Clean up multiple spaces
  text = text.replace(/\s{2,}/g, ' ').trim();
  
  return text;
}

