# DownloadAll - Chrome Extension

A Chrome extension that provides quick download functionality and table extraction from web pages.

## Features

### Quick Download Dialog
- Extract and download files by type (HTM, XML, JPG, GIF, PNG)
- Filter files by extension
- Set custom download directory
- Add items to download queue or download immediately

### Table Extraction
- Automatically detect tables on web pages
- Export tables to Excel format
- View table information (rows × columns)
- Export individual tables or all tables at once

## Installation

1. Clone or download this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" (toggle in top right)
4. Click "Load unpacked"
5. Select the `DownloadAll` folder

## Setup

**Important**: Before using the extension, you must:

1. Go to Chrome Settings → Downloads
2. **Uncheck** "Ask where to save each file before downloading"
   - This is required for automatic downloads to work
   - Otherwise, you'll get popup dialogs for each file

## Usage

### Quick Download Dialog

1. Open the extension popup
2. The Quick Download Dialog will show file counts for each type (HTM, XML, JPG, GIF, PNG)
3. Check the file types you want to download
4. (Optional) Set a directory for the downloads
5. Click "ADD ITEMS TO LIST" to queue downloads or "DOWNLOAD NOW" to start immediately

### Table Extraction

1. Navigate to a webpage with tables
2. Open the extension popup
3. Tables will be automatically detected and displayed
4. Click on a table to export it individually
5. Click "Export All to Excel" to export all tables at once

## Project Structure

```
DownloadAll/
├── manifest.json              # Extension manifest
├── popup/
│   ├── popup.html            # Main UI
│   ├── popup.js              # UI logic
│   └── popup.css             # Styles
├── content/
│   └── content-script.js     # Table extraction
└── utils/
    └── excelExporter.js      # Excel export functionality
```

## License

This project is provided as-is for educational and personal use.
