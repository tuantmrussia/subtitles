// Excel Export Utilities

class ExcelExporter {
  /**
   * Export table data to Excel format (XLSX)
   * Uses Excel XML format for better compatibility
   */
  static exportTableToExcel(tableData, filename = 'table.xlsx') {
    if (!tableData || !tableData.rows || tableData.rows.length === 0) {
      throw new Error('No table data to export');
    }

    // Use Excel XML format for proper Excel files
    const xml = this.generateExcelXML(tableData);
    const blob = new Blob([xml], { type: 'application/vnd.ms-excel' });
    // Ensure filename has .xls extension for Excel XML format
    const excelFilename = filename.endsWith('.xlsx') ? filename.replace('.xlsx', '.xls') : 
                          filename.endsWith('.xls') ? filename : filename + '.xls';
    this.downloadFile(blob, excelFilename);
  }

  /**
   * Export multiple tables to a single Excel file
   */
  static exportTablesToExcel(tables, filename = 'tables.xlsx') {
    if (!tables || tables.length === 0) {
      throw new Error('No tables to export');
    }

    // Generate Excel XML with multiple worksheets
    let xml = '<?xml version="1.0"?>\n';
    xml += '<?mso-application progid="Excel.Sheet"?>\n';
    xml += '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"\n';
    xml += ' xmlns:o="urn:schemas-microsoft-com:office:office"\n';
    xml += ' xmlns:x="urn:schemas-microsoft-com:office:excel"\n';
    xml += ' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"\n';
    xml += ' xmlns:html="http://www.w3.org/TR/REC-html40">\n';

    tables.forEach((table, index) => {
      const sheetName = this.escapeXML(table.title || `Table ${index + 1}`).substring(0, 31); // Excel sheet name limit
      xml += '<Worksheet ss:Name="' + sheetName + '">\n';
      xml += '<Table>\n';

      // Add headers
      if (table.headers && table.headers.length > 0) {
        xml += '<Row>\n';
        table.headers.forEach(header => {
          xml += '<Cell><Data ss:Type="String">' + this.escapeXML(header) + '</Data></Cell>\n';
        });
        xml += '</Row>\n';
      }

      // Add rows
      table.rows.forEach(row => {
        xml += '<Row>\n';
        const paddedRow = [...row];
        while (paddedRow.length < table.headers.length) {
          paddedRow.push('');
        }
        paddedRow.slice(0, table.headers.length).forEach(cell => {
          const isNumber = !isNaN(cell) && !isNaN(parseFloat(cell)) && isFinite(cell) && String(cell).trim() !== '';
          const type = isNumber ? 'Number' : 'String';
          xml += '<Cell><Data ss:Type="' + type + '">' + this.escapeXML(String(cell)) + '</Data></Cell>\n';
        });
        xml += '</Row>\n';
      });

      xml += '</Table>\n';
      xml += '</Worksheet>\n';
    });

    xml += '</Workbook>';

    const blob = new Blob([xml], { type: 'application/vnd.ms-excel' });
    const excelFilename = filename.endsWith('.xlsx') ? filename.replace('.xlsx', '.xls') : 
                          filename.endsWith('.xls') ? filename : filename + '.xls';
    this.downloadFile(blob, excelFilename);
  }

  /**
   * Export table to proper XLSX format using a simple XML structure
   * This creates a basic Excel-compatible file (Excel 2003+ compatible)
   */
  static exportTableToXLSX(tableData, filename = 'table.xlsx') {
    const xml = this.generateExcelXML(tableData);
    const blob = new Blob([xml], { type: 'application/vnd.ms-excel' });
    const excelFilename = filename.endsWith('.xlsx') ? filename.replace('.xlsx', '.xls') : 
                          filename.endsWith('.xls') ? filename : filename + '.xls';
    this.downloadFile(blob, excelFilename);
  }

  /**
   * Generate Excel XML format (Excel 2003 XML Spreadsheet)
   */
  static generateExcelXML(tableData) {
    let xml = '<?xml version="1.0"?>\n';
    xml += '<?mso-application progid="Excel.Sheet"?>\n';
    xml += '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"\n';
    xml += ' xmlns:o="urn:schemas-microsoft-com:office:office"\n';
    xml += ' xmlns:x="urn:schemas-microsoft-com:office:excel"\n';
    xml += ' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"\n';
    xml += ' xmlns:html="http://www.w3.org/TR/REC-html40">\n';
    xml += '<Worksheet ss:Name="' + this.escapeXML(tableData.title || 'Sheet1') + '">\n';
    xml += '<Table>\n';

    // Add headers
    if (tableData.headers && tableData.headers.length > 0) {
      xml += '<Row>\n';
      tableData.headers.forEach(header => {
        xml += '<Cell><Data ss:Type="String">' + this.escapeXML(header) + '</Data></Cell>\n';
      });
      xml += '</Row>\n';
    }

    // Add rows
    tableData.rows.forEach(row => {
      xml += '<Row>\n';
      const paddedRow = [...row];
      while (paddedRow.length < tableData.headers.length) {
        paddedRow.push('');
      }
      paddedRow.slice(0, tableData.headers.length).forEach(cell => {
        // Try to detect if it's a number
        const isNumber = !isNaN(cell) && !isNaN(parseFloat(cell)) && isFinite(cell) && String(cell).trim() !== '';
        const type = isNumber ? 'Number' : 'String';
        xml += '<Cell><Data ss:Type="' + type + '">' + this.escapeXML(String(cell)) + '</Data></Cell>\n';
      });
      xml += '</Row>\n';
    });

    xml += '</Table>\n';
    xml += '</Worksheet>\n';
    xml += '</Workbook>';

    return xml;
  }

  /**
   * Escape CSV cell value
   */
  static escapeCSVRow(cells) {
    return cells.map(cell => {
      const str = String(cell || '');
      // If cell contains comma, quote, or newline, wrap in quotes and escape quotes
      if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
        return '"' + str.replace(/"/g, '""') + '"';
      }
      return str;
    }).join(',');
  }

  /**
   * Escape XML content
   */
  static escapeXML(text) {
    return String(text || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  }

  /**
   * Download file
   */
  static downloadFile(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    // Append to body if available, otherwise just click
    if (document.body) {
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } else {
      a.click();
    }
    // Clean up after a short delay
    setTimeout(() => URL.revokeObjectURL(url), 100);
  }

  /**
   * Export to CSV (simpler alternative)
   */
  static exportTableToCSV(tableData, filename = 'table.csv') {
    this.exportTableToExcel(tableData, filename);
  }
}

