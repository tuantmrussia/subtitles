// Content script to bridge postMessage from page context to extension
window.addEventListener('message', (event) => {
  // Only process our custom messages
  if (event.data && event.data.type === 'BOOKMARKLET_OPEN_TAB') {
    chrome.runtime.sendMessage({
      action: 'openTab',
      url: event.data.url
    });
  }
}, false);










