(() => {
  const state = { all: [], filtered: [], categories: [], tabId: null, pinnedEntries: [] };

  function toast(msg, ms = 2200) {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), ms);
  }

  function normalizeKind(k) {
    if (k === 'navigate') return 'navigate';
    if (k === 'file') return 'file';
    return 'inject';
  }

  function groupByCategory(items) {
    const map = new Map();
    for (const it of items) {
      const cat = it.category || 'General';
      if (!map.has(cat)) map.set(cat, []);
      map.get(cat).push(it);
    }
    return Array.from(map.entries()).map(([name, list]) => ({ 
      name, 
      list: list.sort((a, b) => (a.title || '').localeCompare(b.title || ''))
    }));
  }

  async function loadPinnedEntries() {
    try {
      const result = await chrome.storage.local.get(['pinnedEntries']);
      state.pinnedEntries = result.pinnedEntries || [];
    } catch (e) {
      console.error('Failed to load pinned entries:', e);
      state.pinnedEntries = [];
    }
  }

  async function savePinnedEntries() {
    try {
      await chrome.storage.local.set({ pinnedEntries: state.pinnedEntries });
    } catch (e) {
      console.error('Failed to save pinned entries:', e);
    }
  }

  async function togglePinEntry(entryId) {
    const index = state.pinnedEntries.indexOf(entryId);
    if (index > -1) {
      state.pinnedEntries.splice(index, 1);
    } else {
      state.pinnedEntries.push(entryId);
    }
    await savePinnedEntries();
    render();
  }

  function isEntryPinned(entryId) {
    return state.pinnedEntries.includes(entryId);
  }

  function hasPinnedEntriesInCategory(items) {
    return items.some(item => isEntryPinned(item.id));
  }

  function createCategoryElement(g, hasPinned = false) {
    const details = document.createElement('details');
    details.className = 'category';
    if (hasPinned) details.classList.add('has-pinned');
    // Explicitly set open state - always start collapsed unless has pinned entries
    if (hasPinned) {
      details.setAttribute('open', '');
    } else {
      details.removeAttribute('open');
    }
    
    const summary = document.createElement('summary');
    const labelWrapper = document.createElement('span');
    labelWrapper.className = 'category-label';
    labelWrapper.textContent = g.name;
    summary.appendChild(labelWrapper);
    
    const rightSide = document.createElement('span');
    rightSide.className = 'category-right';
    
    const count = document.createElement('span');
    count.className = 'count';
    count.textContent = String(g.list.length);
    rightSide.appendChild(count);
    
    summary.appendChild(rightSide);
    details.appendChild(summary);

    const items = document.createElement('div');
    items.className = 'items';
    for (const item of g.list) {
      const row = document.createElement('div');
      row.className = 'item';
      if (isEntryPinned(item.id)) {
        row.classList.add('pinned');
      }
      row.setAttribute('data-tip', item.description || '');

      const label = document.createElement('div');
      label.className = 'item-label';
      label.textContent = item.title;
      
      // Make the row clickable to execute the bookmarklet
      row.addEventListener('click', (e) => {
        // Don't execute if clicking on the pin button
        if (!e.target.closest('.entry-pin-btn')) {
          executeItem(item);
        }
      });

      const rightControls = document.createElement('div');
      rightControls.className = 'item-right';

      const badge = document.createElement('span');
      badge.className = 'badge';
      badge.textContent = normalizeKind(item.kind);
      rightControls.appendChild(badge);

      const isPinned = isEntryPinned(item.id);
      const pinBtn = document.createElement('button');
      pinBtn.className = 'entry-pin-btn';
      pinBtn.setAttribute('aria-label', isPinned ? 'Remove from favorites' : 'Add to favorites');
      pinBtn.innerHTML = isPinned ? '⭐' : '☆';
      pinBtn.title = isPinned ? 'Remove from favorites' : 'Add to favorites';
      pinBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        togglePinEntry(item.id);
      });
      rightControls.appendChild(pinBtn);

      row.appendChild(label);
      row.appendChild(rightControls);
      items.appendChild(row);
    }
    details.appendChild(items);
    return details;
  }

  function getPinnedEntries() {
    return state.filtered
      .filter(item => isEntryPinned(item.id))
      .sort((a, b) => (a.title || '').localeCompare(b.title || ''));
  }

  function createFavoritesCategory() {
    const pinnedEntries = getPinnedEntries();
    if (pinnedEntries.length === 0) return null;

    const details = document.createElement('details');
    details.className = 'category favorites-category';
    details.open = true;
    
    const summary = document.createElement('summary');
    const labelWrapper = document.createElement('span');
    labelWrapper.className = 'category-label';
    labelWrapper.textContent = 'Favorites';
    summary.appendChild(labelWrapper);
    
    const rightSide = document.createElement('span');
    rightSide.className = 'category-right';
    
    const count = document.createElement('span');
    count.className = 'count';
    count.textContent = String(pinnedEntries.length);
    rightSide.appendChild(count);
    
    summary.appendChild(rightSide);
    details.appendChild(summary);

    const items = document.createElement('div');
    items.className = 'items';
    for (const item of pinnedEntries) {
      const row = document.createElement('div');
      row.className = 'item pinned';
      row.setAttribute('data-tip', item.description || '');

      const label = document.createElement('div');
      label.className = 'item-label';
      label.textContent = item.title;
      
      // Make the row clickable to execute the bookmarklet
      row.addEventListener('click', (e) => {
        // Don't execute if clicking on the remove button
        if (!e.target.closest('.remove-favorite-btn')) {
          executeItem(item);
        }
      });

      const rightControls = document.createElement('div');
      rightControls.className = 'item-right';

      const badge = document.createElement('span');
      badge.className = 'badge';
      badge.textContent = normalizeKind(item.kind);
      rightControls.appendChild(badge);

      const removeBtn = document.createElement('button');
      removeBtn.className = 'remove-favorite-btn';
      removeBtn.setAttribute('aria-label', 'Remove from favorites');
      removeBtn.innerHTML = '⭐';
      removeBtn.title = 'Remove from favorites';
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        togglePinEntry(item.id);
      });
      rightControls.appendChild(removeBtn);

      row.appendChild(label);
      row.appendChild(rightControls);
      items.appendChild(row);
    }
    details.appendChild(items);
    return details;
  }

  function render() {
    const wrap = document.getElementById('categories');
    if (!wrap) return;
    wrap.innerHTML = '';
    
    // Render Favorites category first if there are pinned entries
    const favoritesCategory = createFavoritesCategory();
    if (favoritesCategory) {
      wrap.appendChild(favoritesCategory);
    }
    
    // Render all other categories
    const groups = groupByCategory(state.filtered);
    for (const g of groups) {
      wrap.appendChild(createCategoryElement(g, hasPinnedEntriesInCategory(g.list)));
    }
    
    // Ensure all categories without pinned entries are collapsed after render
    // This prevents Chrome from restoring previous open state
    requestAnimationFrame(() => {
      const allDetails = wrap.querySelectorAll('.category:not(.has-pinned):not(.favorites-category)');
      allDetails.forEach(details => {
        details.removeAttribute('open');
      });
    });
  }

  async function getActiveTabId() {
    return new Promise((resolve) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        resolve(tabs && tabs[0] ? tabs[0].id : null);
      });
    });
  }

  function stripJsPrefix(code) {
    return code.startsWith('javascript:') ? code.slice('javascript:'.length) : code;
  }

  async function executeInject(tabId, code) {
    const payload = stripJsPrefix(code);
    try {
      // First, inject a bridge script to handle window.open via postMessage
      await chrome.scripting.executeScript({
        target: { tabId },
        world: 'ISOLATED',
        func: () => {
          // Inject script into page context via DOM manipulation
          const script = document.createElement('script');
          script.textContent = `
            (function() {
              if (window.__bookmarkletOpenOverride) return;
              window.__bookmarkletOpenOverride = true;
              const originalOpen = window.open;
              window.open = function(url, target, features) {
                if (url && typeof url === 'string') {
                  if (url.startsWith('http://') || url.startsWith('https://')) {
                    window.postMessage({type: 'BOOKMARKLET_OPEN_TAB', url: url}, '*');
                    return null;
                  } else if (url.startsWith('/') || !url.includes(':')) {
                    const fullUrl = new URL(url, window.location.origin).href;
                    window.postMessage({type: 'BOOKMARKLET_OPEN_TAB', url: fullUrl}, '*');
                    return null;
                  }
                }
                return originalOpen.call(window, url, target, features);
              };
            })();
          `;
          (document.head || document.documentElement).appendChild(script);
          script.remove();
        }
      });

      // Execute the bookmarklet code
      await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: (scriptCode) => {
          try {
            (0, eval)(scriptCode);
          } catch (e) {
            alert('Bookmarklet error: ' + e.message);
          }
        },
        args: [payload]
      });

      toast('Executed');
    } catch (e) {
      toast('Execution failed: ' + (e && e.message ? e.message : e));
    }
  }

  async function executeNavigate(tabId, url, needsInput) {
    let targetUrl = url;
    if (needsInput) {
      const q = prompt('Enter query:');
      if (!q) return;
      targetUrl = url.replace('%s', encodeURIComponent(q));
    }
    try {
      await chrome.tabs.update(tabId, { url: targetUrl });
      window.close();
    } catch (e) {
      toast('Navigation failed: ' + (e && e.message ? e.message : e));
    }
  }

  async function executeItem(item) {
    const tabId = state.tabId || (await getActiveTabId());
    if (!tabId) return toast('No active tab');
    const kind = normalizeKind(item.kind);
    if (kind === 'file' && item.file) {
      try {
        // First, inject a bridge script to handle window.open via postMessage
        await chrome.scripting.executeScript({
          target: { tabId },
          world: 'ISOLATED',
          func: () => {
            // Inject script into page context via DOM manipulation
            const script = document.createElement('script');
            script.textContent = `
              (function() {
                if (window.__bookmarkletOpenOverride) return;
                window.__bookmarkletOpenOverride = true;
                const originalOpen = window.open;
                window.open = function(url, target, features) {
                  if (url && typeof url === 'string') {
                    if (url.startsWith('http://') || url.startsWith('https://')) {
                      window.postMessage({type: 'BOOKMARKLET_OPEN_TAB', url: url}, '*');
                      return null;
                    } else if (url.startsWith('/') || !url.includes(':')) {
                      const fullUrl = new URL(url, window.location.origin).href;
                      window.postMessage({type: 'BOOKMARKLET_OPEN_TAB', url: fullUrl}, '*');
                      return null;
                    }
                  }
                  return originalOpen.call(window, url, target, features);
                };
              })();
            `;
            (document.head || document.documentElement).appendChild(script);
            script.remove();
          }
        });

        // Then inject the actual bookmarklet file
        await chrome.scripting.executeScript({
          target: { tabId },
          files: [item.file]
        });

        toast('Executed');
      } catch (e) {
        toast('Execution failed: ' + (e && e.message ? e.message : e));
      }
      return;
    }
    if (kind === 'inject') return executeInject(tabId, item.code);
    return executeNavigate(tabId, item.url, Boolean(item.needsInput));
  }

  function filterItems(searchQuery) {
    if (!searchQuery || searchQuery.trim() === '') {
      state.filtered = state.all.slice();
      return;
    }
    const query = searchQuery.toLowerCase().trim();
    state.filtered = state.all.filter(item => {
      const titleMatch = item.title.toLowerCase().includes(query);
      const descMatch = (item.description || '').toLowerCase().includes(query);
      const catMatch = (item.category || '').toLowerCase().includes(query);
      return titleMatch || descMatch || catMatch;
    });
  }

  function handleSearchInput(e) {
    const query = e.target.value;
    filterItems(query);
    render();
  }

  async function loadData() {
    try {
      const url = chrome.runtime.getURL('data/bookmarklets.json');
      const res = await fetch(url, { cache: 'no-store' });
      if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      const text = await res.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch (parseErr) {
        throw new Error(`JSON parse error: ${parseErr.message}`);
      }
      if (!Array.isArray(data)) throw new Error('Invalid data format: expected array');
      state.all = data;
      state.filtered = data.slice();
    } catch (err) {
      console.error('Failed to load data/bookmarklets.json:', err);
      toast(`Error: ${err.message}`);
      state.all = [];
      state.filtered = [];
    }
  }

  window.__popupInit = async function init() {
    state.tabId = await getActiveTabId();
    await loadPinnedEntries();
    await loadData();
    
    // Setup search input handler
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
      searchInput.addEventListener('input', handleSearchInput);
    }
    
    render();
  };
  // Ensure initialization without inline scripts in HTML
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      if (typeof window.__popupInit === 'function') window.__popupInit();
    });
  } else {
    if (typeof window.__popupInit === 'function') window.__popupInit();
  }
})();


