(function(){
try{
  const esc=s=>(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  const scriptEl=document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
  if(!scriptEl||!scriptEl.text){
    alert('TikTok rehydration data not found. Make sure you are on a TikTok profile page.');
    return;
  }
  const jsonData=JSON.parse(scriptEl.text);
  const defaultScope=jsonData?.__DEFAULT_SCOPE__;
  const userDetail=defaultScope?.['webapp.user-detail'];
  if(!userDetail){
    alert('User detail data not found. Make sure you are on a TikTok profile page.');
    return;
  }
  const userInfo=userDetail?.userInfo;
  const user=userInfo?.user;
  if(!user){
    alert('User data not found. Make sure you are on a TikTok profile page.');
    return;
  }
  const userId=user.id||'';
  const uniqueId=user.uniqueId||'';
  const nickname=user.nickname||'';
  const shortId=user.shortId||'';
  const profileUrl=userId?`https://www.tiktok.com/@${uniqueId||'user'}`:window.location.href;
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#333';modal.style.color='#fff';modal.style.padding='20px';
  modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='600px';modal.style.maxHeight='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';modal.style.overflow='auto';
  modal.style.boxShadow='0 0 20px rgba(0,0,0,0.5)';
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  if(userId){
    content.innerHTML=`<h3 style="margin-top:0;color:#fff;font-size:20px;">TikTok User ID Extractor</h3>
      ${nickname?`<p style="margin:10px 0;color:#fff;"><strong>Display Name:</strong> ${esc(nickname)}</p>`:''}
      ${uniqueId?`<p style="margin:10px 0;color:#fff;"><strong>Username:</strong> <code style="background:#222;padding:2px 6px;border-radius:3px;font-family:Courier New,monospace;color:#fff;">@${esc(uniqueId)}</code></p>`:''}
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#fff;"><strong>TikTok User ID:</strong></p>
        <div style="background:#222;padding:12px;border-radius:5px;margin:10px 0;border:1px solid #fff;">
          <code style="font-family:Courier New,monospace;font-size:14px;color:#fff;word-break:break-all;">${esc(userId)}</code>
          <button id="copyUserId" style="margin-left:10px;padding:5px 10px;background:#fff;color:#333;border:none;border-radius:3px;cursor:pointer;font-weight:bold;font-size:12px;">Copy</button>
        </div>
      </div>
      ${shortId?`<div style="margin:15px 0;">
        <p style="margin:10px 0;color:#fff;"><strong>Short ID:</strong></p>
        <div style="background:#222;padding:12px;border-radius:5px;margin:10px 0;border:1px solid #fff;">
          <code style="font-family:Courier New,monospace;font-size:14px;color:#fff;word-break:break-all;">${esc(shortId)}</code>
          <button id="copyShortId" style="margin-left:10px;padding:5px 10px;background:#fff;color:#333;border:none;border-radius:3px;cursor:pointer;font-weight:bold;font-size:12px;">Copy</button>
        </div>
      </div>`:''}
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#fff;"><strong>Profile URL:</strong></p>
        <p style="margin:10px 0;"><a href="${esc(profileUrl)}" target="_blank" style="color:#9cf;font-family:Courier New,monospace;font-weight:bold;word-break:break-all;text-decoration:none;">${esc(profileUrl)}</a></p>
      </div>
      <div style="margin-top:20px;padding-top:15px;border-top:1px solid #fff;">
        <button id="copyAll" style="padding:10px 20px;background:#ff0050;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold;width:100%;">Copy All Info</button>
      </div>`;
    const copyButton=(id,text)=>{
      const btn=content.querySelector(id);
      if(btn){
        btn.onclick=function(){
          navigator.clipboard.writeText(text).then(()=>{
            const originalText=btn.textContent;
            btn.textContent='Copied!';
            btn.style.background='#5c7e10';
            setTimeout(()=>{
              btn.textContent=originalText;
              btn.style.background='#fff';
            },2000);
          }).catch(()=>{
            prompt('Copy this (Ctrl+C):',text);
          });
        };
      }
    };
    copyButton('#copyUserId',userId);
    if(shortId)copyButton('#copyShortId',shortId);
    const copyAllBtn=content.querySelector('#copyAll');
    if(copyAllBtn){
      const allInfo=`TikTok User ID: ${userId}\nUsername: @${uniqueId}\nDisplay Name: ${nickname}\n${shortId?`Short ID: ${shortId}\n`:''}Profile URL: ${profileUrl}`;
      copyAllBtn.onclick=function(){
        navigator.clipboard.writeText(allInfo).then(()=>{
          copyAllBtn.textContent='All Info Copied!';
          copyAllBtn.style.background='#5c7e10';
          setTimeout(()=>{
            copyAllBtn.textContent='Copy All Info';
            copyAllBtn.style.background='#ff0050';
          },2000);
        }).catch(()=>{
          prompt('Copy all info (Ctrl+C):',allInfo);
        });
      };
    }
  }else{
    content.innerHTML=`<h3 style="margin-top:0;color:#fff;font-size:20px;">TikTok User ID Extractor</h3>
      <p style="color:#ff6b6b;margin:15px 0;">User ID not found on this page.</p>
      <p style="color:#fff;font-size:12px;margin-top:10px;">Make sure you are on a TikTok profile page:</p>
      <ul style="color:#fff;font-size:12px;margin:10px 0;padding-left:20px;">
        <li>tiktok.com/@[username]</li>
      </ul>`;
  }
  modal.appendChild(content);
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){
    if(e.target===closeBtn||e.target.tagName==='BUTTON'||e.target.closest('button')||e.target.tagName==='CODE'||e.target.closest('code'))return;
    dragInfo.isDragging=true;
    dragInfo.offsetX=e.clientX-modal.offsetLeft;
    dragInfo.offsetY=e.clientY-modal.offsetTop;
    modal.style.transform='none';
  };
  document.onmousemove=function(e){
    if(dragInfo.isDragging){
      modal.style.left=e.clientX-dragInfo.offsetX+'px';
      modal.style.top=e.clientY-dragInfo.offsetY+'px';
    }
  };
  document.onmouseup=function(){
    dragInfo.isDragging=false;
  };
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';
  closeBtn.style.position='absolute';
  closeBtn.style.top='5px';
  closeBtn.style.right='10px';
  closeBtn.style.background='none';
  closeBtn.style.border='none';
  closeBtn.style.color='#fff';
  closeBtn.style.fontSize='28px';
  closeBtn.style.cursor='pointer';
  closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';
  closeBtn.style.width='30px';
  closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};
  closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){
    e.stopPropagation();
    document.body.removeChild(modal);
    document.onmousemove=null;
    document.onmouseup=null;
  };
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
}catch(e){
  alert('Error: '+(e&&e.message?e.message:e));
}
})();

