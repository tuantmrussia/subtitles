(function(){
try{
  var scriptContent=document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__').text;
  var jsonData=JSON.parse(scriptContent);
  var defaultScope=jsonData?.__DEFAULT_SCOPE__;
  var userDetails=defaultScope?.['webapp.user-detail'];
  var videoDetails=defaultScope?.['webapp.video-detail'];
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#333';modal.style.color='#fff';modal.style.padding='20px';
  modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='80%';modal.style.maxHeight='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';modal.style.overflow='auto';
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  content.innerHTML=`<h3 style=\"margin-top:0;color:#fff;\">TikTok Extracted Data</h3>
  <h4 style=\"color:#fff;\">User Details</h4>
  <pre style=\"font-family:Courier New,monospace;font-size:12px;white-space:pre-wrap;background:#222;padding:10px;border-radius:5px;overflow-x:auto;\">${JSON.stringify(userDetails,null,2)}</pre>
  <h4 style=\"color:#fff;\">Video Details</h4>
  <pre style=\"font-family:Courier New,monospace;font-size:12px;white-space:pre-wrap;background:#222;padding:10px;border-radius:5px;overflow-x:auto;\">${JSON.stringify(videoDetails,null,2)}</pre>`;
  modal.appendChild(content);
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){if(e.target===closeBtn)return;dragInfo.isDragging=true;dragInfo.offsetX=e.clientX-modal.offsetLeft;dragInfo.offsetY=e.clientY-modal.offsetTop;modal.style.transform='none'};
  document.onmousemove=function(e){if(dragInfo.isDragging){modal.style.left=e.clientX-dragInfo.offsetX+'px';modal.style.top=e.clientY-dragInfo.offsetY+'px'}};
  document.onmouseup=function(){dragInfo.isDragging=false};
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';closeBtn.style.position='absolute';closeBtn.style.top='5px';closeBtn.style.right='10px';
  closeBtn.style.background='none';closeBtn.style.border='none';closeBtn.style.color='#fff';
  closeBtn.style.fontSize='28px';closeBtn.style.cursor='pointer';closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';closeBtn.style.width='30px';closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){e.stopPropagation();document.body.removeChild(modal);document.onmousemove=null;document.onmouseup=null};
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
}catch(e){alert('An error occurred: '+e.message)}})();












