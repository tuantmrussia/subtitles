(function(){
function findProfileInfo(){
  if('18'==document.documentElement.innerHTML.match(/\"pageType\":(\d\d)/)[1]){
    var e=document.documentElement.innerHTML.match(/\"dateCreated\":\"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z)\"/);
    var o=document.documentElement.innerHTML.match(/\"dateModified\":\"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z)\"/);
    var t=e?e[1]:'[Not Present]';
    var n=o?o[1]:'[Not Present]';
    var r=document.getElementById('__NEXT_DATA__');
    var l=JSON.parse(r.text).props.pageProps.userProfile.publicProfileInfo;
    return{createdDate:t,modifiedDate:n,username:l.username,displayName:l.title?l.title:'[Not Present]',bio:l.bio?l.bio:'[Not Present]',location:l.address?l.address:'[Not Present]',websiteUrl:l.websiteUrl?l.websiteUrl:'[Not Present]'}
  }
  return alert('Sorry. This Snapchat user has no public profile.');
}
var profileInfo=findProfileInfo();
if(profileInfo){
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#333';modal.style.color='#fff';modal.style.padding='20px';
  modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  let websiteHtml='';
  if(profileInfo.websiteUrl!=='[Not Present]'){
    websiteHtml=`<p>Website: <a href="${profileInfo.websiteUrl}" target="_blank" style="color:#9cf;font-family:Courier New,monospace;font-weight:bold;">${profileInfo.websiteUrl}</a></p>`
  }else{websiteHtml='<p>Website: <strong style=\"font-family:Courier New,monospace;\">[Not Present]</strong></p>'}
  content.innerHTML=`<h3 style=\"margin-top:0;color:#fff;\">Snapchat Profile Information</h3>
  <p>Username: <strong style=\"font-family:Courier New,monospace;\">@${profileInfo.username}</strong></p>
  <p>Display Name: <strong style=\"font-family:Courier New,monospace;\">${profileInfo.displayName}</strong></p>
  <p>Location: <strong style=\"font-family:Courier New,monospace;\">${profileInfo.location}</strong></p>
  <p>Bio: <strong style=\"font-family:Courier New,monospace;\">${profileInfo.bio}</strong></p>
  ${websiteHtml}
  <p>Created Timestamp: <strong style=\"font-family:Courier New,monospace;\">${profileInfo.createdDate}</strong></p>
  <p>Modified Timestamp: <strong style=\"font-family:Courier New,monospace;\">${profileInfo.modifiedDate}</strong></p>
  <p>Current URL: <a href=\"${document.URL}\" target=\"_blank\" style=\"color:#9cf;font-family:Courier New,monospace;font-weight:bold;\">${document.URL}</a></p>`;
  modal.appendChild(content);
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){if(e.target===closeBtn||e.target.tagName==='A')return;dragInfo.isDragging=true;dragInfo.offsetX=e.clientX-modal.offsetLeft;dragInfo.offsetY=e.clientY-modal.offsetTop;modal.style.transform='none'};
  document.onmousemove=function(e){if(dragInfo.isDragging){modal.style.left=e.clientX-dragInfo.offsetX+'px';modal.style.top=e.clientY-dragInfo.offsetY+'px'}};
  document.onmouseup=function(){dragInfo.isDragging=false};
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';closeBtn.style.position='absolute';closeBtn.style.top='5px';closeBtn.style.right='10px';
  closeBtn.style.background='none';closeBtn.style.border='none';closeBtn.style.color='#fff';
  closeBtn.style.fontSize='28px';closeBtn.style.cursor='pointer';closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';closeBtn.style.width='30px';closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){e.stopPropagation();document.body.removeChild(modal);document.onmousemove=null;document.onmouseup=null};
  modal.appendChild(closeBtn);
  document.body.appendChild(modal)
}
})();












