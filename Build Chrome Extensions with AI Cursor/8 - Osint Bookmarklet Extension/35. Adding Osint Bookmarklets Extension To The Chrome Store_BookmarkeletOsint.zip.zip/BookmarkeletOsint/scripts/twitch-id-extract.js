(function(){
try{
  const esc=s=>(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  let userId='';
  let username='';
  let displayName='';
  let profileUrl='';
  
  const url=location.href;
  
  // Extract username from URL
  const urlMatch=url.match(/twitch\.tv\/([^\/\?]+)(?:\?|$|\/)/i);
  if(urlMatch&&urlMatch[1]&&!urlMatch[1].match(/^(videos|clips|directory|p|search|settings|dashboard|moderator|subscriptions|subscriptions\/manage|chat|user|popout|embed|player|collections|login|register|logout|about|jobs|partners|security|turbo|subscriptions\/purchase|bits|wallet|dev|extension|creator|creator-lounge|brand|press|music|videos|videos\/all|videos\/past-broadcasts|videos\/highlights|videos\/uploads|videos\/clips|clips\/all|clips\/past-broadcasts|clips\/highlights|clips\/uploads|collections\/all|collections\/past-broadcasts|collections\/highlights|collections\/uploads|collections\/saved|followers|following|squad|squad\/invite|squad\/settings|squad\/manage|squad\/view|squad\/create|squad\/join|squad\/leave|squad\/kick|squad\/ban|squad\/unban|squad\/mod|squad\/unmod|squad\/owner|squad\/subscriber|squad\/vip|squad\/moderator|squad\/editor|squad\/broadcaster|squad\/admin|squad\/staff|squad\/global_mod|squad\/global_moderator|squad\/twitch|squad\/twitch_mod|squad\/twitch_moderator|squad\/twitch_admin|squad\/twitch_staff|squad\/twitch_partner|squad\/twitch_affiliate|squad\/twitch_broadcaster|squad\/twitch_editor|squad\/twitch_subscriber|squad\/twitch_vip|squad\/twitch_moderator|squad\/twitch_global_mod|squad\/twitch_global_moderator|squad\/twitch_admin|squad\/twitch_staff|squad\/twitch_partner|squad\/twitch_affiliate|squad\/twitch_broadcaster|squad\/twitch_editor|squad\/twitch_subscriber|squad\/twitch_vip|squad\/twitch_moderator|squad\/twitch_global_mod|squad\/twitch_global_moderator)$/i)){
    username=urlMatch[1].toLowerCase();
  }
  
  // Extract user ID from page source and script tags
  const pageSource=document.documentElement.outerHTML;
  const patterns=[
    /"userId":\s*"(\d+)"/i,
    /"user_id":\s*"(\d+)"/i,
    /"userId":\s*(\d+)/i,
    /"user_id":\s*(\d+)/i,
    /"id":\s*"(\d+)"[^}]*"login":\s*"([^"]+)"/i,
    /"login":\s*"([^"]+)"[^}]*"id":\s*"(\d+)"/i,
    /"user":\s*{[^}]*"id":\s*"(\d+)"/i,
    /"channel":\s*{[^}]*"id":\s*"(\d+)"/i,
    /"broadcaster":\s*{[^}]*"id":\s*"(\d+)"/i,
    /"owner":\s*{[^}]*"id":\s*"(\d+)"/i,
    /\/users\/(\d+)/i,
    /helix\/users\?id=(\d+)/i,
    /helix\/users\?login=([^&]+)/i,
    /data-user-id="(\d+)"/i,
    /data-userid="(\d+)"/i,
    /data-user-id=["'](\d+)["']/i,
    /data-userid=["'](\d+)["']/i,
    /user_id["\s:=]+["']?(\d+)["']?/i,
    /userId["\s:=]+["']?(\d+)["']?/i
  ];
  
  // Search in page source
  for(const pattern of patterns){
    const match=pageSource.match(pattern);
    if(match){
      // Check if pattern captured both ID and username
      if(match[2]&&!username){
        username=match[2].toLowerCase();
      }
      if(match[1]&&match[1].length>=5&&match[1].length<=15){
        userId=match[1];
        break;
      }
    }
  }
  
  // Search in script tags
  if(!userId){
    const scriptTags=Array.from(document.querySelectorAll('script'));
    for(const script of scriptTags){
      const content=script.textContent||'';
      for(const pattern of patterns){
        const match=content.match(pattern);
        if(match){
          if(match[2]&&!username){
            username=match[2].toLowerCase();
          }
          if(match[1]&&match[1].length>=5&&match[1].length<=15){
            userId=match[1];
            break;
          }
        }
      }
      if(userId)break;
    }
  }
  
  // Try to find user ID in JSON data structures
  if(!userId){
    const scriptTags=Array.from(document.querySelectorAll('script[type="application/json"], script[id*="data"], script[id*="json"], script:not([src])'));
    for(const script of scriptTags){
      try{
        const content=script.textContent||'';
        if(content.includes('userId')||content.includes('user_id')||content.includes('"id"')&&content.includes('"login"')){
          // Try to parse as JSON
          try{
            const jsonData=JSON.parse(content);
            const findUserId=(obj)=>{
              if(typeof obj==='object'&&obj!==null){
                if(obj.userId||obj.user_id){
                  return obj.userId||obj.user_id;
                }
                if(obj.id&&obj.login&&typeof obj.id==='string'&&obj.id.match(/^\d+$/)){
                  if(!username)username=obj.login.toLowerCase();
                  return obj.id;
                }
                for(const key in obj){
                  const result=findUserId(obj[key]);
                  if(result)return result;
                }
              }
              return null;
            };
            const foundId=findUserId(jsonData);
            if(foundId&&foundId.toString().length>=5&&foundId.toString().length<=15){
              userId=foundId.toString();
              break;
            }
          }catch(e){}
          
          // Try regex patterns on JSON string
          for(const pattern of patterns){
            const match=content.match(pattern);
            if(match){
              if(match[2]&&!username){
                username=match[2].toLowerCase();
              }
              if(match[1]&&match[1].length>=5&&match[1].length<=15){
                userId=match[1];
                break;
              }
            }
          }
          if(userId)break;
        }
      }catch(e){}
    }
  }
  
  // Extract display name from page elements
  if(!displayName){
    const displayNameEl=document.querySelector('h2[data-a-target="user-channel-header-item"]')||
                        document.querySelector('[data-a-target="stream-title"]')||
                        document.querySelector('h1')||
                        document.querySelector('[class*="channel-header"] [class*="name"]')||
                        document.querySelector('[class*="username"]')||
                        document.querySelector('meta[property="og:title"]');
    if(displayNameEl){
      displayName=displayNameEl.textContent||displayNameEl.content||'';
      if(displayName){
        displayName=displayName.replace(/\s*-\s*Twitch.*$/i,'').replace(/\s*on\s+Twitch.*$/i,'').trim();
      }
    }
  }
  
  // Extract display name from meta tags
  if(!displayName){
    const metaTitle=document.querySelector('meta[property="og:title"]');
    if(metaTitle&&metaTitle.content){
      displayName=metaTitle.content.replace(/\s*-\s*Twitch.*$/i,'').replace(/\s*on\s+Twitch.*$/i,'').trim();
    }
  }
  
  // Construct profile URL
  if(username){
    profileUrl='https://www.twitch.tv/'+username;
  }else if(userId){
    profileUrl='https://www.twitch.tv/?user_id='+userId;
  }else{
    profileUrl=url;
  }
  
  // Create modal
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#18181b';modal.style.color='#efeff1';modal.style.padding='20px';
  modal.style.border='2px solid #9146ff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='600px';modal.style.maxHeight='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';modal.style.overflow='auto';
  modal.style.boxShadow='0 0 20px rgba(145,70,255,0.3)';
  
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  
  if(userId||username){
    content.innerHTML=`<h3 style="margin-top:0;color:#9146ff;font-size:20px;">Twitch ID Extractor</h3>
      ${displayName?`<p style="margin:10px 0;color:#efeff1;"><strong>Display Name:</strong> ${esc(displayName)}</p>`:''}
      ${username?`<p style="margin:10px 0;color:#efeff1;"><strong>Username:</strong> <code style="background:#0e0e10;padding:2px 6px;border-radius:3px;font-family:Courier New,monospace;color:#9146ff;">${esc(username)}</code></p>`:''}
      ${userId?`<div style="margin:15px 0;">
        <p style="margin:10px 0;color:#efeff1;"><strong>Twitch User ID:</strong></p>
        <div style="background:#0e0e10;padding:12px;border-radius:5px;margin:10px 0;border:1px solid #9146ff;">
          <code style="font-family:Courier New,monospace;font-size:14px;color:#9146ff;word-break:break-all;">${esc(userId)}</code>
          <button id="copyUserId" style="margin-left:10px;padding:5px 10px;background:#9146ff;color:#fff;border:none;border-radius:3px;cursor:pointer;font-weight:bold;font-size:12px;">Copy</button>
        </div>
      </div>`:''}
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#efeff1;"><strong>Profile URL:</strong></p>
        <p style="margin:10px 0;"><a href="${esc(profileUrl)}" target="_blank" style="color:#9146ff;font-family:Courier New,monospace;font-weight:bold;word-break:break-all;text-decoration:none;">${esc(profileUrl)}</a></p>
      </div>
      ${userId||username?`<div style="margin-top:20px;padding-top:15px;border-top:1px solid #9146ff;">
        <button id="copyAll" style="padding:10px 20px;background:#9146ff;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold;width:100%;">Copy All Info</button>
      </div>`:''}`;
    
    // Add copy functionality
    const copyButton=(id,text)=>{
      const btn=content.querySelector(id);
      if(btn){
        btn.onclick=function(){
          navigator.clipboard.writeText(text).then(()=>{
            const originalText=btn.textContent;
            btn.textContent='Copied!';
            btn.style.background='#5c7e10';
            setTimeout(()=>{
              btn.textContent=originalText;
              btn.style.background='#9146ff';
            },2000);
          }).catch(()=>{
            prompt('Copy this (Ctrl+C):',text);
          });
        };
      }
    };
    
    if(userId)copyButton('#copyUserId',userId);
    
    const copyAllBtn=content.querySelector('#copyAll');
    if(copyAllBtn){
      const allInfo=`Twitch User ID: ${userId||'(not found)'}\nUsername: ${username||'(not found)'}\nDisplay Name: ${displayName||'(not found)'}\nProfile URL: ${profileUrl}`;
      copyAllBtn.onclick=function(){
        navigator.clipboard.writeText(allInfo).then(()=>{
          copyAllBtn.textContent='All Info Copied!';
          copyAllBtn.style.background='#5c7e10';
          setTimeout(()=>{
            copyAllBtn.textContent='Copy All Info';
            copyAllBtn.style.background='#9146ff';
          },2000);
        }).catch(()=>{
          prompt('Copy all info (Ctrl+C):',allInfo);
        });
      };
    }
  }else{
    content.innerHTML=`<h3 style="margin-top:0;color:#9146ff;font-size:20px;">Twitch ID Extractor</h3>
      <p style="color:#ef4444;margin:15px 0;">Twitch user ID or username not found on this page.</p>
      <p style="color:#efeff1;font-size:12px;margin-top:10px;">Make sure you are on a Twitch profile page:</p>
      <ul style="color:#efeff1;font-size:12px;margin:10px 0;padding-left:20px;">
        <li>twitch.tv/[username]</li>
        <li>twitch.tv/[username]/videos</li>
        <li>twitch.tv/[username]/clips</li>
        <li>twitch.tv/[username]/about</li>
      </ul>
      <p style="color:#efeff1;font-size:11px;margin-top:15px;opacity:0.7;">Note: User IDs are typically found in JavaScript data on profile pages. Try scrolling or interacting with the page first.</p>`;
  }
  
  modal.appendChild(content);
  
  // Drag functionality
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){
    if(e.target===closeBtn||e.target.tagName==='BUTTON'||e.target.closest('button')||e.target.tagName==='CODE'||e.target.closest('code'))return;
    dragInfo.isDragging=true;
    dragInfo.offsetX=e.clientX-modal.offsetLeft;
    dragInfo.offsetY=e.clientY-modal.offsetTop;
    modal.style.transform='none';
  };
  document.onmousemove=function(e){
    if(dragInfo.isDragging){
      modal.style.left=e.clientX-dragInfo.offsetX+'px';
      modal.style.top=e.clientY-dragInfo.offsetY+'px';
    }
  };
  document.onmouseup=function(){
    dragInfo.isDragging=false;
  };
  
  // Close button
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';
  closeBtn.style.position='absolute';
  closeBtn.style.top='5px';
  closeBtn.style.right='10px';
  closeBtn.style.background='none';
  closeBtn.style.border='none';
  closeBtn.style.color='#9146ff';
  closeBtn.style.fontSize='28px';
  closeBtn.style.cursor='pointer';
  closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';
  closeBtn.style.width='30px';
  closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};
  closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){
    e.stopPropagation();
    document.body.removeChild(modal);
    document.onmousemove=null;
    document.onmouseup=null;
  };
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
}catch(e){
  alert('Error: '+(e&&e.message?e.message:e));
}
})();

