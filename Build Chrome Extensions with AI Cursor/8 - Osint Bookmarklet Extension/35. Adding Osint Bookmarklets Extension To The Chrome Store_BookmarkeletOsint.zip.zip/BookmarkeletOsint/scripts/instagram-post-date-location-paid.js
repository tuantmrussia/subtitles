(function(){
  var url = window.location.href;
  
  // Check if we're on an Instagram post page
  if (!url.match(/instagram\.com\/p\//) && !url.match(/instagram\.com\/reel\//)) {
    alert('This bookmarklet works on Instagram post pages.\n\nPlease navigate to a post first (e.g., instagram.com/p/... or instagram.com/reel/...)');
    return;
  }
  
  var postDate = null;
  var postTimestamp = null;
  var location = null;
  var locationId = null;
  var paidPartnership = false;
  var brandPartner = null;
  var postId = null;
  
  // Method 1: Extract from GraphQL data in window objects
  try {
    var windowKeys = Object.keys(window);
    for (var i = 0; i < windowKeys.length; i++) {
      var key = windowKeys[i];
      if (key.includes('__REACT') || key.includes('__additionalData') || key.includes('GraphQL') || key.includes('_sharedData')) {
        try {
          var data = window[key];
          if (data && typeof data === 'object') {
            var jsonStr = JSON.stringify(data);
            
            // Extract post ID
            if (!postId) {
              var postIdMatch = jsonStr.match(/"shortcode":"([^"]+)"/);
              if (postIdMatch) {
                postId = postIdMatch[1];
              }
            }
            
            // Extract timestamp
            if (!postTimestamp) {
              var timestampMatch = jsonStr.match(/"taken_at_timestamp":(\d+)/);
              if (timestampMatch) {
                postTimestamp = parseInt(timestampMatch[1]);
                var date = new Date(postTimestamp * 1000);
                postDate = date.toLocaleString();
              }
            }
            
            // Extract location
            if (!location) {
              var locationMatch = jsonStr.match(/"location":\{[^}]*"name":"([^"]+)"[^}]*"id":"([^"]+)"/);
              if (locationMatch) {
                location = locationMatch[1];
                locationId = locationMatch[2];
              } else {
                var locationNameMatch = jsonStr.match(/"location_name":"([^"]+)"/);
                if (locationNameMatch) {
                  location = locationNameMatch[1];
                }
              }
            }
            
            // Extract paid partnership
            if (!paidPartnership) {
              if (jsonStr.includes('"is_paid_partnership":true') || jsonStr.includes('"is_paid_partnership": true')) {
                paidPartnership = true;
                
                // Try to extract brand partner
                var brandMatch = jsonStr.match(/"branded_content_sponsor":\{[^}]*"username":"([^"]+)"/);
                if (brandMatch) {
                  brandPartner = brandMatch[1];
                } else {
                  var sponsorMatch = jsonStr.match(/"sponsor":\{[^}]*"username":"([^"]+)"/);
                  if (sponsorMatch) {
                    brandPartner = sponsorMatch[1];
                  }
                }
              }
            }
          }
        } catch (e) {}
      }
    }
  } catch (e) {}
  
  // Method 2: Extract from page source/HTML
  try {
    var pageSource = document.documentElement.outerHTML;
    
    // Extract timestamp from various patterns
    if (!postTimestamp) {
      var patterns = [
        /"taken_at_timestamp":(\d+)/,
        /"timestamp":(\d{10})/,
        /"date":(\d{10})/,
        /taken_at[":\s]+(\d{10})/
      ];
      for (var p = 0; p < patterns.length; p++) {
        var match = pageSource.match(patterns[p]);
        if (match) {
          postTimestamp = parseInt(match[1]);
          var date = new Date(postTimestamp * 1000);
          postDate = date.toLocaleString();
          break;
        }
      }
    }
    
    // Extract location
    if (!location) {
      var locPatterns = [
        /"location":\{[^}]*"name":"([^"]+)"/,
        /"location_name":"([^"]+)"/,
        /location[":\s]+"([^"]+)"/,
        /<meta[^>]*property="place:location:name"[^>]*content="([^"]+)"/i
      ];
      for (var lp = 0; lp < locPatterns.length; lp++) {
        var locMatch = pageSource.match(locPatterns[lp]);
        if (locMatch) {
          location = locMatch[1];
          break;
        }
      }
    }
    
    // Extract paid partnership
    if (!paidPartnership) {
      if (pageSource.includes('paid partnership') || pageSource.includes('paid_partnership') || 
          pageSource.includes('is_paid_partnership') || pageSource.includes('Paid partnership')) {
        paidPartnership = true;
      }
    }
  } catch (e) {}
  
  // Method 3: Try to parse structured data
  try {
    var scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (var s = 0; s < scripts.length; s++) {
      try {
        var jsonData = JSON.parse(scripts[s].textContent);
        if (jsonData.datePublished && !postDate) {
          var date = new Date(jsonData.datePublished);
          postDate = date.toLocaleString();
          postTimestamp = Math.floor(date.getTime() / 1000);
        }
        if (jsonData.contentLocation && !location) {
          location = jsonData.contentLocation.name || jsonData.contentLocation;
        }
      } catch (e) {}
    }
  } catch (e) {}
  
  // Method 4: Look for time elements in the DOM
  try {
    var timeEl = document.querySelector('time[datetime]');
    if (timeEl && !postDate) {
      var datetime = timeEl.getAttribute('datetime');
      if (datetime) {
        var date = new Date(datetime);
        postDate = date.toLocaleString();
        postTimestamp = Math.floor(date.getTime() / 1000);
      }
    }
  } catch (e) {}
  
  // Create modal to display results
  var modal = document.createElement('div');
  modal.style.position = 'fixed';
  modal.style.top = '50%';
  modal.style.left = '50%';
  modal.style.transform = 'translate(-50%, -50%)';
  modal.style.backgroundColor = '#333';
  modal.style.color = '#fff';
  modal.style.padding = '20px';
  modal.style.border = '2px solid #fff';
  modal.style.borderRadius = '10px';
  modal.style.zIndex = '10000';
  modal.style.maxWidth = '80%';
  modal.style.maxHeight = '80vh';
  modal.style.overflow = 'auto';
  modal.style.textAlign = 'left';
  modal.style.fontFamily = 'Arial, sans-serif';
  modal.style.cursor = 'move';
  modal.style.boxShadow = '0 4px 20px rgba(0,0,0,0.5)';
  
  var content = document.createElement('div');
  content.style.fontFamily = 'Arial, sans-serif';
  content.style.marginTop = '10px';
  
  var html = '<h3 style="margin-top:0;color:#fff;border-bottom:2px solid #fff;padding-bottom:10px;">Instagram Post OSINT Data</h3>';
  
  // Post Date
  html += '<p style="margin:10px 0;"><strong style="color:#9cf;">Post Date:</strong> ';
  if (postDate) {
    html += '<span style="font-family:Courier New,monospace;">' + postDate + '</span>';
    if (postTimestamp) {
      html += '<br><span style="font-size:12px;color:#aaa;">Unix Timestamp: ' + postTimestamp + '</span>';
      var timeAgo = Math.floor((Date.now() / 1000 - postTimestamp) / 86400);
      html += '<br><span style="font-size:12px;color:#aaa;">Posted ' + timeAgo + ' day' + (timeAgo !== 1 ? 's' : '') + ' ago</span>';
    }
  } else {
    html += '<span style="color:#f88;">Not found</span>';
  }
  html += '</p>';
  
  // Location
  html += '<p style="margin:10px 0;"><strong style="color:#9cf;">Location:</strong> ';
  if (location) {
    html += '<span style="font-family:Courier New,monospace;">' + location + '</span>';
    if (locationId) {
      html += '<br><span style="font-size:12px;color:#aaa;">Location ID: ' + locationId + '</span>';
    }
  } else {
    html += '<span style="color:#f88;">Not found</span>';
  }
  html += '</p>';
  
  // Paid Partnership
  html += '<p style="margin:10px 0;"><strong style="color:#9cf;">Paid Partnership:</strong> ';
  if (paidPartnership) {
    html += '<span style="color:#ff6;font-weight:bold;">YES</span>';
    if (brandPartner) {
      html += '<br><span style="font-size:12px;color:#aaa;">Brand Partner: @' + brandPartner + '</span>';
    }
  } else {
    html += '<span style="color:#8f8;">No</span>';
  }
  html += '</p>';
  
  // Post ID
  if (postId) {
    html += '<p style="margin:10px 0;"><strong style="color:#9cf;">Post ID:</strong> ';
    html += '<span style="font-family:Courier New,monospace;">' + postId + '</span>';
    html += '</p>';
  }
  
  // Current URL
  html += '<p style="margin:10px 0;padding-top:10px;border-top:1px solid #666;"><strong style="color:#9cf;">Current URL:</strong> ';
  html += '<a href="' + url + '" target="_blank" style="color:#9cf;font-family:Courier New,monospace;font-weight:bold;word-break:break-all;">' + url + '</a>';
  html += '</p>';
  
  content.innerHTML = html;
  modal.appendChild(content);
  
  // Draggable functionality
  var dragInfo = {isDragging: false, offsetX: 0, offsetY: 0};
  modal.onmousedown = function(e) {
    if (e.target === closeBtn || e.target.tagName === 'A') return;
    dragInfo.isDragging = true;
    dragInfo.offsetX = e.clientX - modal.offsetLeft;
    dragInfo.offsetY = e.clientY - modal.offsetTop;
    modal.style.transform = 'none';
  };
  document.onmousemove = function(e) {
    if (dragInfo.isDragging) {
      modal.style.left = (e.clientX - dragInfo.offsetX) + 'px';
      modal.style.top = (e.clientY - dragInfo.offsetY) + 'px';
    }
  };
  document.onmouseup = function() {
    dragInfo.isDragging = false;
  };
  
  // Close button
  var closeBtn = document.createElement('button');
  closeBtn.innerHTML = '×';
  closeBtn.style.position = 'absolute';
  closeBtn.style.top = '5px';
  closeBtn.style.right = '10px';
  closeBtn.style.background = 'none';
  closeBtn.style.border = 'none';
  closeBtn.style.color = '#fff';
  closeBtn.style.fontSize = '28px';
  closeBtn.style.cursor = 'pointer';
  closeBtn.style.lineHeight = '1';
  closeBtn.style.padding = '0';
  closeBtn.style.width = '30px';
  closeBtn.style.height = '30px';
  closeBtn.onmouseover = function() { this.style.opacity = '0.7'; };
  closeBtn.onmouseout = function() { this.style.opacity = '1'; };
  closeBtn.onclick = function(e) {
    e.stopPropagation();
    document.body.removeChild(modal);
    document.onmousemove = null;
    document.onmouseup = null;
  };
  modal.appendChild(closeBtn);
  
  document.body.appendChild(modal);
})();


