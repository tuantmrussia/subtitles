(function(){
try{
  const esc=s=>(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  let profileId='';
  let profileName='';
  let profileUrl='';
  let username='';
  
  const url=location.href;
  
  // Check URL patterns
  const urlPatterns=[
    /facebook\.com\/profile\.php\?id=(\d+)/i,
    /facebook\.com\/(\d+)(?:\?|$|\/)/i,
    /facebook\.com\/profile\/(\d+)/i,
    /profile\/(\d+)/i
  ];
  
  for(const pattern of urlPatterns){
    const match=url.match(pattern);
    if(match&&match[1]){
      profileId=match[1];
      break;
    }
  }
  
  // Check meta tags
  if(!profileId){
    const metaTags=[
      document.querySelector('meta[property="al:android:url"]'),
      document.querySelector('meta[property="al:ios:url"]'),
      document.querySelector('meta[property="og:url"]'),
      document.querySelector('link[rel="canonical"]')
    ];
    
    for(const meta of metaTags){
      if(meta&&meta.content){
        const metaUrl=meta.content;
        for(const pattern of urlPatterns){
          const match=metaUrl.match(pattern);
          if(match&&match[1]){
            profileId=match[1];
            break;
          }
        }
        if(profileId)break;
      }
    }
  }
  
  // Extract from page source and script tags
  if(!profileId){
    const pageSource=document.documentElement.outerHTML;
    const patterns=[
      /"userID":\s*"(\d+)"/i,
      /"profile_owner":\s*{\s*"id":\s*"(\d+)"/i,
      /"actorID":\s*"(\d+)"/i,
      /"ownerID":\s*"(\d+)"/i,
      /"entity_id":\s*"(\d+)"/i,
      /\/profile\/(\d+)/i,
      /profile\.php\?id=(\d+)/i
    ];
    
    for(const pattern of patterns){
      const match=pageSource.match(pattern);
      if(match&&match[1]&&match[1].length>=10){
        profileId=match[1];
        break;
      }
    }
    
    // Try script tags
    if(!profileId){
      const scriptTags=Array.from(document.querySelectorAll('script'));
      for(const script of scriptTags){
        const content=script.textContent||'';
        for(const pattern of patterns){
          const match=content.match(pattern);
          if(match&&match[1]&&match[1].length>=10){
            profileId=match[1];
            break;
          }
        }
        if(profileId)break;
      }
    }
  }
  
  // Extract profile name
  const namePatterns=[
    /<title>([^<]+)<\/title>/i,
    /"name":\s*"([^"]+)",\s*"__isEntity":\s*"User"/i,
    /"name":\s*"([^"]+)"/i
  ];
  
  const pageSource=document.documentElement.outerHTML;
  for(const pattern of namePatterns){
    const match=pageSource.match(pattern);
    if(match&&match[1]){
      profileName=match[1].replace(/\s*-\s*Facebook.*$/i,'').trim();
      if(profileName&&profileName!=='Facebook')break;
    }
  }
  
  // Extract username from URL
  const urlMatch=url.match(/facebook\.com\/([^\/\?]+)(?:\?|$|\/)/i);
  if(urlMatch&&urlMatch[1]&&!urlMatch[1].match(/^(profile|people|pages|groups|events|watch|marketplace|login|register)/i)){
    username=urlMatch[1];
  }
  
  // Construct profile URL
  if(profileId){
    profileUrl='https://www.facebook.com/profile.php?id='+profileId;
  }else if(username){
    profileUrl='https://www.facebook.com/'+username;
  }
  
  // Create modal
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#1877f2';modal.style.color='#fff';modal.style.padding='20px';
  modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='600px';modal.style.maxHeight='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';modal.style.overflow='auto';
  modal.style.boxShadow='0 0 20px rgba(0,0,0,0.5)';
  
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  
  if(profileId){
    content.innerHTML=`<h3 style="margin-top:0;color:#fff;font-size:20px;">Facebook Profile ID Extractor</h3>
      ${profileName?`<p style="margin:10px 0;color:#fff;"><strong>Profile Name:</strong> ${esc(profileName)}</p>`:''}
      ${username?`<p style="margin:10px 0;color:#fff;"><strong>Username:</strong> <code style="background:rgba(0,0,0,0.3);padding:2px 6px;border-radius:3px;font-family:Courier New,monospace;color:#fff;">${esc(username)}</code></p>`:''}
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#fff;"><strong>Profile ID:</strong></p>
        <div style="background:rgba(0,0,0,0.3);padding:12px;border-radius:5px;margin:10px 0;border:1px solid rgba(255,255,255,0.3);">
          <code style="font-family:Courier New,monospace;font-size:14px;color:#fff;word-break:break-all;">${esc(profileId)}</code>
          <button id="copyId" style="margin-left:10px;padding:5px 10px;background:#fff;color:#1877f2;border:none;border-radius:3px;cursor:pointer;font-weight:bold;font-size:12px;">Copy</button>
        </div>
      </div>
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#fff;"><strong>Profile URL:</strong></p>
        <p style="margin:10px 0;"><a href="${esc(profileUrl)}" target="_blank" style="color:#fff;font-family:Courier New,monospace;font-weight:bold;word-break:break-all;text-decoration:underline;">${esc(profileUrl)}</a></p>
      </div>
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#fff;"><strong>Alternative URLs:</strong></p>
        <p style="margin:5px 0;"><a href="https://www.facebook.com/profile.php?id=${esc(profileId)}" target="_blank" style="color:#fff;font-family:Courier New,monospace;font-size:12px;text-decoration:underline;">profile.php?id=${esc(profileId)}</a></p>
      </div>`;
    
    // Copy functionality
    const copyBtn=content.querySelector('#copyId');
    if(copyBtn){
      copyBtn.onclick=function(){
        navigator.clipboard.writeText(profileId).then(()=>{
          const originalText=copyBtn.textContent;
          copyBtn.textContent='Copied!';
          copyBtn.style.background='#42b72a';
          setTimeout(()=>{
            copyBtn.textContent=originalText;
            copyBtn.style.background='#fff';
          },2000);
        }).catch(()=>{
          prompt('Copy this (Ctrl+C):',profileId);
        });
      };
    }
  }else{
    content.innerHTML=`<h3 style="margin-top:0;color:#fff;font-size:20px;">Facebook Profile ID Extractor</h3>
      <p style="color:#ff6b6b;margin:15px 0;">Profile ID not found on this page.</p>
      <p style="color:#fff;font-size:12px;margin-top:10px;">Make sure you are on a Facebook profile page:</p>
      <ul style="color:#fff;font-size:12px;margin:10px 0;padding-left:20px;">
        <li>facebook.com/profile.php?id=[ID]</li>
        <li>facebook.com/[USERNAME]</li>
        <li>facebook.com/profile/[ID]</li>
      </ul>`;
  }
  
  modal.appendChild(content);
  
  // Drag functionality
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){
    if(e.target===closeBtn||e.target.tagName==='BUTTON'||e.target.closest('button')||e.target.tagName==='CODE'||e.target.closest('code'))return;
    dragInfo.isDragging=true;
    dragInfo.offsetX=e.clientX-modal.offsetLeft;
    dragInfo.offsetY=e.clientY-modal.offsetTop;
    modal.style.transform='none';
  };
  document.onmousemove=function(e){
    if(dragInfo.isDragging){
      modal.style.left=e.clientX-dragInfo.offsetX+'px';
      modal.style.top=e.clientY-dragInfo.offsetY+'px';
    }
  };
  document.onmouseup=function(){
    dragInfo.isDragging=false;
  };
  
  // Close button
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';
  closeBtn.style.position='absolute';
  closeBtn.style.top='5px';
  closeBtn.style.right='10px';
  closeBtn.style.background='none';
  closeBtn.style.border='none';
  closeBtn.style.color='#fff';
  closeBtn.style.fontSize='28px';
  closeBtn.style.cursor='pointer';
  closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';
  closeBtn.style.width='30px';
  closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};
  closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){
    e.stopPropagation();
    document.body.removeChild(modal);
    document.onmousemove=null;
    document.onmouseup=null;
  };
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
}catch(e){
  alert('Error: '+(e&&e.message?e.message:e));
}
})();

