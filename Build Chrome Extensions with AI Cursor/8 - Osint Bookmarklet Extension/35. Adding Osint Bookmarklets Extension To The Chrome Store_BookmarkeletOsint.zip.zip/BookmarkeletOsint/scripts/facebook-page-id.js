(function(){
try{
  const esc=s=>(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  let pageId='';
  let pageName='';
  let pageUrl='';
  let pageSlug='';
  
  const url=location.href;
  
  // Check URL patterns
  const urlPatterns=[
    /facebook\.com\/([^\/\?]+)(?:\?|$|\/)/i,
    /facebook\.com\/pages\/([^\/\?]+)/i,
    /facebook\.com\/page\.php\?id=(\d+)/i
  ];
  
  for(const pattern of urlPatterns){
    const match=url.match(pattern);
    if(match&&match[1]){
      // Exclude common non-page paths
      if(!match[1].match(/^(profile|people|pages|groups|events|watch|marketplace|login|register|help|about|policies|privacy|settings|messages|notifications|bookmarks|saved|games|apps|developers|business|ads|create|recover|checkpoint)/i)){
        pageSlug=match[1];
      }
    }
  }
  
  // Check meta tags
  if(!pageId){
    const metaTags=[
      document.querySelector('meta[property="al:android:url"]'),
      document.querySelector('meta[property="al:ios:url"]'),
      document.querySelector('meta[property="og:url"]'),
      document.querySelector('link[rel="canonical"]')
    ];
    
    for(const meta of metaTags){
      if(meta&&meta.content){
        const metaUrl=meta.content;
        const metaMatch=metaUrl.match(/facebook\.com\/([^\/\?]+)(?:\?|$|\/)/i);
        if(metaMatch&&metaMatch[1]){
          if(!metaMatch[1].match(/^(profile|people|pages|groups|events|watch|marketplace|login|register|help|about)/i)){
            pageSlug=metaMatch[1];
          }
        }
        
        // Try numeric ID patterns
        const idPatterns=[
          /\/pages\/([^\/\?]+)\/(\d+)/i,
          /page\.php\?id=(\d+)/i,
          /\/(\d{10,})(?:\?|$|\/)/i
        ];
        
        for(const pattern of idPatterns){
          const match=metaUrl.match(pattern);
          if(match&&match[1]){
            if(match[1].length>=10){
              pageId=match[1];
              break;
            }
          }
        }
        if(pageId)break;
      }
    }
  }
  
  // Extract from page source and script tags
  if(!pageId){
    const pageSource=document.documentElement.outerHTML;
    const patterns=[
      /"pageID":\s*"(\d+)"/i,
      /"page_id":\s*"(\d+)"/i,
      /"entity_id":\s*"(\d+)"/i,
      /"page":\s*{\s*"id":\s*"(\d+)"/i,
      /"__isEntity":\s*"Page"[^}]*"id":\s*"(\d+)"/i,
      /"id":\s*"(\d+)"[^}]*"__isEntity":\s*"Page"/i,
      /page\.php\?id=(\d+)/i
    ];
    
    for(const pattern of patterns){
      const match=pageSource.match(pattern);
      if(match&&match[1]&&match[1].length>=10){
        pageId=match[1];
        break;
      }
    }
    
    // Try script tags
    if(!pageId){
      const scriptTags=Array.from(document.querySelectorAll('script'));
      for(const script of scriptTags){
        const content=script.textContent||'';
        for(const pattern of patterns){
          const match=content.match(pattern);
          if(match&&match[1]&&match[1].length>=10){
            pageId=match[1];
            break;
          }
        }
        if(pageId)break;
      }
    }
  }
  
  // Extract page name
  const namePatterns=[
    /<title>([^<]+)<\/title>/i,
    /"name":\s*"([^"]+)",\s*"__isEntity":\s*"Page"/i,
    /"name":\s*"([^"]+)"/i
  ];
  
  const pageSource=document.documentElement.outerHTML;
  for(const pattern of namePatterns){
    const match=pageSource.match(pattern);
    if(match&&match[1]){
      pageName=match[1].replace(/\s*-\s*Facebook.*$/i,'').trim();
      if(pageName&&pageName!=='Facebook')break;
    }
  }
  
  // Construct page URL
  if(pageSlug){
    pageUrl='https://www.facebook.com/'+pageSlug;
  }else if(pageId){
    pageUrl='https://www.facebook.com/'+pageId;
  }
  
  // Create modal
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#1877f2';modal.style.color='#fff';modal.style.padding='20px';
  modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='600px';modal.style.maxHeight='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';modal.style.overflow='auto';
  modal.style.boxShadow='0 0 20px rgba(0,0,0,0.5)';
  
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  
  if(pageId||pageSlug){
    content.innerHTML=`<h3 style="margin-top:0;color:#fff;font-size:20px;">Facebook Page ID Extractor</h3>
      ${pageName?`<p style="margin:10px 0;color:#fff;"><strong>Page Name:</strong> ${esc(pageName)}</p>`:''}
      ${pageSlug?`<p style="margin:10px 0;color:#fff;"><strong>Page Slug:</strong> <code style="background:rgba(0,0,0,0.3);padding:2px 6px;border-radius:3px;font-family:Courier New,monospace;color:#fff;">${esc(pageSlug)}</code></p>`:''}
      ${pageId?`<div style="margin:15px 0;">
        <p style="margin:10px 0;color:#fff;"><strong>Page ID:</strong></p>
        <div style="background:rgba(0,0,0,0.3);padding:12px;border-radius:5px;margin:10px 0;border:1px solid rgba(255,255,255,0.3);">
          <code style="font-family:Courier New,monospace;font-size:14px;color:#fff;word-break:break-all;">${esc(pageId)}</code>
          <button id="copyId" style="margin-left:10px;padding:5px 10px;background:#fff;color:#1877f2;border:none;border-radius:3px;cursor:pointer;font-weight:bold;font-size:12px;">Copy</button>
        </div>
      </div>`:''}
      ${pageSlug?`<div style="margin:15px 0;">
        <p style="margin:10px 0;color:#fff;"><strong>Page URL:</strong></p>
        <p style="margin:10px 0;"><a href="${esc(pageUrl)}" target="_blank" style="color:#fff;font-family:Courier New,monospace;font-weight:bold;word-break:break-all;text-decoration:underline;">${esc(pageUrl)}</a></p>
      </div>`:''}
      ${pageId?`<div style="margin:15px 0;">
        <p style="margin:10px 0;color:#fff;"><strong>Note:</strong></p>
        <p style="margin:5px 0;color:#fff;font-size:12px;">Numeric Page IDs are often found in the page source. If not found, the page may use a username/slug instead.</p>
      </div>`:''}`;
    
    // Copy functionality
    if(pageId){
      const copyBtn=content.querySelector('#copyId');
      if(copyBtn){
        copyBtn.onclick=function(){
          navigator.clipboard.writeText(pageId).then(()=>{
            const originalText=copyBtn.textContent;
            copyBtn.textContent='Copied!';
            copyBtn.style.background='#42b72a';
            setTimeout(()=>{
              copyBtn.textContent=originalText;
              copyBtn.style.background='#fff';
            },2000);
          }).catch(()=>{
            prompt('Copy this (Ctrl+C):',pageId);
          });
        };
      }
    }
  }else{
    content.innerHTML=`<h3 style="margin-top:0;color:#fff;font-size:20px;">Facebook Page ID Extractor</h3>
      <p style="color:#ff6b6b;margin:15px 0;">Page ID not found on this page.</p>
      <p style="color:#fff;font-size:12px;margin-top:10px;">Make sure you are on a Facebook page:</p>
      <ul style="color:#fff;font-size:12px;margin:10px 0;padding-left:20px;">
        <li>facebook.com/[PAGENAME]</li>
        <li>facebook.com/pages/[PAGENAME]/[ID]</li>
        <li>facebook.com/page.php?id=[ID]</li>
      </ul>
      <p style="color:#fff;font-size:12px;margin-top:10px;"><strong>Note:</strong> Many Facebook pages only use usernames/slugs and don't expose numeric IDs in the page source.</p>`;
  }
  
  modal.appendChild(content);
  
  // Drag functionality
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){
    if(e.target===closeBtn||e.target.tagName==='BUTTON'||e.target.closest('button')||e.target.tagName==='CODE'||e.target.closest('code'))return;
    dragInfo.isDragging=true;
    dragInfo.offsetX=e.clientX-modal.offsetLeft;
    dragInfo.offsetY=e.clientY-modal.offsetTop;
    modal.style.transform='none';
  };
  document.onmousemove=function(e){
    if(dragInfo.isDragging){
      modal.style.left=e.clientX-dragInfo.offsetX+'px';
      modal.style.top=e.clientY-dragInfo.offsetY+'px';
    }
  };
  document.onmouseup=function(){
    dragInfo.isDragging=false;
  };
  
  // Close button
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';
  closeBtn.style.position='absolute';
  closeBtn.style.top='5px';
  closeBtn.style.right='10px';
  closeBtn.style.background='none';
  closeBtn.style.border='none';
  closeBtn.style.color='#fff';
  closeBtn.style.fontSize='28px';
  closeBtn.style.cursor='pointer';
  closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';
  closeBtn.style.width='30px';
  closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};
  closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){
    e.stopPropagation();
    document.body.removeChild(modal);
    document.onmousemove=null;
    document.onmouseup=null;
  };
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
}catch(e){
  alert('Error: '+(e&&e.message?e.message:e));
}
})();

