(function(){
try{
  const esc=s=>(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  let views=0,subscribers=0;
  function parseNumber(str){
    if(!str)return 0;
    str=str.toString().trim().replace(/,/g,'');
    const match=str.match(/([\d.]+)\s*([KMkm]|million|billion)?/i);
    if(!match)return parseInt(str,10)||0;
    let num=parseFloat(match[1]);
    const unit=(match[2]||'').toLowerCase();
    if(unit==='k'||unit==='thousand')num*=1000;
    else if(unit==='m'||unit==='million')num*=1000000;
    else if(unit==='b'||unit==='billion')num*=1000000000;
    return Math.floor(num);
  }
  function extractViews(){
    const viewSelectors=[
      '#count .view-count',
      'ytd-video-view-count-renderer span',
      '.view-count',
      'yt-formatted-string[aria-label*="view"]',
      '[class*="view-count"]'
    ];
    for(const sel of viewSelectors){
      const el=document.querySelector(sel);
      if(el){
        const text=el.textContent||el.innerText||'';
        const parsed=parseNumber(text);
        if(parsed>0){
          views=parsed;
          return;
        }
      }
    }
    if(window.ytplayer&&window.ytplayer.config&&window.ytplayer.config.args){
      views=parseInt(window.ytplayer.config.args.avg_rating_count||window.ytplayer.config.args.view_count||0,10)||0;
    }
  }
  function extractSubscribers(){
    const subSelectors=[
      '#subscriber-count',
      'ytd-channel-name #subscriber-count',
      'yt-formatted-string[id*="subscriber"]',
      '[class*="subscriber-count"]'
    ];
    for(const sel of subSelectors){
      const el=document.querySelector(sel);
      if(el){
        const text=el.textContent||el.innerText||'';
        const parsed=parseNumber(text);
        if(parsed>0){
          subscribers=parsed;
          return;
        }
      }
    }
  }
  extractViews();
  extractSubscribers();
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#333';modal.style.color='#fff';modal.style.padding='20px';
  modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='600px';modal.style.maxHeight='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';modal.style.overflow='auto';
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  let html=`<h3 style="margin-top:0;color:#fff;">YouTube Money Calculator</h3>
    <p style="color:#aaa;font-size:12px;">CPM ranges from $0.25 to $4.00 per 1000 impressions</p>
    <div style="margin-top:20px;">
      <label style="display:block;margin-bottom:5px;"><strong>Views:</strong></label>
      <input type="text" id="viewsInput" value="${views.toLocaleString()}" style="width:100%;padding:8px;border-radius:5px;border:1px solid #555;background:#222;color:#fff;font-size:14px;margin-bottom:15px;">
      <label style="display:block;margin-bottom:5px;"><strong>Subscribers (optional):</strong></label>
      <input type="text" id="subsInput" value="${subscribers.toLocaleString()}" style="width:100%;padding:8px;border-radius:5px;border:1px solid #555;background:#222;color:#fff;font-size:14px;margin-bottom:15px;">
      <label style="display:block;margin-bottom:5px;"><strong>CPM (Cost Per Mille):</strong></label>
      <input type="text" id="cpmInput" value="2.00" style="width:100%;padding:8px;border-radius:5px;border:1px solid #555;background:#222;color:#fff;font-size:14px;margin-bottom:15px;">
      <p style="color:#aaa;font-size:11px;margin-top:-10px;margin-bottom:15px;">Default: $2.00 (average)</p>
      <button id="calculateBtn" style="width:100%;padding:10px;background:#f00;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold;font-size:16px;">Calculate Revenue</button>
    </div>
    <div id="results" style="margin-top:20px;display:none;"></div>`;
  content.innerHTML=html;
  const viewsInput=content.querySelector('#viewsInput');
  const subsInput=content.querySelector('#subsInput');
  const cpmInput=content.querySelector('#cpmInput');
  const calculateBtn=content.querySelector('#calculateBtn');
  const resultsDiv=content.querySelector('#results');
  function calculate(){
    const v=parseNumber(viewsInput.value)||0;
    const cpm=parseFloat(cpmInput.value)||2.0;
    if(v<=0){
      resultsDiv.innerHTML='<p style="color:#faa;">Please enter a valid number of views.</p>';
      resultsDiv.style.display='block';
      return;
    }
    const impressions=Math.floor(v*0.8);
    const revenuePer1k=cpm;
    const totalRevenue=(impressions/1000)*revenuePer1k;
    const monthlyViews=v/12;
    const monthlyRevenue=(monthlyViews*0.8/1000)*revenuePer1k;
    const yearlyRevenue=monthlyRevenue*12;
    const subCount=parseNumber(subsInput.value)||0;
    let revenuePerSub='';
    if(subCount>0){
      revenuePerSub=`<p style="margin:10px 0;"><strong>Revenue per Subscriber:</strong> $${(totalRevenue/subCount).toFixed(4)}</p>`;
    }
    resultsDiv.innerHTML=`<div style="background:#222;padding:15px;border-radius:5px;margin-top:15px;">
      <h4 style="margin-top:0;color:#9cf;">Estimated Revenue</h4>
      <p style="margin:10px 0;"><strong>Total Views:</strong> ${v.toLocaleString()}</p>
      <p style="margin:10px 0;"><strong>Estimated Impressions (80%):</strong> ${impressions.toLocaleString()}</p>
      <p style="margin:10px 0;"><strong>CPM:</strong> $${cpm.toFixed(2)}</p>
      <p style="margin:10px 0;font-size:18px;color:#9cf;"><strong>Total Revenue:</strong> $${totalRevenue.toFixed(2)}</p>
      <p style="margin:10px 0;"><strong>Monthly Revenue (if views/month):</strong> $${monthlyRevenue.toFixed(2)}</p>
      <p style="margin:10px 0;"><strong>Yearly Revenue:</strong> $${yearlyRevenue.toFixed(2)}</p>
      ${revenuePerSub}
      <p style="margin-top:15px;color:#aaa;font-size:11px;">Note: Revenue varies based on ad type, viewer location, video category, and audience demographics. This is an estimate only.</p>
    </div>`;
    resultsDiv.style.display='block';
  }
  calculateBtn.onclick=calculate;
  viewsInput.onkeypress=function(e){if(e.key==='Enter')calculate();};
  subsInput.onkeypress=function(e){if(e.key==='Enter')calculate();};
  cpmInput.onkeypress=function(e){if(e.key==='Enter')calculate();};
  modal.appendChild(content);
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){if(e.target===closeBtn||e.target.tagName==='INPUT'||e.target.tagName==='BUTTON'||e.target.closest('button'))return;dragInfo.isDragging=true;dragInfo.offsetX=e.clientX-modal.offsetLeft;dragInfo.offsetY=e.clientY-modal.offsetTop;modal.style.transform='none'};
  document.onmousemove=function(e){if(dragInfo.isDragging){modal.style.left=e.clientX-dragInfo.offsetX+'px';modal.style.top=e.clientY-dragInfo.offsetY+'px'}};
  document.onmouseup=function(){dragInfo.isDragging=false};
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';closeBtn.style.position='absolute';closeBtn.style.top='5px';closeBtn.style.right='10px';
  closeBtn.style.background='none';closeBtn.style.border='none';closeBtn.style.color='#fff';
  closeBtn.style.fontSize='28px';closeBtn.style.cursor='pointer';closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';closeBtn.style.width='30px';closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){e.stopPropagation();document.body.removeChild(modal);document.onmousemove=null;document.onmouseup=null};
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
}catch(e){alert('Error: '+(e&&e.message?e.message:e))}
})();



