(function(){
try{
  const esc=s=>(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  const tags=[];
  const metaTags=document.querySelectorAll('meta[property="og:video:tag"],meta[name="keywords"]');
  for(const meta of metaTags){
    const content=meta.content||'';
    if(content){
      const splitTags=content.split(',').map(t=>t.trim()).filter(t=>t.length>0);
      tags.push(...splitTags);
    }
  }
  const scriptTags=Array.from(document.querySelectorAll('script'));
  for(const script of scriptTags){
    const content=script.textContent||'';
    const tagMatches=[
      content.match(/"keywords":\s*\[([^\]]+)\]/),
      content.match(/"videoTags":\s*\[([^\]]+)\]/),
      content.match(/"tags":\s*\[([^\]]+)\]/),
      content.match(/keywords["\s:]+\[([^\]]+)\]/),
      content.match(/videoTags["\s:]+\[([^\]]+)\]/)
    ];
    for(const match of tagMatches){
      if(match&&match[1]){
        const tagStr=match[1];
        const extractedTags=tagStr.match(/"([^"]+)"/g)||tagStr.match(/'([^']+)'/g);
        if(extractedTags){
          extractedTags.forEach(t=>{
            const tag=t.replace(/["']/g,'').trim();
            if(tag&&!tags.includes(tag))tags.push(tag);
          });
        }
      }
    }
    if(content.includes('"keywords"')||content.includes('"videoTags"')||content.includes('"tags"')){
      try{
        const jsonMatch=content.match(/\{[^}]*"keywords"[^}]*\}/)||content.match(/\{[^}]*"videoTags"[^}]*\}/)||content.match(/\{[^}]*"tags"[^}]*\}/);
        if(jsonMatch){
          const jsonStr=jsonMatch[0];
          const keywordMatch=jsonStr.match(/"keywords":\s*\[([^\]]+)\]/)||jsonStr.match(/"videoTags":\s*\[([^\]]+)\]/)||jsonStr.match(/"tags":\s*\[([^\]]+)\]/);
          if(keywordMatch&&keywordMatch[1]){
            const tagStr=keywordMatch[1];
            const extractedTags=tagStr.match(/"([^"]+)"/g)||tagStr.match(/'([^']+)'/g);
            if(extractedTags){
              extractedTags.forEach(t=>{
                const tag=t.replace(/["']/g,'').trim();
                if(tag&&!tags.includes(tag))tags.push(tag);
              });
            }
          }
        }
      }catch(e){}
    }
  }
  if(window.ytplayer&&window.ytplayer.config&&window.ytplayer.config.args){
    const ytTags=window.ytplayer.config.args.keywords||window.ytplayer.config.args.tags||[];
    if(Array.isArray(ytTags)){
      ytTags.forEach(tag=>{
        if(tag&&typeof tag==='string'&&!tags.includes(tag))tags.push(tag);
      });
    }else if(typeof ytTags==='string'){
      const splitTags=ytTags.split(',').map(t=>t.trim()).filter(t=>t.length>0);
      splitTags.forEach(tag=>{
        if(!tags.includes(tag))tags.push(tag);
      });
    }
  }
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#333';modal.style.color='#fff';modal.style.padding='20px';
  modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='600px';modal.style.maxHeight='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';modal.style.overflow='auto';
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  if(tags.length>0){
    const tagsHtml=tags.map(tag=>`<span style="display:inline-block;background:#222;padding:5px 10px;margin:5px;border-radius:3px;border:1px solid #555;">${esc(tag)}</span>`).join('');
    const tagsText=tags.join(', ');
    content.innerHTML=`<h3 style="margin-top:0;color:#fff;">YouTube Tag Extractor</h3>
      <p style="color:#aaa;font-size:12px;margin-bottom:15px;">Found ${tags.length} tag${tags.length!==1?'s':''}</p>
      <div style="margin-bottom:15px;">
        ${tagsHtml}
      </div>
      <p style="margin-top:20px;"><strong>Tags (copyable):</strong></p>
      <textarea id="tagsText" readonly style="width:100%;height:100px;padding:10px;border-radius:5px;border:1px solid #555;background:#222;color:#fff;font-family:Courier New,monospace;font-size:12px;resize:vertical;">${esc(tagsText)}</textarea>
      <button id="copyTags" style="margin-top:10px;padding:8px 16px;background:#f00;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold;">Copy Tags</button>`;
    const copyBtn=content.querySelector('#copyTags');
    const tagsTextarea=content.querySelector('#tagsText');
    copyBtn.onclick=function(){
      tagsTextarea.select();
      document.execCommand('copy');
      navigator.clipboard.writeText(tagsText).then(()=>{
        copyBtn.textContent='Copied!';
        setTimeout(()=>{copyBtn.textContent='Copy Tags';},2000);
      }).catch(()=>{
        copyBtn.textContent='Use Ctrl+C';
        setTimeout(()=>{copyBtn.textContent='Copy Tags';},2000);
      });
    };
  }else{
    content.innerHTML=`<h3 style="margin-top:0;color:#fff;">YouTube Tag Extractor</h3>
      <p style="color:#faa;">No tags found on this page.</p>
      <p style="color:#aaa;font-size:12px;margin-top:10px;">Make sure you are on a YouTube video page. Some videos may not have tags.</p>`;
  }
  modal.appendChild(content);
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){if(e.target===closeBtn||e.target.tagName==='BUTTON'||e.target.tagName==='TEXTAREA'||e.target.closest('button'))return;dragInfo.isDragging=true;dragInfo.offsetX=e.clientX-modal.offsetLeft;dragInfo.offsetY=e.clientY-modal.offsetTop;modal.style.transform='none'};
  document.onmousemove=function(e){if(dragInfo.isDragging){modal.style.left=e.clientX-dragInfo.offsetX+'px';modal.style.top=e.clientY-dragInfo.offsetY+'px'}};
  document.onmouseup=function(){dragInfo.isDragging=false};
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';closeBtn.style.position='absolute';closeBtn.style.top='5px';closeBtn.style.right='10px';
  closeBtn.style.background='none';closeBtn.style.border='none';closeBtn.style.color='#fff';
  closeBtn.style.fontSize='28px';closeBtn.style.cursor='pointer';closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';closeBtn.style.width='30px';closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){e.stopPropagation();document.body.removeChild(modal);document.onmousemove=null;document.onmouseup=null};
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
}catch(e){alert('Error: '+(e&&e.message?e.message:e))}
})();



