(function(){
try{
  const DISCORD_EPOCH = 1420070400000n; // January 1, 2015, 00:00:00 UTC in milliseconds
  const esc = s => (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  
  // Convert Discord snowflake to timestamp
  const decodeSnowflake = (snowflake) => {
    try {
      const id = BigInt(snowflake);
      const timestamp = Number((id >> 22n) + DISCORD_EPOCH);
      const date = new Date(timestamp);
      if (isNaN(date.getTime())) return null;
      return {
        timestamp: timestamp,
        iso: date.toISOString(),
        local: date.toLocaleString(),
        date: date.toDateString(),
        time: date.toTimeString()
      };
    } catch (e) {
      return null;
    }
  };
  
  // Find Discord snowflakes in various places
  const findSnowflakes = () => {
    const snowflakes = new Map();
    const snowflakeRegex = /\b(\d{17,19})\b/g;
    
    // Check URL
    const url = location.href;
    const urlMatches = url.match(snowflakeRegex);
    if (urlMatches) {
      urlMatches.forEach(match => {
        const decoded = decodeSnowflake(match);
        if (decoded) {
          if (!snowflakes.has(match)) {
            snowflakes.set(match, { source: 'URL', decoded });
          }
        }
      });
    }
    
    // Check page HTML content
    const html = document.documentElement.innerHTML;
    const htmlMatches = html.match(snowflakeRegex);
    if (htmlMatches) {
      htmlMatches.forEach(match => {
        const decoded = decodeSnowflake(match);
        if (decoded) {
          if (!snowflakes.has(match)) {
            const existing = snowflakes.get(match);
            if (!existing) {
              snowflakes.set(match, { source: 'Page Content', decoded });
            }
          }
        }
      });
    }
    
    // Check data attributes
    const allElements = document.querySelectorAll('*');
    allElements.forEach(el => {
      Array.from(el.attributes).forEach(attr => {
        if (attr.value) {
          const matches = attr.value.match(snowflakeRegex);
          if (matches) {
            matches.forEach(match => {
              const decoded = decodeSnowflake(match);
              if (decoded) {
                if (!snowflakes.has(match)) {
                  snowflakes.set(match, { source: `Data Attribute (${attr.name})`, decoded });
                }
              }
            });
          }
        }
      });
    });
    
    // Check text content of specific Discord-related elements
    const discordSelectors = [
      '[class*="message"]',
      '[class*="channel"]',
      '[class*="user"]',
      '[class*="guild"]',
      '[id*="message"]',
      '[id*="channel"]',
      '[id*="user"]'
    ];
    
    discordSelectors.forEach(selector => {
      try {
        const elements = document.querySelectorAll(selector);
        elements.forEach(el => {
          if (el.textContent) {
            const matches = el.textContent.match(snowflakeRegex);
            if (matches) {
              matches.forEach(match => {
                const decoded = decodeSnowflake(match);
                if (decoded) {
                  if (!snowflakes.has(match)) {
                    snowflakes.set(match, { source: 'Discord Element', decoded });
                  }
                }
              });
            }
          }
        });
      } catch (e) {}
    });
    
    return Array.from(snowflakes.entries()).map(([id, info]) => ({ id, ...info }));
  };
  
  const found = findSnowflakes();
  
  const modal = document.createElement('div');
  modal.style.position = 'fixed';
  modal.style.top = '50%';
  modal.style.left = '50%';
  modal.style.transform = 'translate(-50%, -50%)';
  modal.style.backgroundColor = '#333';
  modal.style.color = '#fff';
  modal.style.padding = '20px';
  modal.style.border = '2px solid #fff';
  modal.style.borderRadius = '10px';
  modal.style.zIndex = '10000';
  modal.style.maxWidth = '90%';
  modal.style.maxHeight = '80%';
  modal.style.textAlign = 'left';
  modal.style.fontFamily = 'Arial, sans-serif';
  modal.style.cursor = 'move';
  modal.style.overflow = 'auto';
  
  const content = document.createElement('div');
  content.style.fontFamily = 'Arial, sans-serif';
  content.style.marginTop = '30px';
  
  if (found.length === 0) {
    content.innerHTML = `<h3 style="margin-top:0;color:#fff;">Discord Snowflake Extractor</h3>
      <p style="color:#ff6b6b;">No valid Discord snowflakes found on this page.</p>
      <p style="font-size:12px;color:#aaa;">Tip: Try this on Discord web pages, URLs with numeric IDs, or pages containing Discord content.</p>`;
  } else {
    let html = `<h3 style="margin-top:0;color:#fff;">Discord Snowflake Extractor</h3>
      <p style="margin-bottom:15px;">Found <strong>${found.length}</strong> unique snowflake${found.length > 1 ? 's' : ''}:</p>`;
    
    found.forEach((item, index) => {
      const d = item.decoded;
      html += `<div style="background:#222;padding:15px;margin-bottom:15px;border-radius:5px;border:1px solid #555;">
        <p style="margin:5px 0;"><strong>Snowflake ID:</strong> <code style="background:#111;padding:2px 6px;border-radius:3px;font-family:Courier New,monospace;color:#9cf;">${esc(item.id)}</code></p>
        <p style="margin:5px 0;"><strong>Source:</strong> <span style="color:#aaa;">${esc(item.source)}</span></p>
        <p style="margin:5px 0;"><strong>Timestamp (Unix):</strong> <code style="background:#111;padding:2px 6px;border-radius:3px;font-family:Courier New,monospace;">${d.timestamp}</code></p>
        <p style="margin:5px 0;"><strong>ISO Date:</strong> <code style="background:#111;padding:2px 6px;border-radius:3px;font-family:Courier New,monospace;color:#9cf;">${esc(d.iso)}</code></p>
        <p style="margin:5px 0;"><strong>Local Date:</strong> <code style="background:#111;padding:2px 6px;border-radius:3px;font-family:Courier New,monospace;">${esc(d.local)}</code></p>
        <p style="margin:5px 0;"><strong>Date:</strong> <code style="background:#111;padding:2px 6px;border-radius:3px;font-family:Courier New,monospace;">${esc(d.date)}</code></p>
        <p style="margin:5px 0;"><strong>Time:</strong> <code style="background:#111;padding:2px 6px;border-radius:3px;font-family:Courier New,monospace;">${esc(d.time)}</code></p>
        <button onclick="navigator.clipboard.writeText('${esc(item.id)}').then(()=>alert('Copied!')).catch(()=>alert('Copy failed'))" style="margin-top:8px;padding:5px 10px;background:#5865F2;color:#fff;border:none;border-radius:3px;cursor:pointer;font-size:12px;">Copy Snowflake</button>
        <button onclick="navigator.clipboard.writeText('${esc(d.iso)}').then(()=>alert('Copied!')).catch(()=>alert('Copy failed'))" style="margin-top:8px;margin-left:5px;padding:5px 10px;background:#5865F2;color:#fff;border:none;border-radius:3px;cursor:pointer;font-size:12px;">Copy Timestamp</button>
      </div>`;
    });
    
    content.innerHTML = html;
  }
  
  modal.appendChild(content);
  
  var dragInfo = { isDragging: false, offsetX: 0, offsetY: 0 };
  modal.onmousedown = function(e) {
    if (e.target === closeBtn || e.target.tagName === 'BUTTON' || e.target.tagName === 'CODE') return;
    dragInfo.isDragging = true;
    dragInfo.offsetX = e.clientX - modal.offsetLeft;
    dragInfo.offsetY = e.clientY - modal.offsetTop;
    modal.style.transform = 'none';
  };
  document.onmousemove = function(e) {
    if (dragInfo.isDragging) {
      modal.style.left = (e.clientX - dragInfo.offsetX) + 'px';
      modal.style.top = (e.clientY - dragInfo.offsetY) + 'px';
    }
  };
  document.onmouseup = function() {
    dragInfo.isDragging = false;
  };
  
  var closeBtn = document.createElement('button');
  closeBtn.innerHTML = '×';
  closeBtn.style.position = 'absolute';
  closeBtn.style.top = '5px';
  closeBtn.style.right = '10px';
  closeBtn.style.background = 'none';
  closeBtn.style.border = 'none';
  closeBtn.style.color = '#fff';
  closeBtn.style.fontSize = '28px';
  closeBtn.style.cursor = 'pointer';
  closeBtn.style.lineHeight = '1';
  closeBtn.style.padding = '0';
  closeBtn.style.width = '30px';
  closeBtn.style.height = '30px';
  closeBtn.onmouseover = function() { this.style.opacity = '0.7'; };
  closeBtn.onmouseout = function() { this.style.opacity = '1'; };
  closeBtn.onclick = function(e) {
    e.stopPropagation();
    document.body.removeChild(modal);
    document.onmousemove = null;
    document.onmouseup = null;
  };
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
} catch(e) {
  alert('Discord Snowflake Extractor error: ' + (e && e.message ? e.message : e));
}
})();





