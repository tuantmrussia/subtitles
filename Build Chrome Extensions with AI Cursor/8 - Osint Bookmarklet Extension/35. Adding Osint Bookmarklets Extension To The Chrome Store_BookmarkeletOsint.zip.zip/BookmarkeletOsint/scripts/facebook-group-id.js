(function(){
try{
  const esc=s=>(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  let groupId='';
  let groupName='';
  let groupUrl='';
  let groupSlug='';
  
  const url=location.href;
  
  // Check URL patterns
  const urlPatterns=[
    /facebook\.com\/groups\/(\d+)(?:\?|$|\/)/i,
    /facebook\.com\/group\.php\?gid=(\d+)/i,
    /\/groups\/(\d+)/i,
    /gid=(\d+)/i
  ];
  
  for(const pattern of urlPatterns){
    const match=url.match(pattern);
    if(match&&match[1]){
      groupId=match[1];
      break;
    }
  }
  
  // Check for group slug in URL (non-numeric)
  const slugMatch=url.match(/facebook\.com\/groups\/([^\/\?]+)(?:\?|$|\/)/i);
  if(slugMatch&&slugMatch[1]&&!slugMatch[1].match(/^\d+$/)){
    groupSlug=slugMatch[1];
  }
  
  // Check meta tags
  if(!groupId){
    const metaTags=[
      document.querySelector('meta[property="al:android:url"]'),
      document.querySelector('meta[property="al:ios:url"]'),
      document.querySelector('meta[property="og:url"]'),
      document.querySelector('link[rel="canonical"]')
    ];
    
    for(const meta of metaTags){
      if(meta&&meta.content){
        const metaUrl=meta.content;
        for(const pattern of urlPatterns){
          const match=metaUrl.match(pattern);
          if(match&&match[1]){
            groupId=match[1];
            break;
          }
        }
        if(groupId)break;
      }
    }
  }
  
  // Extract from page source and script tags
  if(!groupId){
    const pageSource=document.documentElement.outerHTML;
    const patterns=[
      /"groupID":\s*"(\d+)"/i,
      /"group_id":\s*"(\d+)"/i,
      /"entity_id":\s*"(\d+)"/i,
      /"gid":\s*"(\d+)"/i,
      /"group":\s*{\s*"id":\s*"(\d+)"/i,
      /\/groups\/(\d+)/i,
      /group\.php\?gid=(\d+)/i
    ];
    
    for(const pattern of patterns){
      const match=pageSource.match(pattern);
      if(match&&match[1]&&match[1].length>=10){
        groupId=match[1];
        break;
      }
    }
    
    // Try script tags
    if(!groupId){
      const scriptTags=Array.from(document.querySelectorAll('script'));
      for(const script of scriptTags){
        const content=script.textContent||'';
        for(const pattern of patterns){
          const match=content.match(pattern);
          if(match&&match[1]&&match[1].length>=10){
            groupId=match[1];
            break;
          }
        }
        if(groupId)break;
      }
    }
  }
  
  // Extract group name
  const namePatterns=[
    /<title>([^<]+)<\/title>/i,
    /"name":\s*"([^"]+)",\s*"__isEntity":\s*"Group"/i,
    /"name":\s*"([^"]+)"/i
  ];
  
  const pageSource=document.documentElement.outerHTML;
  for(const pattern of namePatterns){
    const match=pageSource.match(pattern);
    if(match&&match[1]){
      groupName=match[1].replace(/\s*-\s*Facebook.*$/i,'').trim();
      if(groupName&&groupName!=='Facebook')break;
    }
  }
  
  // Construct group URL
  if(groupId){
    groupUrl='https://www.facebook.com/groups/'+groupId;
  }else if(groupSlug){
    groupUrl='https://www.facebook.com/groups/'+groupSlug;
  }
  
  // Create modal
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#1877f2';modal.style.color='#fff';modal.style.padding='20px';
  modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='600px';modal.style.maxHeight='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';modal.style.overflow='auto';
  modal.style.boxShadow='0 0 20px rgba(0,0,0,0.5)';
  
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  
  if(groupId){
    content.innerHTML=`<h3 style="margin-top:0;color:#fff;font-size:20px;">Facebook Group ID Extractor</h3>
      ${groupName?`<p style="margin:10px 0;color:#fff;"><strong>Group Name:</strong> ${esc(groupName)}</p>`:''}
      ${groupSlug?`<p style="margin:10px 0;color:#fff;"><strong>Group Slug:</strong> <code style="background:rgba(0,0,0,0.3);padding:2px 6px;border-radius:3px;font-family:Courier New,monospace;color:#fff;">${esc(groupSlug)}</code></p>`:''}
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#fff;"><strong>Group ID:</strong></p>
        <div style="background:rgba(0,0,0,0.3);padding:12px;border-radius:5px;margin:10px 0;border:1px solid rgba(255,255,255,0.3);">
          <code style="font-family:Courier New,monospace;font-size:14px;color:#fff;word-break:break-all;">${esc(groupId)}</code>
          <button id="copyId" style="margin-left:10px;padding:5px 10px;background:#fff;color:#1877f2;border:none;border-radius:3px;cursor:pointer;font-weight:bold;font-size:12px;">Copy</button>
        </div>
      </div>
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#fff;"><strong>Group URL:</strong></p>
        <p style="margin:10px 0;"><a href="${esc(groupUrl)}" target="_blank" style="color:#fff;font-family:Courier New,monospace;font-weight:bold;word-break:break-all;text-decoration:underline;">${esc(groupUrl)}</a></p>
      </div>
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#fff;"><strong>Alternative URLs:</strong></p>
        <p style="margin:5px 0;"><a href="https://www.facebook.com/groups/${esc(groupId)}" target="_blank" style="color:#fff;font-family:Courier New,monospace;font-size:12px;text-decoration:underline;">groups/${esc(groupId)}</a></p>
        <p style="margin:5px 0;"><a href="https://www.facebook.com/group.php?gid=${esc(groupId)}" target="_blank" style="color:#fff;font-family:Courier New,monospace;font-size:12px;text-decoration:underline;">group.php?gid=${esc(groupId)}</a></p>
      </div>`;
    
    // Copy functionality
    const copyBtn=content.querySelector('#copyId');
    if(copyBtn){
      copyBtn.onclick=function(){
        navigator.clipboard.writeText(groupId).then(()=>{
          const originalText=copyBtn.textContent;
          copyBtn.textContent='Copied!';
          copyBtn.style.background='#42b72a';
          setTimeout(()=>{
            copyBtn.textContent=originalText;
            copyBtn.style.background='#fff';
          },2000);
        }).catch(()=>{
          prompt('Copy this (Ctrl+C):',groupId);
        });
      };
    }
  }else{
    content.innerHTML=`<h3 style="margin-top:0;color:#fff;font-size:20px;">Facebook Group ID Extractor</h3>
      <p style="color:#ff6b6b;margin:15px 0;">Group ID not found on this page.</p>
      <p style="color:#fff;font-size:12px;margin-top:10px;">Make sure you are on a Facebook group page:</p>
      <ul style="color:#fff;font-size:12px;margin:10px 0;padding-left:20px;">
        <li>facebook.com/groups/[ID]</li>
        <li>facebook.com/groups/[SLUG]</li>
        <li>facebook.com/group.php?gid=[ID]</li>
      </ul>`;
  }
  
  modal.appendChild(content);
  
  // Drag functionality
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){
    if(e.target===closeBtn||e.target.tagName==='BUTTON'||e.target.closest('button')||e.target.tagName==='CODE'||e.target.closest('code'))return;
    dragInfo.isDragging=true;
    dragInfo.offsetX=e.clientX-modal.offsetLeft;
    dragInfo.offsetY=e.clientY-modal.offsetTop;
    modal.style.transform='none';
  };
  document.onmousemove=function(e){
    if(dragInfo.isDragging){
      modal.style.left=e.clientX-dragInfo.offsetX+'px';
      modal.style.top=e.clientY-dragInfo.offsetY+'px';
    }
  };
  document.onmouseup=function(){
    dragInfo.isDragging=false;
  };
  
  // Close button
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';
  closeBtn.style.position='absolute';
  closeBtn.style.top='5px';
  closeBtn.style.right='10px';
  closeBtn.style.background='none';
  closeBtn.style.border='none';
  closeBtn.style.color='#fff';
  closeBtn.style.fontSize='28px';
  closeBtn.style.cursor='pointer';
  closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';
  closeBtn.style.width='30px';
  closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};
  closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){
    e.stopPropagation();
    document.body.removeChild(modal);
    document.onmousemove=null;
    document.onmouseup=null;
  };
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
}catch(e){
  alert('Error: '+(e&&e.message?e.message:e));
}
})();

