(function(){
try{
  const esc=s=>(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  let channelId='';
  const url=location.href;
  const urlMatch=url.match(/[?&]channel_id=([^&]+)/)||url.match(/\/channel\/([^\/\?]+)/);
  if(urlMatch&&urlMatch[1])channelId=urlMatch[1];
  if(!channelId){
    const canonicalLink=document.querySelector('link[rel="canonical"]')?.href||'';
    if(canonicalLink){
      const canonMatch=canonicalLink.match(/[?&]channel_id=([^&]+)/)||canonicalLink.match(/\/channel\/([^\/\?]+)/);
      if(canonMatch&&canonMatch[1])channelId=canonMatch[1];
    }
  }
  if(!channelId){
    const metaChannel=document.querySelector('meta[itemprop="channelId"]')?.content||document.querySelector('meta[property="og:video:channel_id"]')?.content||'';
    if(metaChannel)channelId=metaChannel;
  }
  if(!channelId){
    const scriptTags=Array.from(document.querySelectorAll('script'));
    for(const script of scriptTags){
      const content=script.textContent||'';
      const matches=[
        content.match(/"channelId":\s*"([^"]+)"/),
        content.match(/"channel_id":\s*"([^"]+)"/),
        content.match(/"ucid":\s*"([^"]+)"/),
        content.match(/channelId["\s:]+["']([^"']+)["']/),
        content.match(/channel_id["\s:]+["']([^"']+)["']/)
      ];
      for(const match of matches){
        if(match&&match[1]&&match[1].length>10){
          channelId=match[1];
          break;
        }
      }
      if(channelId)break;
    }
  }
  if(!channelId){
    const ownerLink=document.querySelector('a[href*="/channel/"]')?.href||document.querySelector('a[href*="channel_id="]')?.href||'';
    if(ownerLink){
      const ownerMatch=ownerLink.match(/\/channel\/([^\/\?]+)/)||ownerLink.match(/[?&]channel_id=([^&]+)/);
      if(ownerMatch&&ownerMatch[1])channelId=ownerMatch[1];
    }
  }
  if(!channelId){
    const channelLink=document.querySelector('ytd-channel-name a[href*="/channel/"]')?.href||document.querySelector('ytd-video-owner-renderer a[href*="/channel/"]')?.href||'';
    if(channelLink){
      const chanMatch=channelLink.match(/\/channel\/([^\/\?]+)/);
      if(chanMatch&&chanMatch[1])channelId=chanMatch[1];
    }
  }
  if(!channelId&&window.ytplayer&&window.ytplayer.config&&window.ytplayer.config.args){
    channelId=window.ytplayer.config.args.channel_id||window.ytplayer.config.args.channelId||'';
  }
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#333';modal.style.color='#fff';modal.style.padding='20px';
  modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='500px';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  if(channelId){
    const channelUrl='https://www.youtube.com/channel/'+channelId;
    content.innerHTML=`<h3 style="margin-top:0;color:#fff;">YouTube Channel ID</h3>
      <p style="margin:15px 0;"><strong>Channel ID:</strong></p>
      <p style="font-family:Courier New,monospace;font-size:14px;background:#222;padding:10px;border-radius:5px;word-break:break-all;margin:10px 0;">${esc(channelId)}</p>
      <p style="margin:15px 0;"><strong>Channel URL:</strong></p>
      <p style="margin:10px 0;"><a href="${esc(channelUrl)}" target="_blank" style="color:#9cf;font-family:Courier New,monospace;font-weight:bold;word-break:break-all;">${esc(channelUrl)}</a></p>
      <button id="copyId" style="margin-top:15px;padding:8px 16px;background:#f00;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold;">Copy Channel ID</button>`;
    const copyBtn=content.querySelector('#copyId');
    copyBtn.onclick=function(){
      navigator.clipboard.writeText(channelId).then(()=>{
        copyBtn.textContent='Copied!';
        setTimeout(()=>{copyBtn.textContent='Copy Channel ID';},2000);
      }).catch(()=>{
        prompt('Channel ID (Ctrl+C to copy):',channelId);
      });
    };
  }else{
    content.innerHTML=`<h3 style="margin-top:0;color:#fff;">YouTube Channel ID</h3>
      <p style="color:#faa;">Channel ID not found on this page.</p>
      <p style="color:#aaa;font-size:12px;margin-top:10px;">Make sure you are on a YouTube video or channel page.</p>`;
  }
  modal.appendChild(content);
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){if(e.target===closeBtn||e.target.tagName==='BUTTON'||e.target.closest('button'))return;dragInfo.isDragging=true;dragInfo.offsetX=e.clientX-modal.offsetLeft;dragInfo.offsetY=e.clientY-modal.offsetTop;modal.style.transform='none'};
  document.onmousemove=function(e){if(dragInfo.isDragging){modal.style.left=e.clientX-dragInfo.offsetX+'px';modal.style.top=e.clientY-dragInfo.offsetY+'px'}};
  document.onmouseup=function(){dragInfo.isDragging=false};
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';closeBtn.style.position='absolute';closeBtn.style.top='5px';closeBtn.style.right='10px';
  closeBtn.style.background='none';closeBtn.style.border='none';closeBtn.style.color='#fff';
  closeBtn.style.fontSize='28px';closeBtn.style.cursor='pointer';closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';closeBtn.style.width='30px';closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){e.stopPropagation();document.body.removeChild(modal);document.onmousemove=null;document.onmouseup=null};
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
}catch(e){alert('Error: '+(e&&e.message?e.message:e))}
})();



