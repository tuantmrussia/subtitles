(function(){
var modal=document.createElement('div');
modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
modal.style.backgroundColor='#333';modal.style.color='#fff';modal.style.padding='20px';
modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
modal.style.maxWidth='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';
var url=window.location.href;
let userStr=document.querySelector('meta[name=\'description\']').getAttribute('content').match(/ - (.*?) on Instagram:/)[1];
let[,displayName,username]=userStr.match(/(.*?) ?\(?@(.+?)\)?$/);
let[,instagramId]=document.body.innerHTML.match(/profilePage_(.*?)\"/);
displayName=displayName||'Not Found';
username=username||'Not Found';
instagramId=instagramId||'Not Found';
var content=document.createElement('div');
content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
content.innerHTML=`<h3 style="margin-top:0;color:#fff;">Instagram User Profile Details</h3>
<p>Username: <strong style="font-family:Courier New,monospace;">${username}</strong></p>
<p>Display Name: <strong style="font-family:Courier New,monospace;">${displayName}</strong></p>
<p>Instagram ID: <strong style="font-family:Courier New,monospace;">${instagramId}</strong></p>
<p>Current URL: <a href="${url}" target="_blank" style="color:#9cf;font-family:Courier New,monospace;font-weight:bold;">${url}</a></p>`;
modal.appendChild(content);
var dragInfo={isDragging:false,offsetX:0,offsetY:0};
modal.onmousedown=function(e){if(e.target===closeBtn||e.target.tagName==='A')return;dragInfo.isDragging=true;dragInfo.offsetX=e.clientX-modal.offsetLeft;dragInfo.offsetY=e.clientY-modal.offsetTop;modal.style.transform='none'};
document.onmousemove=function(e){if(dragInfo.isDragging){modal.style.left=e.clientX-dragInfo.offsetX+'px';modal.style.top=e.clientY-dragInfo.offsetY+'px'}};
document.onmouseup=function(){dragInfo.isDragging=false};
var closeBtn=document.createElement('button');
closeBtn.innerHTML='×';closeBtn.style.position='absolute';closeBtn.style.top='5px';closeBtn.style.right='10px';
closeBtn.style.background='none';closeBtn.style.border='none';closeBtn.style.color='#fff';
closeBtn.style.fontSize='28px';closeBtn.style.cursor='pointer';closeBtn.style.lineHeight='1';
closeBtn.style.padding='0';closeBtn.style.width='30px';closeBtn.style.height='30px';
closeBtn.onmouseover=function(){this.style.opacity='0.7'};closeBtn.onmouseout=function(){this.style.opacity='1'};
closeBtn.onclick=function(e){e.stopPropagation();document.body.removeChild(modal);document.onmousemove=null;document.onmouseup=null};
modal.appendChild(closeBtn);
document.body.appendChild(modal);
})();












