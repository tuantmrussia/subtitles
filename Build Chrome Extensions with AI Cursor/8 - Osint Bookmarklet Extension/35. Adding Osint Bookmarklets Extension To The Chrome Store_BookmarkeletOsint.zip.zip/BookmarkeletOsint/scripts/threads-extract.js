(function(){
const pageSource=document.documentElement.outerHTML;
try{if(window.trustedTypes&&window.trustedTypes.createPolicy){window.trustedTypes.createPolicy('default',{createHTML:(string,sink)=>string})}}catch{};
const decodeUnicode=str=>str.replace(/\\u[\\dA-Fa-f]{4}/g,match=>String.fromCharCode(parseInt(match.replace(/\\u/,''),16)));
const extractValues=(regex,source)=>{const matches=[];let match;while((match=regex.exec(source))!==null){matches.push(decodeUnicode(match[1]))}return matches};
const regexDisplayName=/\"full_name\":\"([^\"]+)\"/g;
const regexThreadsId=/\"pk\":\"(\\d+)\"/g;
const regexBio=/\"biography\":\"([^\"]+)\"/g;
const regexUsername=/\"username\":\"([^\"]+)\"/g;
const displayNames=extractValues(regexDisplayName,pageSource);
const threadsIds=extractValues(regexThreadsId,pageSource);
const bios=extractValues(regexBio,pageSource);
const users=extractValues(regexUsername,pageSource);
const modal=document.createElement('div');
modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
modal.style.backgroundColor='#333';modal.style.color='#fff';modal.style.padding='20px';
modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
modal.style.maxWidth='80%';modal.style.maxHeight='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';modal.style.overflow='auto';
const content=document.createElement('div');
content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
let bioHtml='';
if(bios.length>0){bios.forEach(bio=>{bioHtml+=`<p style=\"margin-left:20px;\">• <strong style=\"font-family:Courier New,monospace;\">${bio.replace(/\\n/g,'<br>')}</strong></p>`})}
else{bioHtml='<p>Bio: <strong style=\"font-family:Courier New,monospace;\">Not found</strong></p>'}
content.innerHTML=`<h3 style=\"margin-top:0;color:#fff;\">Threads User Data</h3>
<p>Username: <strong style=\"font-family:Courier New,monospace;\">${users[1]||'Not found'}</strong></p>
<p>Display Name: <strong style=\"font-family:Courier New,monospace;\">${displayNames[0]||'Not found'}</strong></p>
<p>Threads ID: <strong style=\"font-family:Courier New,monospace;\">${threadsIds[0]||'Not found'}</strong></p>
<p>Current URL: <a href=\"${document.URL}\" target=\"_blank\" style=\"color:#9cf;font-family:Courier New,monospace;font-weight:bold;\">${document.URL}</a></p>
<p>Bio/Signature:</p>${bioHtml}`;
modal.appendChild(content);
var dragInfo={isDragging:false,offsetX:0,offsetY:0};
modal.onmousedown=function(e){if(e.target===closeBtn||e.target.tagName==='A')return;dragInfo.isDragging=true;dragInfo.offsetX=e.clientX-modal.offsetLeft;dragInfo.offsetY=e.clientY-modal.offsetTop;modal.style.transform='none'};
document.onmousemove=function(e){if(dragInfo.isDragging){modal.style.left=e.clientX-dragInfo.offsetX+'px';modal.style.top=e.clientY-dragInfo.offsetY+'px'}};
document.onmouseup=function(){dragInfo.isDragging=false};
var closeBtn=document.createElement('button');
closeBtn.innerHTML='×';closeBtn.style.position='absolute';closeBtn.style.top='5px';closeBtn.style.right='10px';
closeBtn.style.background='none';closeBtn.style.border='none';closeBtn.style.color='#fff';
closeBtn.style.fontSize='28px';closeBtn.style.cursor='pointer';closeBtn.style.lineHeight='1';
closeBtn.style.padding='0';closeBtn.style.width='30px';closeBtn.style.height='30px';
closeBtn.onmouseover=function(){this.style.opacity='0.7'};closeBtn.onmouseout=function(){this.style.opacity='1'};
closeBtn.onclick=function(e){e.stopPropagation();document.body.removeChild(modal);document.onmousemove=null;document.onmouseup=null};
modal.appendChild(closeBtn);
document.body.appendChild(modal);
})();












