(function(){
var a=ytplayer?.config?.args?.storyboard_spec;
if(!a){alert('Sorry we cannot process this YouTube video. Please try another one');return}
var b=a.split('|');
var base=b[0].split('$')[0]+"2/M";
var c=b[3].split('#');
var sigh=c[c.length-1];
var imgs="";
var t=ytplayer.config.args.length_seconds;
var n=Math.ceil(c[2]/(c[3]*c[4]));
for(var i=0;i<n;i++){imgs+="<PICTURE='"+base+i+".jpg?sigh="+sigh+"'><br/>";}
var title=ytplayer.config.args.title;
var msg="<body style='background-color:#444;color:#eee;margin:20px auto;width:90%;text-align:center'><h2>TITLE</h2><div>IMAGES</div/body>";
msg=msg.replace("TITLE",title).replace("IMAGES",imgs).replace(/PICTURE/g,"img src");
var w=window.open();
if(!w){alert('Popup blocked. Allow popups for this site and retry.');return}
w.document.open();
w.document.write(msg);
w.document.close();
})();












