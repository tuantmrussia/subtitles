(function(){
try{
  const esc=s=>(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  const comments=[];
  const commentSelectors=[
    'ytd-comment-renderer',
    'ytd-comment-thread-renderer ytd-comment-renderer',
    '#comment #content-text',
    '#content-text'
  ];
  function extractComments(){
    for(const sel of commentSelectors){
      const els=document.querySelectorAll(sel);
      if(els.length>0){
        els.forEach(el=>{
          const textEl=el.querySelector('#content-text,#content-text span,#content')||el;
          const authorEl=el.querySelector('#author-text,#author-text span,#author-text a')||el.closest('ytd-comment-renderer')?.querySelector('#author-text,#author-text span');
          const timeEl=el.querySelector('#published-time-text,#published-time-text a')||el.closest('ytd-comment-renderer')?.querySelector('#published-time-text');
          const likesEl=el.querySelector('#vote-count-middle,#vote-count-middle span')||el.closest('ytd-comment-renderer')?.querySelector('#vote-count-middle');
          const text=textEl?.textContent?.trim()||'';
          const author=authorEl?.textContent?.trim()||'Unknown';
          const time=timeEl?.textContent?.trim()||'';
          const likes=likesEl?.textContent?.trim()||'0';
          if(text&&text.length>0&&!comments.find(c=>c.text===text)){
            comments.push({text,author,time,likes});
          }
        });
        if(comments.length>0)break;
      }
    }
    if(comments.length===0){
      const allText=document.body.innerText||'';
      const scriptTags=Array.from(document.querySelectorAll('script'));
      for(const script of scriptTags){
        const content=script.textContent||'';
        if(content.includes('"commentText"')||content.includes('"text"')&&content.includes('author')){
          try{
            const match=content.match(/"commentText":\s*"([^"]+)"/g)||content.match(/"text":\s*"([^"]+)"/g);
            if(match){
              match.forEach(m=>{
                const textMatch=m.match(/:\s*"([^"]+)"/);
                if(textMatch&&textMatch[1]){
                  const text=textMatch[1].replace(/\\n/g,' ').trim();
                  if(text.length>10&&!comments.find(c=>c.text===text)){
                    comments.push({text,author:'Unknown',time:'',likes:'0'});
                  }
                }
              });
            }
          }catch(e){}
        }
      }
    }
  }
  extractComments();
  if(comments.length===0){
    alert('No comments found on this page. Make sure you are on a YouTube video page with comments visible.');
    return;
  }
  const randomComment=comments[Math.floor(Math.random()*comments.length)];
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#333';modal.style.color='#fff';modal.style.padding='20px';
  modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='600px';modal.style.maxHeight='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';modal.style.overflow='auto';
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  content.innerHTML=`<h3 style="margin-top:0;color:#fff;">Random Comment Picker</h3>
    <p style="color:#aaa;font-size:12px;">Found ${comments.length} comment${comments.length!==1?'s':''} on this page</p>
    <div style="background:#222;padding:15px;border-radius:5px;margin-top:15px;border-left:3px solid #f00;">
      <p style="margin:0 0 10px 0;color:#9cf;font-weight:bold;">Author: ${esc(randomComment.author)}</p>
      ${randomComment.time?`<p style="margin:0 0 10px 0;color:#aaa;font-size:12px;">Time: ${esc(randomComment.time)}</p>`:''}
      ${randomComment.likes&&randomComment.likes!=='0'?`<p style="margin:0 0 10px 0;color:#aaa;font-size:12px;">Likes: ${esc(randomComment.likes)}</p>`:''}
      <p style="margin:0;color:#fff;white-space:pre-wrap;word-wrap:break-word;">${esc(randomComment.text)}</p>
    </div>
    <button id="pickAnother" style="margin-top:15px;padding:8px 16px;background:#f00;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold;">Pick Another Random Comment</button>`;
  modal.appendChild(content);
  const pickAnotherBtn=content.querySelector('#pickAnother');
  pickAnotherBtn.onclick=function(){
    const newComment=comments[Math.floor(Math.random()*comments.length)];
    const commentDiv=content.querySelector('div[style*="background:#222"]');
    commentDiv.innerHTML=`<p style="margin:0 0 10px 0;color:#9cf;font-weight:bold;">Author: ${esc(newComment.author)}</p>
      ${newComment.time?`<p style="margin:0 0 10px 0;color:#aaa;font-size:12px;">Time: ${esc(newComment.time)}</p>`:''}
      ${newComment.likes&&newComment.likes!=='0'?`<p style="margin:0 0 10px 0;color:#aaa;font-size:12px;">Likes: ${esc(newComment.likes)}</p>`:''}
      <p style="margin:0;color:#fff;white-space:pre-wrap;word-wrap:break-word;">${esc(newComment.text)}</p>`;
  };
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){if(e.target===closeBtn||e.target.tagName==='BUTTON'||e.target.closest('button'))return;dragInfo.isDragging=true;dragInfo.offsetX=e.clientX-modal.offsetLeft;dragInfo.offsetY=e.clientY-modal.offsetTop;modal.style.transform='none'};
  document.onmousemove=function(e){if(dragInfo.isDragging){modal.style.left=e.clientX-dragInfo.offsetX+'px';modal.style.top=e.clientY-dragInfo.offsetY+'px'}};
  document.onmouseup=function(){dragInfo.isDragging=false};
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';closeBtn.style.position='absolute';closeBtn.style.top='5px';closeBtn.style.right='10px';
  closeBtn.style.background='none';closeBtn.style.border='none';closeBtn.style.color='#fff';
  closeBtn.style.fontSize='28px';closeBtn.style.cursor='pointer';closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';closeBtn.style.width='30px';closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){e.stopPropagation();document.body.removeChild(modal);document.onmousemove=null;document.onmouseup=null};
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
}catch(e){alert('Error: '+(e&&e.message?e.message:e))}
})();



