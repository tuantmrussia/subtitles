(function(){
try{
  const q=(s,r=document)=>r.querySelector(s),qa=(s,r=document)=>Array.from(r.querySelectorAll(s));
  const t=s=>typeof s=='string'?s.trim():'';
  const esc=s=>(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  
  const url=location.href;
  let epicId='';
  let username='';
  let displayName='';
  let source='';
  
  // UUID pattern (Epic IDs are typically UUIDs: 8-4-4-4-12 hex characters)
  const uuidPattern=/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi;
  const uuidNoHyphensPattern=/[0-9a-f]{32}/gi;
  
  // Try to find Epic ID in URL parameters
  const urlParams=new URLSearchParams(location.search);
  const accountIdParam=urlParams.get('accountId')||urlParams.get('account_id')||urlParams.get('epicId')||urlParams.get('epic_id');
  if(accountIdParam){
    epicId=accountIdParam;
    source='URL Parameter';
  }
  
  // Try to find Epic ID in URL path
  if(!epicId){
    const pathMatch=url.match(/\/account\/([a-f0-9-]{36})/i)||url.match(/\/profile\/([a-f0-9-]{36})/i)||url.match(/\/user\/([a-f0-9-]{36})/i);
    if(pathMatch&&pathMatch[1]){
      epicId=pathMatch[1];
      source='URL Path';
    }
  }
  
  // Search in script tags for Epic Games data
  if(!epicId){
    const scripts=qa('script');
    for(const script of scripts){
      const content=script.textContent||script.innerHTML||'';
      if(!content||content.length<50)continue;
      
      // Look for common Epic Games JSON patterns
      const patterns=[
        /"accountId":\s*"([a-f0-9-]{36})"/gi,
        /"account_id":\s*"([a-f0-9-]{36})"/gi,
        /"epicId":\s*"([a-f0-9-]{36})"/gi,
        /"epic_id":\s*"([a-f0-9-]{36})"/gi,
        /"id":\s*"([a-f0-9-]{36})"/gi,
        /"userId":\s*"([a-f0-9-]{36})"/gi,
        /"user_id":\s*"([a-f0-9-]{36})"/gi,
        /accountId["\s:]+["']([a-f0-9-]{36})["']/gi,
        /epicId["\s:]+["']([a-f0-9-]{36})["']/gi,
        /__accountId["\s:]+["']([a-f0-9-]{36})["']/gi,
        /window\.__accountId\s*=\s*["']([a-f0-9-]{36})["']/gi,
        /epicgames\.accountId["\s:]+["']([a-f0-9-]{36})["']/gi
      ];
      
      for(const pattern of patterns){
        const match=content.match(pattern);
        if(match&&match[1]&&match[1].length>=32){
          epicId=match[1];
          source='JavaScript Data';
          break;
        }
      }
      
      // Also try to extract username/display name from Epic Games data
      if(!username){
        const usernameMatch=content.match(/"displayName":\s*"([^"]+)"/i)||content.match(/"username":\s*"([^"]+)"/i)||content.match(/"name":\s*"([^"]+)"/i);
        if(usernameMatch&&usernameMatch[1]){
          displayName=usernameMatch[1];
        }
      }
      
      if(epicId)break;
    }
  }
  
  // Search in page HTML for Epic ID patterns
  if(!epicId){
    const html=document.documentElement.innerHTML;
    const htmlMatches=html.match(/accountId["\s:]+["']([a-f0-9-]{36})["']/gi)||html.match(/epicId["\s:]+["']([a-f0-9-]{36})["']/gi);
    if(htmlMatches&&htmlMatches.length>0){
      const firstMatch=htmlMatches[0].match(/"([a-f0-9-]{36})"/);
      if(firstMatch&&firstMatch[1]){
        epicId=firstMatch[1];
        source='Page HTML';
      }
    }
  }
  
  // Search in meta tags
  if(!epicId){
    const metaId=q('meta[name="epicId"]')||q('meta[name="accountId"]')||q('meta[property="epic:accountId"]');
    if(metaId&&metaId.content){
      epicId=metaId.content;
      source='Meta Tag';
    }
  }
  
  // Search in data attributes
  if(!epicId){
    const allElements=qa('*');
    for(const el of allElements){
      const accountId=el.getAttribute('data-account-id')||el.getAttribute('data-epic-id')||el.getAttribute('data-accountId')||el.getAttribute('data-epicId');
      if(accountId&&accountId.match(/^[a-f0-9-]{36}$/i)){
        epicId=accountId;
        source='Data Attribute';
        break;
      }
    }
  }
  
  // Try to find username/display name from page elements
  if(!displayName){
    const displayNameEl=q('[data-testid="displayName"]')||q('.display-name')||q('[class*="displayName"]')||q('[class*="DisplayName"]');
    if(displayNameEl){
      displayName=displayNameEl.textContent||'';
    }
  }
  
  if(!displayName){
    const titleEl=q('title')||q('h1')||q('[class*="username"]')||q('[class*="UserName"]');
    if(titleEl){
      displayName=titleEl.textContent||'';
    }
  }
  
  // Extract username from URL if available
  if(!username){
    const urlParts=url.split('/').filter(Boolean);
    const possibleUsername=urlParts.find(p=>p&&!p.match(/^(account|profile|user|epicgames|epic)$/i)&&!p.match(/^[a-f0-9-]{36}$/i)&&!p.includes('.'));
    if(possibleUsername){
      username=possibleUsername;
    }
  }
  
  // Create modal
  const modal=document.createElement('div');
  modal.style.position='fixed';
  modal.style.top='50%';
  modal.style.left='50%';
  modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#333';
  modal.style.color='#fff';
  modal.style.padding='20px';
  modal.style.border='2px solid #fff';
  modal.style.borderRadius='10px';
  modal.style.zIndex='10000';
  modal.style.maxWidth='80%';
  modal.style.maxHeight='80%';
  modal.style.textAlign='left';
  modal.style.fontFamily='Arial, sans-serif';
  modal.style.cursor='move';
  modal.style.overflow='auto';
  
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';
  content.style.marginTop='30px';
  
  let epicIdDisplay=epicId||'(not found)';
  let epicIdClass=epicId?'monospace':'not-found';
  
  content.innerHTML=`<h3 style="margin-top:0;color:#fff;">Epic Games Account ID</h3>
    <p>Epic ID: <strong style="font-family:Courier New,monospace;${epicId?'color:#9cf;':'color:#f99;'}">${esc(epicIdDisplay)}</strong></p>
    ${source?`<p>Source: <strong style="font-family:Courier New,monospace;">${esc(source)}</strong></p>`:''}
    ${displayName?`<p>Display Name: <strong style="font-family:Courier New,monospace;">${esc(displayName)}</strong></p>`:''}
    ${username?`<p>Username: <strong style="font-family:Courier New,monospace;">${esc(username)}</strong></p>`:''}
    <p>Current URL: <a href="${esc(url)}" target="_blank" style="color:#9cf;font-family:Courier New,monospace;font-weight:bold;word-break:break-all;">${esc(url)}</a></p>
    ${epicId?`<p style="margin-top:15px;"><button id="copy-epic-id" style="background:#9cf;color:#000;border:none;padding:8px 16px;border-radius:5px;cursor:pointer;font-weight:bold;">Copy Epic ID</button></p>`:''}
    <p style="margin-top:10px;font-size:12px;color:#999;">Note: Epic IDs are typically only visible on your own account page. If not found, try viewing your own Epic Games account settings.</p>`;
  
  modal.appendChild(content);
  
  // Add copy functionality
  if(epicId){
    const copyBtn=q('#copy-epic-id',modal);
    if(copyBtn){
      copyBtn.onclick=function(e){
        e.stopPropagation();
        if(navigator.clipboard){
          navigator.clipboard.writeText(epicId).then(()=>{
            copyBtn.textContent='Copied!';
            copyBtn.style.background='#9f9';
            setTimeout(()=>{
              copyBtn.textContent='Copy Epic ID';
              copyBtn.style.background='#9cf';
            },2000);
          }).catch(()=>{
            prompt('Epic ID:',epicId);
          });
        }else{
          prompt('Epic ID:',epicId);
        }
      };
    }
  }
  
  // Draggable functionality
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){
    if(e.target.closest('button')||e.target.tagName==='A'||e.target.closest('#copy-epic-id'))return;
    dragInfo.isDragging=true;
    dragInfo.offsetX=e.clientX-modal.offsetLeft;
    dragInfo.offsetY=e.clientY-modal.offsetTop;
    modal.style.transform='none';
  };
  document.onmousemove=function(e){
    if(dragInfo.isDragging){
      modal.style.left=e.clientX-dragInfo.offsetX+'px';
      modal.style.top=e.clientY-dragInfo.offsetY+'px';
    }
  };
  document.onmouseup=function(){
    dragInfo.isDragging=false;
  };
  
  // Close button
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';
  closeBtn.style.position='absolute';
  closeBtn.style.top='5px';
  closeBtn.style.right='10px';
  closeBtn.style.background='none';
  closeBtn.style.border='none';
  closeBtn.style.color='#fff';
  closeBtn.style.fontSize='28px';
  closeBtn.style.cursor='pointer';
  closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';
  closeBtn.style.width='30px';
  closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7';};
  closeBtn.onmouseout=function(){this.style.opacity='1';};
  closeBtn.onclick=function(e){
    e.stopPropagation();
    document.body.removeChild(modal);
    document.onmousemove=null;
    document.onmouseup=null;
  };
  modal.appendChild(closeBtn);
  
  document.body.appendChild(modal);
}catch(e){
  alert('Bookmarklet error: '+(e&&e.message?e.message:e));
}
})();

