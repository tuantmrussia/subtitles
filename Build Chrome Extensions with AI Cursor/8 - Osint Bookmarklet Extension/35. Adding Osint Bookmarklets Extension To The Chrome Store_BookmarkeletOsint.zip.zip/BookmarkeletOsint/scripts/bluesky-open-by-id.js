(function(){
try{
  var userId=prompt('Enter the Bsky User ID:');
  if(userId&&userId.trim()!==''){
    var url='https://bsky.app/profile/did:plc:'+userId.trim();
    window.open(url,'_blank');
  }else{
    alert('No User ID provided!');
  }
}catch(e){alert('Error processing request: '+e.message);}
})();












