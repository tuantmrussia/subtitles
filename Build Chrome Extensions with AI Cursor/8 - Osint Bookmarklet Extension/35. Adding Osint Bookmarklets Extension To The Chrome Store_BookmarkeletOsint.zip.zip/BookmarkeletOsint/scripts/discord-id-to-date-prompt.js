(function(){
try{
  const DISCORD_EPOCH = 1420070400000n; // January 1, 2015, 00:00:00 UTC in milliseconds
  const esc = s => (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  
  // Convert Discord snowflake to timestamp
  const decodeSnowflake = (snowflake) => {
    try {
      const id = BigInt(snowflake);
      const timestamp = Number((id >> 22n) + DISCORD_EPOCH);
      const date = new Date(timestamp);
      if (isNaN(date.getTime())) return null;
      
      // Format 24H
      const format24H = date.toLocaleString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
        timeZoneName: 'short'
      });
      
      // Format 12H
      const format12H = date.toLocaleString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
        timeZoneName: 'short'
      });
      
      // Time ago
      const now = Date.now();
      const diff = now - timestamp;
      const seconds = Math.floor(diff / 1000);
      const minutes = Math.floor(seconds / 60);
      const hours = Math.floor(minutes / 60);
      const days = Math.floor(hours / 24);
      const months = Math.floor(days / 30);
      const years = Math.floor(days / 365);
      
      let timeAgo = '';
      if (years > 0) {
        timeAgo = `${years} year${years > 1 ? 's' : ''} ago`;
      } else if (months > 0) {
        timeAgo = `${months} month${months > 1 ? 's' : ''} ago`;
      } else if (days > 0) {
        timeAgo = `${days} day${days > 1 ? 's' : ''} ago`;
      } else if (hours > 0) {
        timeAgo = `${hours} hour${hours > 1 ? 's' : ''} ago`;
      } else if (minutes > 0) {
        timeAgo = `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
      } else {
        timeAgo = `${seconds} second${seconds > 1 ? 's' : ''} ago`;
      }
      
      // Timezone
      const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
      
      return {
        timestamp: timestamp,
        timestampSeconds: Math.floor(timestamp / 1000),
        iso: date.toISOString(),
        format24H: format24H,
        format12H: format12H,
        timeAgo: timeAgo,
        timezone: timezone,
        date: date
      };
    } catch (e) {
      return null;
    }
  };
  
  // Always prompt for Discord ID
  const discordId = prompt('Enter Discord ID (snowflake):\nExample: 956390671105789992', '');
  
  if (!discordId || !discordId.trim()) {
    return;
  }
  
  const trimmedId = discordId.trim();
  
  // Validate format
  if (!/^\d{17,19}$/.test(trimmedId)) {
    alert('Invalid Discord ID format. Discord IDs are 17-19 digit numbers.');
    return;
  }
  
  const decoded = decodeSnowflake(trimmedId);
  
  if (!decoded) {
    alert('Failed to decode Discord ID. Please check the ID and try again.');
    return;
  }
  
  const modal = document.createElement('div');
  modal.style.position = 'fixed';
  modal.style.top = '50%';
  modal.style.left = '50%';
  modal.style.transform = 'translate(-50%, -50%)';
  modal.style.backgroundColor = '#2C2F33';
  modal.style.color = '#fff';
  modal.style.padding = '25px';
  modal.style.border = '2px solid #5865F2';
  modal.style.borderRadius = '10px';
  modal.style.zIndex = '10000';
  modal.style.maxWidth = '500px';
  modal.style.width = '90%';
  modal.style.fontFamily = 'Arial, sans-serif';
  modal.style.cursor = 'move';
  modal.style.boxShadow = '0 4px 20px rgba(0,0,0,0.5)';
  
  const content = document.createElement('div');
  content.style.fontFamily = 'Arial, sans-serif';
  content.style.marginTop = '10px';
  
  content.innerHTML = `
    <h3 style="margin-top:0;color:#5865F2;font-size:20px;">Discord ID to Creation Date</h3>
    <div style="background:#23272A;padding:15px;margin-bottom:15px;border-radius:5px;border:1px solid #5865F2;">
      <p style="margin:8px 0;"><strong style="color:#99AAB5;">Discord ID:</strong><br>
      <code style="background:#1E2124;padding:5px 10px;border-radius:3px;font-family:'Courier New',monospace;color:#5865F2;display:inline-block;margin-top:5px;font-size:14px;">${esc(trimmedId)}</code></p>
    </div>
    
    <div style="background:#23272A;padding:15px;margin-bottom:15px;border-radius:5px;border:1px solid #5865F2;">
      <p style="margin:8px 0;"><strong style="color:#99AAB5;">Creation Date (24H format):</strong><br>
      <code style="background:#1E2124;padding:5px 10px;border-radius:3px;font-family:'Courier New',monospace;color:#fff;display:inline-block;margin-top:5px;font-size:14px;">${esc(decoded.format24H)}</code></p>
      
      <p style="margin:8px 0;"><strong style="color:#99AAB5;">Creation Date (12H format):</strong><br>
      <code style="background:#1E2124;padding:5px 10px;border-radius:3px;font-family:'Courier New',monospace;color:#fff;display:inline-block;margin-top:5px;font-size:14px;">${esc(decoded.format12H)}</code></p>
      
      <p style="margin:8px 0;"><strong style="color:#99AAB5;">Your timezone:</strong><br>
      <code style="background:#1E2124;padding:5px 10px;border-radius:3px;font-family:'Courier New',monospace;color:#fff;display:inline-block;margin-top:5px;font-size:14px;">${esc(decoded.timezone)}</code></p>
      
      <p style="margin:8px 0;"><strong style="color:#99AAB5;">Time ago:</strong><br>
      <code style="background:#1E2124;padding:5px 10px;border-radius:3px;font-family:'Courier New',monospace;color:#57F287;display:inline-block;margin-top:5px;font-size:14px;">${esc(decoded.timeAgo)}</code></p>
      
      <p style="margin:8px 0;"><strong style="color:#99AAB5;">Unix timestamp:</strong><br>
      <code style="background:#1E2124;padding:5px 10px;border-radius:3px;font-family:'Courier New',monospace;color:#5865F2;display:inline-block;margin-top:5px;font-size:14px;">${decoded.timestampSeconds}</code> (seconds)<br>
      <code style="background:#1E2124;padding:5px 10px;border-radius:3px;font-family:'Courier New',monospace;color:#5865F2;display:inline-block;margin-top:5px;font-size:14px;">${decoded.timestamp}</code> (milliseconds)</p>
      
      <p style="margin:8px 0;"><strong style="color:#99AAB5;">ISO 8601:</strong><br>
      <code style="background:#1E2124;padding:5px 10px;border-radius:3px;font-family:'Courier New',monospace;color:#fff;display:inline-block;margin-top:5px;font-size:14px;">${esc(decoded.iso)}</code></p>
    </div>
    
    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      <button onclick="navigator.clipboard.writeText('${esc(trimmedId)}').then(()=>alert('Copied!')).catch(()=>alert('Copy failed'))" style="padding:8px 15px;background:#5865F2;color:#fff;border:none;border-radius:5px;cursor:pointer;font-size:13px;font-weight:bold;">Copy ID</button>
      <button onclick="navigator.clipboard.writeText('${decoded.timestampSeconds}').then(()=>alert('Copied!')).catch(()=>alert('Copy failed'))" style="padding:8px 15px;background:#5865F2;color:#fff;border:none;border-radius:5px;cursor:pointer;font-size:13px;font-weight:bold;">Copy Timestamp</button>
      <button onclick="navigator.clipboard.writeText('${esc(decoded.iso)}').then(()=>alert('Copied!')).catch(()=>alert('Copy failed'))" style="padding:8px 15px;background:#5865F2;color:#fff;border:none;border-radius:5px;cursor:pointer;font-size:13px;font-weight:bold;">Copy ISO Date</button>
    </div>
  `;
  
  modal.appendChild(content);
  
  var dragInfo = { isDragging: false, offsetX: 0, offsetY: 0 };
  modal.onmousedown = function(e) {
    if (e.target === closeBtn || e.target.tagName === 'BUTTON' || e.target.tagName === 'CODE') return;
    dragInfo.isDragging = true;
    dragInfo.offsetX = e.clientX - modal.offsetLeft;
    dragInfo.offsetY = e.clientY - modal.offsetTop;
    modal.style.transform = 'none';
  };
  document.onmousemove = function(e) {
    if (dragInfo.isDragging) {
      modal.style.left = (e.clientX - dragInfo.offsetX) + 'px';
      modal.style.top = (e.clientY - dragInfo.offsetY) + 'px';
    }
  };
  document.onmouseup = function() {
    dragInfo.isDragging = false;
  };
  
  var closeBtn = document.createElement('button');
  closeBtn.innerHTML = '×';
  closeBtn.style.position = 'absolute';
  closeBtn.style.top = '5px';
  closeBtn.style.right = '10px';
  closeBtn.style.background = 'none';
  closeBtn.style.border = 'none';
  closeBtn.style.color = '#fff';
  closeBtn.style.fontSize = '28px';
  closeBtn.style.cursor = 'pointer';
  closeBtn.style.lineHeight = '1';
  closeBtn.style.padding = '0';
  closeBtn.style.width = '30px';
  closeBtn.style.height = '30px';
  closeBtn.onmouseover = function() { this.style.opacity = '0.7'; };
  closeBtn.onmouseout = function() { this.style.opacity = '1'; };
  closeBtn.onclick = function(e) {
    e.stopPropagation();
    document.body.removeChild(modal);
    document.onmousemove = null;
    document.onmouseup = null;
  };
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
} catch(e) {
  alert('Discord ID to Date error: ' + (e && e.message ? e.message : e));
}
})();

