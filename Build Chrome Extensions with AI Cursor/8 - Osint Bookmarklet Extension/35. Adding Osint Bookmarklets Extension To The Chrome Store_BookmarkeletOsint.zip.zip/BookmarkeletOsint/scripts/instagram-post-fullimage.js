(function(){
var url=window.location.href;
if(location.href.match(/instagram.com.*\/p\//)){
  let newUrl=`${document.location.origin}/p/${document.location.pathname.split('/p/').at(-1)}media?size=l`;
  window.open(newUrl,'_blank');
}else{
  alert('This is not an Instagram post URL.');
}
})();












