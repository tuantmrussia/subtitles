(function(){
try{
  const esc=s=>(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  let steamId64='';
  let steamId3='';
  let steamId='';
  let customUrl='';
  let profileName='';
  
  const url=location.href;
  
  // Check if URL contains numeric Steam ID
  const urlMatch=url.match(/\/profiles\/(\d+)/);
  if(urlMatch&&urlMatch[1]){
    steamId64=urlMatch[1];
  }
  
  // Check for custom URL
  const customUrlMatch=url.match(/\/id\/([^\/\?]+)/);
  if(customUrlMatch&&customUrlMatch[1]){
    customUrl=customUrlMatch[1];
  }
  
  // Extract from page source (works for both numeric and custom URLs)
  if(!steamId64){
    const pageSource=document.documentElement.outerHTML;
    
    // Try to find Steam ID64 in various patterns
    const patterns=[
      /"steamid":"(\d{17})"/,
      /"steamid":\s*"(\d{17})"/,
      /"steamID64":"(\d{17})"/,
      /"steamID64":\s*"(\d{17})"/,
      /steamid["'\s:=]+(\d{17})/,
      /data-steamid="(\d{17})"/,
      /g_steamID\s*=\s*"(\d{17})"/,
      /"profile":\s*{[^}]*"steamid":\s*"(\d{17})"/,
      /"persona":\s*{[^}]*"steamid":\s*"(\d{17})"/,
      /ProfileUrl:.*?steamcommunity\.com\/profiles\/(\d{17})/,
      /steamcommunity\.com\/profiles\/(\d{17})/
    ];
    
    for(const pattern of patterns){
      const match=pageSource.match(pattern);
      if(match&&match[1]&&match[1].length===17){
        steamId64=match[1];
        break;
      }
    }
    
    // Try to find in script tags
    if(!steamId64){
      const scriptTags=Array.from(document.querySelectorAll('script'));
      for(const script of scriptTags){
        const content=script.textContent||'';
        for(const pattern of patterns){
          const match=content.match(pattern);
          if(match&&match[1]&&match[1].length===17){
            steamId64=match[1];
            break;
          }
        }
        if(steamId64)break;
      }
    }
    
    // Try to find custom URL from page
    if(!customUrl){
      const customPatterns=[
        /"customURL":"([^"]+)"/,
        /"customURL":\s*"([^"]+)"/,
        /ProfileUrl:.*?steamcommunity\.com\/id\/([^"\s]+)/
      ];
      for(const pattern of customPatterns){
        const match=pageSource.match(pattern);
        if(match&&match[1]){
          customUrl=match[1];
          break;
        }
      }
    }
    
    // Try to find profile name
    const namePatterns=[
      /"personaname":"([^"]+)"/,
      /"personaname":\s*"([^"]+)"/,
      /"profileName":"([^"]+)"/,
      /"profileName":\s*"([^"]+)"/,
      /<meta\s+property="og:title"\s+content="([^"]+)"/,
      /<title>([^<]+)<\/title>/
    ];
    for(const pattern of namePatterns){
      const match=pageSource.match(pattern);
      if(match&&match[1]&&match[1]!=='Steam Community'){
        profileName=match[1].replace(/\s+-\s+Steam Community.*$/,'');
        break;
      }
    }
  }
  
  // If we have Steam ID64, convert to other formats
  if(steamId64){
    const id64=BigInt(steamId64);
    const steamId3Val=id64-BigInt('76561197960265728');
    steamId3='[U:1:'+steamId3Val+']';
    
    // Convert to legacy Steam ID format
    const accountId=Number(steamId3Val);
    const y=accountId%2;
    const z=Math.floor(accountId/2);
    steamId='STEAM_0:'+y+':'+z;
  }
  
  // Create modal
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#171a21';modal.style.color='#c7d5e0';modal.style.padding='20px';
  modal.style.border='2px solid #66c0f4';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='600px';modal.style.maxHeight='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';modal.style.overflow='auto';
  modal.style.boxShadow='0 0 20px rgba(0,0,0,0.5)';
  
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  
  if(steamId64){
    const profileUrl='https://steamcommunity.com/profiles/'+steamId64;
    const sourceModLine='\"'+steamId64+'\"/\"@'+steamId64+'\"';
    
    content.innerHTML=`<h3 style="margin-top:0;color:#66c0f4;font-size:20px;">Steam ID Finder</h3>
      ${profileName?`<p style="margin:10px 0;color:#c7d5e0;"><strong>Profile Name:</strong> ${esc(profileName)}</p>`:''}
      ${customUrl?`<p style="margin:10px 0;color:#c7d5e0;"><strong>Custom URL:</strong> <code style="background:#1b2838;padding:2px 6px;border-radius:3px;font-family:Courier New,monospace;color:#66c0f4;">${esc(customUrl)}</code></p>`:''}
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#c7d5e0;"><strong>Steam ID64 (SteamID64):</strong></p>
        <div style="background:#1b2838;padding:12px;border-radius:5px;margin:10px 0;border:1px solid #66c0f4;">
          <code style="font-family:Courier New,monospace;font-size:14px;color:#66c0f4;word-break:break-all;">${esc(steamId64)}</code>
          <button id="copyId64" style="margin-left:10px;padding:5px 10px;background:#66c0f4;color:#171a21;border:none;border-radius:3px;cursor:pointer;font-weight:bold;font-size:12px;">Copy</button>
        </div>
      </div>
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#c7d5e0;"><strong>Steam ID3:</strong></p>
        <div style="background:#1b2838;padding:12px;border-radius:5px;margin:10px 0;border:1px solid #66c0f4;">
          <code style="font-family:Courier New,monospace;font-size:14px;color:#66c0f4;word-break:break-all;">${esc(steamId3)}</code>
          <button id="copyId3" style="margin-left:10px;padding:5px 10px;background:#66c0f4;color:#171a21;border:none;border-radius:3px;cursor:pointer;font-weight:bold;font-size:12px;">Copy</button>
        </div>
      </div>
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#c7d5e0;"><strong>Steam ID (Legacy):</strong></p>
        <div style="background:#1b2838;padding:12px;border-radius:5px;margin:10px 0;border:1px solid #66c0f4;">
          <code style="font-family:Courier New,monospace;font-size:14px;color:#66c0f4;word-break:break-all;">${esc(steamId)}</code>
          <button id="copyId" style="margin-left:10px;padding:5px 10px;background:#66c0f4;color:#171a21;border:none;border-radius:3px;cursor:pointer;font-weight:bold;font-size:12px;">Copy</button>
        </div>
      </div>
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#c7d5e0;"><strong>Profile URL:</strong></p>
        <p style="margin:10px 0;"><a href="${esc(profileUrl)}" target="_blank" style="color:#66c0f4;font-family:Courier New,monospace;font-weight:bold;word-break:break-all;text-decoration:none;">${esc(profileUrl)}</a></p>
      </div>
      <div style="margin:15px 0;">
        <p style="margin:10px 0;color:#c7d5e0;"><strong>SourceMod Admin Config Line:</strong></p>
        <div style="background:#1b2838;padding:12px;border-radius:5px;margin:10px 0;border:1px solid #66c0f4;">
          <code style="font-family:Courier New,monospace;font-size:12px;color:#66c0f4;word-break:break-all;">${esc(sourceModLine)}</code>
          <button id="copySourceMod" style="margin-left:10px;padding:5px 10px;background:#66c0f4;color:#171a21;border:none;border-radius:3px;cursor:pointer;font-weight:bold;font-size:12px;">Copy</button>
        </div>
      </div>
      <div style="margin-top:20px;padding-top:15px;border-top:1px solid #66c0f4;">
        <button id="copyAll" style="padding:10px 20px;background:#5c7e10;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold;width:100%;">Copy All IDs</button>
      </div>`;
    
    // Add copy functionality
    const copyButton=(id,text)=>{
      const btn=content.querySelector(id);
      if(btn){
        btn.onclick=function(){
          navigator.clipboard.writeText(text).then(()=>{
            const originalText=btn.textContent;
            btn.textContent='Copied!';
            btn.style.background='#5c7e10';
            setTimeout(()=>{
              btn.textContent=originalText;
              btn.style.background='#66c0f4';
            },2000);
          }).catch(()=>{
            prompt('Copy this (Ctrl+C):',text);
          });
        };
      }
    };
    
    copyButton('#copyId64',steamId64);
    copyButton('#copyId3',steamId3);
    copyButton('#copyId',steamId);
    copyButton('#copySourceMod',sourceModLine);
    
    const copyAllBtn=content.querySelector('#copyAll');
    if(copyAllBtn){
      const allIds=`Steam ID64: ${steamId64}\nSteam ID3: ${steamId3}\nSteam ID: ${steamId}\nProfile URL: ${profileUrl}\nSourceMod Line: ${sourceModLine}`;
      copyAllBtn.onclick=function(){
        navigator.clipboard.writeText(allIds).then(()=>{
          copyAllBtn.textContent='All IDs Copied!';
          copyAllBtn.style.background='#5c7e10';
          setTimeout(()=>{
            copyAllBtn.textContent='Copy All IDs';
            copyAllBtn.style.background='#5c7e10';
          },2000);
        }).catch(()=>{
          prompt('Copy all IDs (Ctrl+C):',allIds);
        });
      };
    }
  }else{
    content.innerHTML=`<h3 style="margin-top:0;color:#66c0f4;font-size:20px;">Steam ID Finder</h3>
      <p style="color:#ff6b6b;margin:15px 0;">Steam ID not found on this page.</p>
      <p style="color:#c7d5e0;font-size:12px;margin-top:10px;">Make sure you are on a Steam profile page:</p>
      <ul style="color:#c7d5e0;font-size:12px;margin:10px 0;padding-left:20px;">
        <li>steamcommunity.com/profiles/[STEAMID64]</li>
        <li>steamcommunity.com/id/[CUSTOMURL]</li>
      </ul>`;
  }
  
  modal.appendChild(content);
  
  // Drag functionality
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){
    if(e.target===closeBtn||e.target.tagName==='BUTTON'||e.target.closest('button')||e.target.tagName==='CODE'||e.target.closest('code'))return;
    dragInfo.isDragging=true;
    dragInfo.offsetX=e.clientX-modal.offsetLeft;
    dragInfo.offsetY=e.clientY-modal.offsetTop;
    modal.style.transform='none';
  };
  document.onmousemove=function(e){
    if(dragInfo.isDragging){
      modal.style.left=e.clientX-dragInfo.offsetX+'px';
      modal.style.top=e.clientY-dragInfo.offsetY+'px';
    }
  };
  document.onmouseup=function(){
    dragInfo.isDragging=false;
  };
  
  // Close button
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';
  closeBtn.style.position='absolute';
  closeBtn.style.top='5px';
  closeBtn.style.right='10px';
  closeBtn.style.background='none';
  closeBtn.style.border='none';
  closeBtn.style.color='#66c0f4';
  closeBtn.style.fontSize='28px';
  closeBtn.style.cursor='pointer';
  closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';
  closeBtn.style.width='30px';
  closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};
  closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){
    e.stopPropagation();
    document.body.removeChild(modal);
    document.onmousemove=null;
    document.onmouseup=null;
  };
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
}catch(e){
  alert('Error: '+(e&&e.message?e.message:e));
}
})();

