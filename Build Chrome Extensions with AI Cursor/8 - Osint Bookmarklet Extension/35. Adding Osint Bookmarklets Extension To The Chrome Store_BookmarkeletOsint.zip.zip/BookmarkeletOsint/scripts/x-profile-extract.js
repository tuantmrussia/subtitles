(function(){
try{
  const q=(s,r=document)=>r.querySelector(s),qa=(s,r=document)=>Array.from(r.querySelectorAll(s));
  const t=s=>typeof s=='string'?s.trim():'';
  const esc=s=>(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;').replace(/'/g,'&#39;');
  const url=q('meta[property="og:url"]')?.content||location.href;
  const u=new URL(url);
  const parts=u.pathname.split('/').filter(Boolean);
  const handleFromURL=parts[0]||'';
  const spans=qa('div[data-testid="UserName"] span, div[data-testid="User-Name"] span');
  const displayName=spans.map(s=>t(s.textContent)).find(x=>x&&!x.startsWith('@'))||'';
  const findIdentifier=()=>{const hn=(handleFromURL||'').toLowerCase();const escRe=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');const rx=[new RegExp('\"identifier\":\"(\\\\d+)\"[\\\\s\\\\S]{0,15000}\"screen_name\":\"'+escRe(hn)+'\"','i'),new RegExp('\"screen_name\":\"'+escRe(hn)+'\"[\\\\s\\\\S]{0,15000}\"identifier\":\"(\\\\d+)\"','i')];const scan=txt=>{if(!txt||txt.indexOf('\"identifier\"')===-1)return'';for(const r of rx){const m=txt.match(r);if(m)return m[1]}const m2=txt.match(/\"identifier\":\"(\\\\d{5,})\"/);return m2?m2[1]:''};for(const s of qa('script')){const x=s.textContent||'';const id=scan(x);if(id)return id}return scan(document.documentElement.innerHTML)||''};
  const identifier=findIdentifier();
  const userIdURL=identifier?('https://x.com/i/user/'+identifier):'';
  const findCreateISO=()=>{for(const s of qa('script')){const x=s.textContent||'';let m=x.match(/\"dateCreated\":\"([^\"]+)\"/)||x.match(/\"created_at\":\"([^\"]+)\"/)||x.match(/\"createdAt\":\"([^\"]+)\"/);if(m){const d=new Date(m[1]);if(!isNaN(d))return d.toISOString()}}const joined=q('[data-testid="UserJoinDate"] span')?.textContent||'';const jm=joined.match(/Joined\s+([A-Za-z]+)\s+(\d{4})/);if(jm){const d=new Date(jm[1]+' 1, '+jm[2]+' 00:00:00Z');if(!isNaN(d))return d.toISOString()}return''};
  const createdISO=findCreateISO();
  const bannerImg=q('img[src*="pbs.twimg.com/profile_banners/"]')?.src||'';
  const decodeSnowflakeMs=id=>{try{const EPOCH=1288834974657n;return Number((BigInt(id)>>22n)+EPOCH)}catch{return NaN}};
  const parseBannerUpload=src=>{try{if(!src)return'';const clean=src.split('?')[0];const m=clean.match(/\/profile_banners\/\d+\/(\d+)/);if(!m)return'';const token=m[1];let ms=NaN;if(/^\d{19,}$/.test(token)){ms=decodeSnowflakeMs(token)}else if(/^\d{13}$/.test(token)){ms=parseInt(token,10)}else if(/^\d{10}$/.test(token)){ms=parseInt(token,10)*1e3}if(!isNaN(ms)){const d=new Date(ms);if(!isNaN(d))return d.toISOString()}return'(unknown)'}catch{return'(unknown)'}};
  const bannUp=parseBannerUpload(bannerImg);
  const findProfileImg=()=>{try{const hn=handleFromURL||'';let a=q('div[data-testid="primaryColumn"] a[href="/'+hn+'/photo"]')||q('a[href="/'+hn+'/photo"]');if(a){let im=a.querySelector('img[src*="pbs.twimg.com/profile_images/"]');if(im)return im.src;const els=[a,...qa('*',a)];for(const el of els){const bg=getComputedStyle(el).backgroundImage||'';const m=bg.match(/url\(["']?(https?:\/\/[^"')]+profile_images[^"')]+)["']?\)/i);if(m)return m[1]}}const og=q('meta[property="og:image"]')?.content||'';if(og&&/pbs\.twimg\.com\/profile_images\//i.test(og))return og;const escRe=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');const hnre=escRe((hn||'').toLowerCase());const scan=txt=>{if(!txt||txt.indexOf('profile_image_url')===-1)return'';const raw=txt.replace(/\\\//g,'/');let m=raw.match(new RegExp('\"screen_name\":\"'+hnre+'\"[\\s\\S]{0,2000]\"profile_image_url_https\":\"(https://pbs\\.twimg\\.com/profile_images/[^\"]+)\"','i'));if(m)return m[1];m=raw.match(new RegExp('\"profile_image_url_https\":\"(https://pbs\\.twimg\\.com/profile_images/[^\"]+)\"[\\s\\S]{0,2000]\"screen_name\":\"'+hnre+'\"','i'));if(m)return m[1];m=raw.match(/\"profile_image_url_https\":\"(https:\/\/pbs\\.twimg\\.com\/profile_images\/[^\"]+)\"/i);return m?m[1]:''};for(const s of qa('script')){const r=scan(s.textContent||'');if(r)return r}const r2=scan(document.documentElement.innerHTML);if(r2)return r2;const any=q('div[data-testid="primaryColumn"] img[src*="pbs.twimg.com/profile_images/"]');if(any)return any.src;return''}catch{return''}};
  let profileImg=findProfileImg();
  if(profileImg){profileImg=profileImg.replace('_normal','');if(profileImg.indexOf('name=')>-1)profileImg=profileImg.replace(/([?&])name=[^&]*/,'$1name=orig')}
  const profileURL='https://x.com/'+handleFromURL;
  const modal=document.createElement('div');
  modal.style.position='fixed';modal.style.top='50%';modal.style.left='50%';modal.style.transform='translate(-50%, -50%)';
  modal.style.backgroundColor='#333';modal.style.color='#fff';modal.style.padding='20px';
  modal.style.border='2px solid #fff';modal.style.borderRadius='10px';modal.style.zIndex='10000';
  modal.style.maxWidth='80%';modal.style.textAlign='left';modal.style.fontFamily='Arial, sans-serif';modal.style.cursor='move';
  const content=document.createElement('div');
  content.style.fontFamily='Arial, sans-serif';content.style.marginTop='30px';
  const imgHTML=profileImg?('<img src="'+esc(profileImg)+'" alt="Avatar" style="width:72px;height:72px;border-radius:50%;object-fit:cover;margin-bottom:15px;border:2px solid rgba(255,255,255,.2)">'):'';
  content.innerHTML=`<h3 style="margin-top:0;color:#fff;">X Profile Data</h3>${imgHTML}
    <p>Identifier: <strong style="font-family:Courier New,monospace;">${esc(identifier||'(unknown)')}</strong></p>
    <p>User ID URL: ${userIdURL?('<a href="'+esc(userIdURL)+'" target="_blank" style="color:#9cf;font-family:Courier New,monospace;font-weight:bold;">'+esc(userIdURL)+'</a>'):'<strong style="font-family:Courier New,monospace;">(unknown)</strong>'}</p>
    <p>Profile URL: <a href="${esc(profileURL)}" target="_blank" style="color:#9cf;font-family:Courier New,monospace;font-weight:bold;">${esc(profileURL)}</a></p>
    <p>Username: <strong style="font-family:Courier New,monospace;">@${esc(handleFromURL||'(unknown)')}</strong></p>
    <p>Handle: <strong style="font-family:Courier New,monospace;">${esc(displayName||'(unknown)')}</strong></p>
    <p>Create Date: <strong style="font-family:Courier New,monospace;">${esc(createdISO||'(unknown)')}</strong></p>
    <p>Banner Image: ${bannerImg?('<a href="'+esc(bannerImg)+'" target="_blank" style="color:#9cf;font-family:Courier New,monospace;font-weight:bold;">View Image</a>'):'<strong style="font-family:Courier New,monospace;">(not found)</strong>'}</p>
    <p>Banner Upload Date: <strong style="font-family:Courier New,monospace;">${esc(bannUp||'(unknown)')}</strong></p>`;
  modal.appendChild(content);
  var dragInfo={isDragging:false,offsetX:0,offsetY:0};
  modal.onmousedown=function(e){if(e.target===closeBtn||e.target.tagName==='A')return;dragInfo.isDragging=true;dragInfo.offsetX=e.clientX-modal.offsetLeft;dragInfo.offsetY=e.clientY-modal.offsetTop;modal.style.transform='none'};
  document.onmousemove=function(e){if(dragInfo.isDragging){modal.style.left=e.clientX-dragInfo.offsetX+'px';modal.style.top=e.clientY-dragInfo.offsetY+'px'}};
  document.onmouseup=function(){dragInfo.isDragging=false};
  var closeBtn=document.createElement('button');
  closeBtn.innerHTML='×';closeBtn.style.position='absolute';closeBtn.style.top='5px';closeBtn.style.right='10px';
  closeBtn.style.background='none';closeBtn.style.border='none';closeBtn.style.color='#fff';
  closeBtn.style.fontSize='28px';closeBtn.style.cursor='pointer';closeBtn.style.lineHeight='1';
  closeBtn.style.padding='0';closeBtn.style.width='30px';closeBtn.style.height='30px';
  closeBtn.onmouseover=function(){this.style.opacity='0.7'};closeBtn.onmouseout=function(){this.style.opacity='1'};
  closeBtn.onclick=function(e){e.stopPropagation();document.body.removeChild(modal);document.onmousemove=null;document.onmouseup=null};
  modal.appendChild(closeBtn);
  document.body.appendChild(modal);
}catch(e){alert('Bookmarklet error: '+(e&&e.message?e.message:e))}
})();












