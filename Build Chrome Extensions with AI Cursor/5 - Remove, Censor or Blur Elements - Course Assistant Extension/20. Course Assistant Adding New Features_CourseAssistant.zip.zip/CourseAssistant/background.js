// Background service worker for Element Hider extension

// Create context menu on installation
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'hideBlurElement',
    title: 'Manage Visibility',
    contexts: ['all']
  });
  
  chrome.contextMenus.create({
    id: 'hideOnce',
    parentId: 'hideBlurElement',
    title: 'Hide Once',
    contexts: ['all']
  });
  
  chrome.contextMenus.create({
    id: 'hidePersistent',
    parentId: 'hideBlurElement',
    title: 'Hide Persistent',
    contexts: ['all']
  });
  
  chrome.contextMenus.create({
    id: 'blurOnce',
    parentId: 'hideBlurElement',
    title: 'Blur Once',
    contexts: ['all']
  });
  
  chrome.contextMenus.create({
    id: 'blurPersistent',
    parentId: 'hideBlurElement',
    title: 'Blur Persistent',
    contexts: ['all']
  });
  
  chrome.contextMenus.create({
    id: 'asteriskOnce',
    parentId: 'hideBlurElement',
    title: 'Asterisk Once',
    contexts: ['all']
  });
  
  chrome.contextMenus.create({
    id: 'asteriskPersistent',
    parentId: 'hideBlurElement',
    title: 'Asterisk Persistent',
    contexts: ['all']
  });
  
  chrome.contextMenus.create({
    id: 'redactOnce',
    parentId: 'hideBlurElement',
    title: 'Redact Once',
    contexts: ['all']
  });
  
  chrome.contextMenus.create({
    id: 'redactPersistent',
    parentId: 'hideBlurElement',
    title: 'Redact Persistent',
    contexts: ['all']
  });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const menuItemId = info.menuItemId;
  
  if (menuItemId === 'hideOnce' || menuItemId === 'hidePersistent' || 
      menuItemId === 'blurOnce' || menuItemId === 'blurPersistent' ||
      menuItemId === 'asteriskOnce' || menuItemId === 'asteriskPersistent' ||
      menuItemId === 'redactOnce' || menuItemId === 'redactPersistent') {
    try {
      // Skip if it's a chrome:// or extension page
      if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
        return;
      }

      // Determine action type and persistence from menu item ID
      let actionType = 'hide';
      if (menuItemId === 'blurOnce' || menuItemId === 'blurPersistent') {
        actionType = 'blur';
      } else if (menuItemId === 'asteriskOnce' || menuItemId === 'asteriskPersistent') {
        actionType = 'asterisk';
      } else if (menuItemId === 'redactOnce' || menuItemId === 'redactPersistent') {
        actionType = 'redact';
      }
      const save = (menuItemId === 'hidePersistent' || menuItemId === 'blurPersistent' || 
                    menuItemId === 'asteriskPersistent' || menuItemId === 'redactPersistent');

      // Use a more reliable method: inject script that uses the last right-click position
      // First, try to get coordinates if available
      let pageX = null;
      let pageY = null;
      
      if (typeof info.pageX === 'number' && typeof info.pageY === 'number') {
        pageX = info.pageX;
        pageY = info.pageY;
      }
      
      // Inject script to get element info (no prompt needed)
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: handleContextMenuClick,
        args: [pageX !== null ? Number(pageX) : null, pageY !== null ? Number(pageY) : null, actionType]
      });
      
      if (results && results[0] && results[0].result) {
        const result = results[0].result;
        
        // Check if this is a text selection request for asterisk/redact
        if (result.isTextSelection === false && (actionType === 'asterisk' || actionType === 'redact')) {
          // No text selected - show error notification
          chrome.notifications.create({
            type: 'basic',
            title: 'Text Selection Required',
            message: 'Please select text to apply asterisk or redact effect.',
            priority: 1
          });
          return;
        }
        
        if (result.isTextSelection === true && result.textSelection) {
          // Handle text selection for asterisk/redact
          try {
            let action = 'asteriskTextSelection';
            if (actionType === 'redact') {
              action = 'redactTextSelection';
            }
            
            const response = await chrome.tabs.sendMessage(tab.id, {
              action: action,
              textSelection: result.textSelection,
              save: save,
              type: actionType
            });
            
            console.log('Text selection message sent successfully:', response);
            
            // Show notification
            await showVisibilityNotification(tab.id, {
              selector: result.textSelection.selector,
              description: result.textSelection.selectedText.substring(0, 50)
            }, actionType, save);
            
            // Update badge
            setTimeout(async () => {
              await updateBadge(tab.id, null);
            }, 300);
            
            // Refresh page if saved
            if (save) {
              setTimeout(() => {
                chrome.tabs.reload(tab.id);
              }, 100);
            }
          } catch (error) {
            console.log('Content script not ready, injecting...', error);
            try {
              await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['content.js']
              });
              
              await new Promise(resolve => setTimeout(resolve, 200));
              
              let action = 'asteriskTextSelection';
              if (actionType === 'redact') {
                action = 'redactTextSelection';
              }
              
              const response = await chrome.tabs.sendMessage(tab.id, {
                action: action,
                textSelection: result.textSelection,
                save: save,
                type: actionType
              });
              
              console.log('Text selection message sent after injection:', response);
              
              await showVisibilityNotification(tab.id, {
                selector: result.textSelection.selector,
                description: result.textSelection.selectedText.substring(0, 50)
              }, actionType, save);
              
              setTimeout(async () => {
                await updateBadge(tab.id, null);
              }, 300);
              
              if (save) {
                setTimeout(() => {
                  chrome.tabs.reload(tab.id);
                }, 100);
              }
            } catch (retryError) {
              console.error('Error handling text selection:', retryError);
            }
          }
          return;
        }
        
        if (result.elementInfo) {
          // Ensure content script is ready before sending message
          try {
            // Try to send message to content script
            let action = 'hideElement';
            if (actionType === 'blur') {
              action = 'blurElement';
            } else if (actionType === 'asterisk') {
              action = 'asteriskElement';
            } else if (actionType === 'redact') {
              action = 'redactElement';
            }
            
            const response = await chrome.tabs.sendMessage(tab.id, {
              action: action,
              elementInfo: result.elementInfo,
              save: save,
              type: actionType
            });
            
            console.log('Message sent successfully:', response);
            
            // Show notification with preview option
            await showVisibilityNotification(tab.id, result.elementInfo, actionType, save);
            
            // Update badge to show red notification
            setTimeout(async () => {
              await updateBadge(tab.id, null);
            }, 300);
            
            // After hiding/blurring, refresh the page to apply if saved
            if (save) {
              setTimeout(() => {
                chrome.tabs.reload(tab.id);
              }, 100);
            }
          } catch (error) {
            // If content script isn't ready, inject it and try again
            console.log('Content script not ready, injecting...', error);
            try {
              await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['content.js']
              });
              
              // Wait a bit for content script to initialize
              await new Promise(resolve => setTimeout(resolve, 200));
              
              // Try sending message again
              let action = 'hideElement';
              if (actionType === 'blur') {
                action = 'blurElement';
              } else if (actionType === 'asterisk') {
                action = 'asteriskElement';
              } else if (actionType === 'redact') {
                action = 'redactElement';
              }
              
              const response = await chrome.tabs.sendMessage(tab.id, {
                action: action,
                elementInfo: result.elementInfo,
                save: save,
                type: actionType
              });
              
              console.log('Message sent after injection:', response);
              
              // Show notification with preview option
              await showVisibilityNotification(tab.id, result.elementInfo, actionType, save);
              
              // Update badge to show red notification
              setTimeout(async () => {
                await updateBadge(tab.id, null);
              }, 300);
              
              // After hiding/blurring, refresh the page to apply if saved
              if (save) {
                setTimeout(() => {
                  chrome.tabs.reload(tab.id);
                }, 100);
              }
            } catch (retryError) {
              console.error('Error sending message to content script:', retryError);
              // Try direct injection as fallback
              try {
                // Load settings first
                const settingsResult = await chrome.storage.local.get(['blurIntensity', 'redactColor']);
                const blurIntensity = settingsResult.blurIntensity || 10;
                const redactColor = settingsResult.redactColor || '#000000';
                
                await chrome.scripting.executeScript({
                  target: { tabId: tab.id },
                  func: applyVisibilityChange,
                  args: [result.elementInfo.selector, actionType, save, blurIntensity, redactColor]
                });
                // Show notification even for fallback case
                await showVisibilityNotification(tab.id, result.elementInfo, actionType, save);
                
                // Update badge to show red notification
                setTimeout(async () => {
                  await updateBadge(tab.id, null);
                }, 300);
              } catch (fallbackError) {
                console.error('Fallback injection also failed:', fallbackError);
              }
            }
          }
        } else {
          console.log('No element info returned');
        }
      }
    } catch (error) {
      console.error('Error handling context menu click:', error);
    }
  }
});

// Function to be injected into page to get element info (no prompt)
function handleContextMenuClick(pageX, pageY, actionType) {
  // For asterisk and redact, check if there's a text selection
  if (actionType === 'asterisk' || actionType === 'redact') {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0 && !selection.isCollapsed) {
      // There's a text selection - return text selection info
      const range = selection.getRangeAt(0);
      const selectedText = selection.toString().trim();
      
      if (selectedText.length > 0) {
        // Get the container element for generating selector
        let container = range.commonAncestorContainer;
        if (container.nodeType !== 1) {
          container = container.parentElement;
        }
        
        // Generate selector for the container
        let selector = '';
        if (container.id) {
          selector = `#${container.id}`;
        } else {
          selector = container.tagName.toLowerCase();
          if (container.className && typeof container.className === 'string') {
            const classes = container.className.split(' ').filter(c => c.length > 0);
            if (classes.length > 0) {
              selector += '.' + classes.join('.');
            }
          }
          const parent = container.parentElement;
          if (parent) {
            const siblings = Array.from(parent.children);
            const index = siblings.indexOf(container) + 1;
            selector += `:nth-child(${index})`;
          }
        }
        
        // Store range information for reconstruction
        const startContainer = range.startContainer;
        const endContainer = range.endContainer;
        const startOffset = range.startOffset;
        const endOffset = range.endOffset;
        
        return {
          isTextSelection: true,
          textSelection: {
            selector: selector,
            selectedText: selectedText,
            startOffset: startOffset,
            endOffset: endOffset,
            startContainerText: startContainer.nodeType === 3 ? startContainer.textContent : '',
            endContainerText: endContainer.nodeType === 3 ? endContainer.textContent : ''
          }
        };
      }
    }
    
    // No text selection found for asterisk/redact - return error
    return {
      isTextSelection: false,
      error: 'Please select text to apply asterisk or redact'
    };
  }
  
  // For other actions (hide, blur), use element-based selection
  let element = null;
  
  // Try to get element from coordinates if available
  if (pageX !== null && pageY !== null) {
    const x = Number(pageX);
    const y = Number(pageY);
    
    if (!isNaN(x) && !isNaN(y)) {
      element = document.elementFromPoint(x, y);
    }
  }
  
  // Fallback: try to get element from selection or active element
  if (!element) {
    // Try selection first
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      element = range.commonAncestorContainer;
      if (element.nodeType !== 1) { // If it's a text node, get parent
        element = element.parentElement;
      }
    }
    
    // If still no element, try active element
    if (!element && document.activeElement) {
      element = document.activeElement;
    }
  }
  
  if (!element || element.nodeType !== 1) {
    console.error('No valid element found. Coordinates:', pageX, pageY);
    return null;
  }
  
  // Generate selector
  let selector = '';
  if (element.id) {
    selector = `#${element.id}`;
  } else {
    selector = element.tagName.toLowerCase();
    
    if (element.className && typeof element.className === 'string') {
      const classes = element.className.split(' ').filter(c => c.length > 0);
      if (classes.length > 0) {
        selector += '.' + classes.join('.');
      }
    }
    
    const parent = element.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children);
      const index = siblings.indexOf(element) + 1;
      selector += `:nth-child(${index})`;
    }
  }
  
  const description = element.textContent?.substring(0, 50).trim() || selector;
  
  console.log('Element selected:', { selector, description });
  
  return {
    elementInfo: {
      selector: selector,
      description: description
    }
  };
}

// Fallback function to directly apply visibility change
function applyVisibilityChange(selector, actionType, save, blurIntensity = 10, redactColor = '#000000') {
  try {
    const elements = document.querySelectorAll(selector);
    console.log(`Found ${elements.length} elements with selector: ${selector}`);
    
    elements.forEach(element => {
      if (actionType === 'blur') {
        element.style.setProperty('filter', `blur(${blurIntensity}px)`, 'important');
        element.style.setProperty('pointer-events', 'none', 'important');
      } else if (actionType === 'asterisk') {
        // Replace text content with asterisks
        const walker = document.createTreeWalker(
          element,
          NodeFilter.SHOW_TEXT,
          null,
          false
        );
        const textNodes = [];
        let node;
        while (node = walker.nextNode()) {
          textNodes.push(node);
        }
        textNodes.forEach(textNode => {
          const originalText = textNode.textContent;
          if (!textNode.dataset.originalText) {
            textNode.dataset.originalText = originalText;
          }
          textNode.textContent = '*'.repeat(Math.max(originalText.length, 3));
        });
      } else if (actionType === 'redact') {
        // Cover with solid color overlay
        element.style.setProperty('position', 'relative', 'important');
        element.style.setProperty('color', 'transparent', 'important');
        if (!element.querySelector('.redact-overlay')) {
          const overlay = document.createElement('div');
          overlay.className = 'redact-overlay';
          overlay.style.cssText = `position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: ${redactColor}; z-index: 9999; pointer-events: none;`;
          element.appendChild(overlay);
        }
      } else {
        element.style.setProperty('display', 'none', 'important');
      }
    });
    
    console.log(`Applied ${actionType} to ${elements.length} elements`);
  } catch (error) {
    console.error('Error applying visibility change:', error);
  }
}

// Store notification data: notificationId -> { tabId, selector, type }
const notificationData = new Map();

// Show notification when element is hidden/blurred
async function showVisibilityNotification(tabId, elementInfo, actionType, isPersistent) {
  try {
    let actionText = 'Hidden';
    if (actionType === 'blur') {
      actionText = 'Blurred';
    } else if (actionType === 'asterisk') {
      actionText = 'Asterisked';
    } else if (actionType === 'redact') {
      actionText = 'Redacted';
    }
    const persistenceText = isPersistent ? 'Persistent' : 'Once';
    const shortSelector = elementInfo.selector.length > 40 
      ? elementInfo.selector.substring(0, 37) + '...' 
      : elementInfo.selector;
    const description = elementInfo.description 
      ? (elementInfo.description.length > 50 ? elementInfo.description.substring(0, 47) + '...' : elementInfo.description)
      : '';
    
    const notificationId = `visibility-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    // Store notification data
    notificationData.set(notificationId, {
      tabId: tabId,
      selector: elementInfo.selector,
      type: actionType,
      isPersistent: isPersistent
    });
    
    const notificationOptions = {
      type: 'basic',
      title: `Element ${actionText} (${persistenceText})`,
      message: description ? `${shortSelector}\n${description}` : shortSelector,
      buttons: [
        { title: 'Preview' },
        { title: 'Show' }
      ],
      priority: 1
    };
    
    await chrome.notifications.create(notificationId, notificationOptions);
  } catch (error) {
    console.error('Error showing notification:', error);
  }
}

// Handle notification button clicks
chrome.notifications.onButtonClicked.addListener(async (notificationId, buttonIndex) => {
  const data = notificationData.get(notificationId);
  
  if (!data) {
    return;
  }
  
  try {
    const { tabId, selector, type } = data;
    
    if (buttonIndex === 0) {
      // Preview button - toggle preview
      await chrome.tabs.sendMessage(tabId, {
        action: 'preview',
        selector: selector
      });
    } else if (buttonIndex === 1) {
      // Show button - permanently show the element
      await chrome.tabs.sendMessage(tabId, {
        action: 'showElement',
        selector: selector
      });
      
      // If it was persistent, also remove from storage
      if (data.isPersistent) {
        const tab = await chrome.tabs.get(tabId);
        if (tab.url) {
          const url = new URL(tab.url);
          const domain = url.hostname;
          const result = await chrome.storage.local.get(domain);
          const hiddenElements = result[domain] || [];
          const filtered = hiddenElements.filter(el => el.selector !== selector);
          
          if (filtered.length === 0) {
            await chrome.storage.local.remove(domain);
          } else {
            await chrome.storage.local.set({ [domain]: filtered });
          }
          
          // Refresh content script
          await chrome.tabs.sendMessage(tabId, {
            action: 'refresh'
          });
        }
      }
      
      // Update badge after showing element
      setTimeout(async () => {
        await updateBadge(tabId, null);
      }, 200);
      
      // Close notification
      chrome.notifications.clear(notificationId);
      notificationData.delete(notificationId);
    }
  } catch (error) {
    console.error('Error handling notification button click:', error);
  }
});

// Handle notification clicks (when clicking the notification itself)
chrome.notifications.onClicked.addListener(async (notificationId) => {
  const data = notificationData.get(notificationId);
  
  if (!data) {
    return;
  }
  
  try {
    // Focus the tab
    await chrome.tabs.update(data.tabId, { active: true });
    
    // Toggle preview
    await chrome.tabs.sendMessage(data.tabId, {
      action: 'preview',
      selector: data.selector
    });
  } catch (error) {
    console.error('Error handling notification click:', error);
  }
});

// Handle messages from content script and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateBadge') {
    updateBadge(request.tabId || sender.tab?.id, request.count);
    sendResponse({ success: true });
  } else if (request.action === 'getTabId') {
    sendResponse({ tabId: sender.tab?.id });
  } else if (request.action === 'selectionModeChanged') {
    // Forward message to popup if it's open
    sendResponse({ success: true });
  }
  return true;
});

async function updateBadge(tabId, count) {
  if (!tabId) {
    return;
  }
  
  try {
    // Get domain for this tab
    const tab = await chrome.tabs.get(tabId);
    if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
      return;
    }
    
    let badgeCount = count;
    
    // If count not provided, get it from content script (includes both persistent and once-hidden)
    if (badgeCount === null || badgeCount === undefined) {
      try {
        const response = await chrome.tabs.sendMessage(tabId, {
          action: 'getAllHiddenElements'
        });
        
        if (response && response.success && response.elements) {
          badgeCount = response.elements.length;
        } else {
          // Fallback to storage count if content script unavailable
          const url = new URL(tab.url);
          const domain = url.hostname;
          const result = await chrome.storage.local.get(domain);
          const hiddenElements = result[domain] || [];
          badgeCount = hiddenElements.length;
        }
      } catch (error) {
        // Content script might not be ready, fallback to storage
        const url = new URL(tab.url);
        const domain = url.hostname;
        const result = await chrome.storage.local.get(domain);
        const hiddenElements = result[domain] || [];
        badgeCount = hiddenElements.length;
      }
    }
    
    if (badgeCount > 0) {
      chrome.action.setBadgeText({
        text: badgeCount.toString(),
        tabId: tabId
      });
      chrome.action.setBadgeBackgroundColor({
        color: '#e53e3e', // Red color
        tabId: tabId
      });
    } else {
      chrome.action.setBadgeText({
        text: '',
        tabId: tabId
      });
    }
  } catch (error) {
    console.error('Error updating badge:', error);
  }
}

// Update badge when tab is updated
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    updateBadge(tabId, null);
  }
});

// Update badge when storage changes
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local') {
    // Update badge for all tabs
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        if (tab.url) {
          updateBadge(tab.id, null);
        }
      });
    });
  }
});

