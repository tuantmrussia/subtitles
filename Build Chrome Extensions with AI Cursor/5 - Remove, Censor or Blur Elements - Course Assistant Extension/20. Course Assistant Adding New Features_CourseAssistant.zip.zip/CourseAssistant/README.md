# Element Hider - Chrome Extension

A modern Chrome extension that allows you to hide elements on websites with options for temporary (one-time) or saved (per-domain) hiding.

## Features

- **Right-Click Context Menu**: Quickly hide any element by right-clicking and selecting "Hide Element"
- **Save or One-Time Hide**: Choose to save hidden elements (persists across page reloads) or hide temporarily (one-time only)
- **Per-Domain Storage**: Hidden elements are saved per domain, so settings are specific to each website
- **Preview Hidden Elements**: Temporarily show hidden elements to verify what was hidden
- **Compact Popup UI**: Modern, compact popup window that displays all saved hidden elements for the current domain

## Installation

1. Clone or download this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" (toggle in top right)
4. Click "Load unpacked" and select the extension directory

## Usage

### Hiding Elements

1. **Right-click** on any element you want to hide
2. Select **"Hide Element"** from the context menu
3. A prompt will appear asking if you want to:
   - **OK**: Save the element (it will be hidden on future page loads)
   - **Cancel**: One-time hide (element reappears on page reload)

### Managing Hidden Elements

1. Click the extension in the toolbar
2. The popup will show all saved hidden elements for the current domain
3. Use the **eye icon** to preview a hidden element (temporarily show it)
4. Use the **X icon** to delete a saved hidden element

## Technical Details

- **Manifest V3**: Uses the latest Chrome extension manifest format
- **CSS-Based Hiding**: Elements are hidden using `display: none !important` CSS
- **Storage**: Uses Chrome's `chrome.storage.local` API for per-domain persistence
- **Content Scripts**: Injected into all pages to handle element hiding/showing
- **Background Service Worker**: Manages context menu and storage

## File Structure

```
CourseAssistant/
├── manifest.json          # Extension manifest
├── popup.html             # Popup UI HTML
├── popup.css              # Popup styling
├── popup.js               # Popup logic
├── content.js             # Content script (runs on web pages)
├── background.js          # Background service worker
└── README.md              # This file
```

## Permissions

- `storage`: To save hidden elements per domain
- `activeTab`: To access the current tab when using the popup
- `contextMenus`: To add the right-click context menu option
- `scripting`: To inject scripts for element selection and hiding
- `<all_urls>`: To work on all websites

## Development

To modify the extension:

1. Make your changes to the source files
2. Go to `chrome://extensions/`
3. Click the refresh icon on the extension card
4. Test your changes

## Notes

- Hidden elements are stored per domain (e.g., all pages on `example.com`)
- One-time hidden elements are not saved and will reappear on page reload
- Saved hidden elements persist across browser sessions

## License

This project is open source and available for use and modification.

