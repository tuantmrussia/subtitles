# Chrome Extension Implementation Plan: Element Hider

## Overview
A modern Chrome extension that allows users to hide elements on websites with options for temporary (one-time) or saved (per-domain) hiding. Features include right-click context menu and preview functionality.

## Architecture

### Files Structure
```
CourseAssistant/
├── manifest.json          # Extension manifest (Manifest V3)
├── popup.html             # Popup UI HTML
├── popup.css              # Popup styling
├── popup.js               # Popup logic
├── content.js             # Content script (runs on web pages)
├── background.js          # Background service worker
└── README.md              # Documentation
```

## Implementation Details

### 1. manifest.json
- Manifest V3 format
- Permissions: `storage`, `activeTab`, `contextMenus`, `scripting`
- Content script injection on all pages
- Background service worker
- Popup action configuration
- Context menu integration

### 2. popup.html
- Compact, modern UI design
- Header with extension name and version
- List of saved hidden elements for current domain
- Each entry shows:
  - Element selector/description
  - Preview button (eye icon)
  - Delete button (X icon)
  - Remember toggle indicator
- Empty state message when no elements hidden
- Modern dark/light theme support

### 3. popup.css
- Modern, compact design
- Responsive layout
- Smooth animations
- Clean typography
- Icon buttons for actions
- Scrollable list for multiple elements

### 4. popup.js
- Load and display saved hidden elements for current domain
- Handle preview button clicks (send message to content script)
- Handle delete button clicks (remove from storage and content script)
- Update UI when elements are added/removed

### 5. content.js
- Listen for hide element requests (from context menu or popup)
- Apply CSS `display: none !important` to elements
- Handle preview toggle (temporarily show hidden elements)
- Generate CSS selectors for elements
- Track hidden elements on current page
- Re-apply saved hidden elements on page load

### 6. background.js
- Service worker (Manifest V3)
- Create context menu item on installation
- Handle context menu clicks (hide element)
- Manage storage (save/retrieve hidden elements per domain)
- Listen for messages from content script and popup
- Storage structure: `{ [domain]: [{ selector, timestamp, description }] }`

## Features Implementation

### Feature 1: Hide Elements via Context Menu
- Right-click on any element → "Hide Element" option
- Element is hidden immediately
- Option to save or one-time hide
- If saved, added to popup list

### Feature 2: Save Hidden Elements (Per Domain)
- Storage key: domain (e.g., "example.com")
- Store array of hidden element selectors
- Re-apply on page load via content script
- Persist across page reloads

### Feature 3: One-Time Hide
- Hide element without saving to storage
- Element reappears on page reload
- Not shown in popup list

### Feature 4: Preview Hidden Elements
- Eye icon button in popup
- Temporarily toggle `display: none` to show element
- Visual indicator when previewing
- Re-hide after preview


## Storage Schema

```javascript
{
  "example.com": [
    {
      "selector": ".advertisement",
      "timestamp": 1234567890,
      "description": "Advertisement banner"
    }
  ],
  "another-site.com": [...]
}
```

## Message Passing Flow

1. **Context Menu → Background → Content Script**
   - User right-clicks → Background receives context menu click
   - Background sends message to content script with element info
   - Content script hides element

2. **Popup → Background → Content Script**
   - Popup requests preview/delete
   - Background forwards to content script
   - Content script toggles visibility or removes CSS

3. **Page Load → Content Script**
   - Content script loads saved selectors for domain
   - Applies CSS to hide elements

## CSS Selector Generation Strategy

- Use `getUniqueSelector()` function to generate reliable selectors
- Fallback to XPath if CSS selector not unique enough
- Store selector with element for restoration

## UI/UX Considerations

- Compact popup (max 400px width, 500px height)
- Smooth animations for show/hide
- Clear visual feedback for actions
- Empty state when no elements hidden
- Loading states when applying changes
- Error handling for invalid selectors

## Testing Considerations

- Test on various websites
- Handle dynamic content (SPA navigation)
- Test context menu on different element types
- Test storage persistence
- Handle edge cases (nested elements, iframes)

