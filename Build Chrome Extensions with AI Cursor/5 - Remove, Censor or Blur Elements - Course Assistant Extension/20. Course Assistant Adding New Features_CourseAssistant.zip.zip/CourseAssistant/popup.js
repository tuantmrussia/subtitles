// Get current tab domain and load hidden elements
document.addEventListener('DOMContentLoaded', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = new URL(tab.url);
  const domain = url.hostname;
  
  // Setup tab switching
  setupTabs();
  
  // Load settings
  await loadSettings();
  
  // Setup settings event listeners
  setupSettingsListeners();
  
  // Setup zoom settings event listeners
  setupZoomSettingsListeners();
  
  // Setup area selection button
  setupAreaSelection();
  
  // Load and display hidden elements
  await loadHiddenElements(domain);
  
  // Refresh preview button states after loading
  setTimeout(() => {
    refreshPreviewStates();
  }, 200);
  
  // Check if selection mode is active
  checkSelectionModeStatus();
});

// Setup tab switching functionality
function setupTabs() {
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabPanels = document.querySelectorAll('.tab-panel');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const targetTab = button.getAttribute('data-tab');
      
      // Remove active class from all buttons and panels
      tabButtons.forEach(btn => btn.classList.remove('active'));
      tabPanels.forEach(panel => panel.classList.remove('active'));
      
      // Add active class to clicked button and corresponding panel
      button.classList.add('active');
      document.getElementById(`tab-${targetTab}`).classList.add('active');
    });
  });
}

// Load settings from storage
async function loadSettings() {
  try {
    const result = await chrome.storage.local.get(['blurIntensity', 'redactColor', 'zoomKeyBinding', 'zoomAmount', 'zoomSmoothness']);
    const blurIntensity = result.blurIntensity || 10;
    const redactColor = result.redactColor || '#000000';
    
    const blurSlider = document.getElementById('blurIntensity');
    const blurValue = document.getElementById('blurValue');
    const redactColorInput = document.getElementById('redactColor');
    
    blurSlider.value = blurIntensity;
    blurValue.textContent = `${blurIntensity}px`;
    redactColorInput.value = redactColor;
    
    // Load zoom settings
    const zoomKeyBinding = result.zoomKeyBinding || 'Control';
    const zoomAmount = result.zoomAmount !== undefined ? parseFloat(result.zoomAmount) : 2.0;
    const zoomSmoothness = result.zoomSmoothness !== undefined ? parseInt(result.zoomSmoothness) : 15;
    
    // Set zoom key binding radio button
    const zoomKeyRadios = document.querySelectorAll('input[name="zoomKeyBinding"]');
    zoomKeyRadios.forEach(radio => {
      if (radio.value === zoomKeyBinding) {
        radio.checked = true;
      }
    });
    
    // Set zoom amount slider
    const zoomAmountSlider = document.getElementById('zoomAmount');
    const zoomAmountValue = document.getElementById('zoomAmountValue');
    zoomAmountSlider.value = zoomAmount;
    zoomAmountValue.textContent = `${zoomAmount.toFixed(1)}x`;
    
    // Set zoom smoothness slider
    const zoomSmoothnessSlider = document.getElementById('zoomSmoothness');
    const zoomSmoothnessValue = document.getElementById('zoomSmoothnessValue');
    zoomSmoothnessSlider.value = zoomSmoothness;
    zoomSmoothnessValue.textContent = `${zoomSmoothness}%`;
  } catch (error) {
    console.error('Error loading settings:', error);
  }
}

// Setup event listeners for settings
function setupSettingsListeners() {
  const blurSlider = document.getElementById('blurIntensity');
  const blurValue = document.getElementById('blurValue');
  const redactColorInput = document.getElementById('redactColor');
  
  // Blur intensity slider
  blurSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    blurValue.textContent = `${value}px`;
    saveSettings({ blurIntensity: value });
    
    // Notify content script to update blur intensity
    updateBlurIntensity(value);
  });
  
  // Redact color picker
  redactColorInput.addEventListener('change', (e) => {
    const color = e.target.value;
    saveSettings({ redactColor: color });
    
    // Notify content script to update redact color
    updateRedactColor(color);
  });
}

// Setup zoom settings event listeners
function setupZoomSettingsListeners() {
  // Zoom key binding radio buttons
  const zoomKeyRadios = document.querySelectorAll('input[name="zoomKeyBinding"]');
  zoomKeyRadios.forEach(radio => {
    radio.addEventListener('change', async (e) => {
      if (e.target.checked) {
        const keyBinding = e.target.value;
        await saveSettings({ zoomKeyBinding: keyBinding });
        await updateZoomSettings();
      }
    });
  });
  
  // Zoom amount slider
  const zoomAmountSlider = document.getElementById('zoomAmount');
  const zoomAmountValue = document.getElementById('zoomAmountValue');
  zoomAmountSlider.addEventListener('input', (e) => {
    const value = parseFloat(e.target.value);
    zoomAmountValue.textContent = `${value.toFixed(1)}x`;
    saveSettings({ zoomAmount: value });
    updateZoomSettings();
  });
  
  // Zoom smoothness slider
  const zoomSmoothnessSlider = document.getElementById('zoomSmoothness');
  const zoomSmoothnessValue = document.getElementById('zoomSmoothnessValue');
  zoomSmoothnessSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    zoomSmoothnessValue.textContent = `${value}%`;
    // Convert percentage to decimal (1-50% -> 0.01-0.5)
    const smoothnessDecimal = value / 100;
    saveSettings({ zoomSmoothness: value });
    updateZoomSettings();
  });
}

// Update zoom settings in content script
async function updateZoomSettings() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
      return;
    }
    
    const result = await chrome.storage.local.get(['zoomKeyBinding', 'zoomAmount', 'zoomSmoothness']);
    const zoomKeyBinding = result.zoomKeyBinding || 'Control';
    const zoomAmount = result.zoomAmount !== undefined ? parseFloat(result.zoomAmount) : 2.0;
    const zoomSmoothness = result.zoomSmoothness !== undefined ? parseInt(result.zoomSmoothness) : 15;
    const smoothnessDecimal = zoomSmoothness / 100;
    
    try {
      await chrome.tabs.sendMessage(tab.id, {
        action: 'updateZoomSettings',
        keyBinding: zoomKeyBinding,
        zoomAmount: zoomAmount,
        smoothness: smoothnessDecimal
      });
    } catch (sendError) {
      // Content script might not be ready, try injecting it
      if (sendError.message && sendError.message.includes('Could not establish connection')) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
          });
          // Wait a bit for content script to initialize
          await new Promise(resolve => setTimeout(resolve, 200));
          // Try sending message again
          await chrome.tabs.sendMessage(tab.id, {
            action: 'updateZoomSettings',
            keyBinding: zoomKeyBinding,
            zoomAmount: zoomAmount,
            smoothness: smoothnessDecimal
          });
        } catch (injectError) {
          console.error('Error injecting content script for zoom settings:', injectError);
        }
      } else {
        console.error('Error sending zoom settings to content script:', sendError);
      }
    }
  } catch (error) {
    console.error('Error updating zoom settings:', error);
  }
}

// Save settings to storage
async function saveSettings(settings) {
  try {
    await chrome.storage.local.set(settings);
  } catch (error) {
    console.error('Error saving settings:', error);
  }
}

// Update blur intensity in content script
async function updateBlurIntensity(intensity) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://')) {
      await chrome.tabs.sendMessage(tab.id, {
        action: 'updateBlurIntensity',
        intensity: intensity
      });
    }
  } catch (error) {
    console.error('Error updating blur intensity:', error);
  }
}

// Update redact color in content script
async function updateRedactColor(color) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://')) {
      await chrome.tabs.sendMessage(tab.id, {
        action: 'updateRedactColor',
        color: color
      });
    }
  } catch (error) {
    console.error('Error updating redact color:', error);
  }
}

async function refreshPreviewStates() {
  const previewButtons = document.querySelectorAll('.btn-preview');
  previewButtons.forEach(button => {
    const selector = button.getAttribute('data-selector');
    if (selector) {
      updatePreviewButtonState(button, selector);
    }
  });
}

async function loadHiddenElements(domain) {
  try {
    const elementsList = document.getElementById('elementsList');
    
    // Get persistent elements from storage
    const result = await chrome.storage.local.get(domain);
    const persistentElements = result[domain] || [];
    
    // Get all hidden elements (including once-hidden) from content script
    let allElements = [];
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'getAllHiddenElements'
      });
      
      if (response && response.success && response.elements) {
        allElements = response.elements;
      }
    } catch (error) {
      console.log('Could not get once-hidden elements from content script:', error);
      // Fallback to only persistent elements
      allElements = persistentElements.map(el => ({ ...el, isPersistent: true }));
    }
    
    if (allElements.length === 0) {
      elementsList.innerHTML = `
        <div class="empty-state">
          <p>No hidden elements for this domain</p>
        </div>
      `;
      return;
    }
    
    elementsList.innerHTML = '';
    
    // Create items for all elements (both persistent and once)
    allElements.forEach((element, index) => {
      const elementItem = createElementItem(element, index, domain);
      elementsList.appendChild(elementItem);
    });
  } catch (error) {
    console.error('Error loading hidden elements:', error);
  }
}

function createElementItem(element, index, domain) {
  const item = document.createElement('div');
  item.className = 'element-item';
  
  const selector = element.selector || 'Unknown selector';
  const description = element.description || selector.substring(0, 50) + (selector.length > 50 ? '...' : '');
  const type = element.type || 'hide';
  let typeLabel = 'Hide';
  let typeClass = 'type-hide';
  if (type === 'blur') {
    typeLabel = 'Blur';
    typeClass = 'type-blur';
  } else if (type === 'asterisk') {
    typeLabel = 'Asterisk';
    typeClass = 'type-asterisk';
  } else if (type === 'redact') {
    typeLabel = 'Redact';
    typeClass = 'type-redact';
  }
  const isPersistent = element.isPersistent !== false; // Default to true if not specified
  
  // Add persistence indicator to type label
  const persistenceLabel = isPersistent ? 'Persistent' : 'Once';
  
  item.innerHTML = `
    <div class="element-info">
      <div class="element-header">
        <span class="type-badge ${typeClass}">${typeLabel} ${persistenceLabel}</span>
        <div class="element-selector" title="${selector}">${selector}</div>
      </div>
      <div class="element-description">${description}</div>
    </div>
    <div class="element-actions">
      <button class="btn btn-preview" data-index="${index}" data-selector="${selector}" title="Toggle preview">
        <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
          <circle cx="12" cy="12" r="3"></circle>
        </svg>
      </button>
      <button class="btn btn-delete" data-index="${index}" data-selector="${selector}" data-persistent="${isPersistent}" title="Delete">
        <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="3 6 5 6 21 6"></polyline>
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
        </svg>
      </button>
    </div>
  `;
  
  // Preview button handler
  const previewBtn = item.querySelector('.btn-preview');
  previewBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    try {
      // Toggle preview for this element
      await chrome.tabs.sendMessage(tab.id, {
        action: 'preview',
        selector: selector
      });
      
      // Update button state after a short delay to ensure state is updated
      setTimeout(() => {
        updatePreviewButtonState(previewBtn, selector);
      }, 100);
    } catch (error) {
      console.error('Error toggling preview:', error);
    }
  });
  
  // Delete button handler
  const deleteBtn = item.querySelector('.btn-delete');
  deleteBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const selectorToDelete = selector;
    const isPersistentElement = deleteBtn.getAttribute('data-persistent') === 'true';
    
    // If persistent, remove from storage; if once, just remove from content script
    if (isPersistentElement) {
      // Find the index in persistent elements
      const result = await chrome.storage.local.get(domain);
      const persistentElements = result[domain] || [];
      const persistentIndex = persistentElements.findIndex(el => el.selector === selector);
      if (persistentIndex !== -1) {
        await deleteElement(domain, persistentIndex);
      }
    }
    
    // Notify content script to show the element
    try {
      await chrome.tabs.sendMessage(tab.id, {
        action: 'showElement',
        selector: selectorToDelete
      });
      
      // Refresh the list
      await loadHiddenElements(domain);
      
      // Refresh content script if it was persistent
      if (isPersistentElement) {
        await chrome.tabs.sendMessage(tab.id, {
          action: 'refresh'
        });
      }
      
      // Update badge
      chrome.runtime.sendMessage({
        action: 'updateBadge',
        tabId: tab.id
      });
    } catch (error) {
      console.error('Error showing element:', error);
    }
  });
  
  // Initialize preview button state
  updatePreviewButtonState(previewBtn, selector);
  
  return item;
}

async function updatePreviewButtonState(button, selector) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const response = await chrome.tabs.sendMessage(tab.id, {
      action: 'getElements'
    });
    
    if (response && response.success) {
      const element = response.elements.find(e => e.selector === selector);
      if (element) {
        if (element.isPreviewing) {
          button.classList.add('active');
          button.title = 'Hide preview';
        } else {
          button.classList.remove('active');
          button.title = 'Show preview';
        }
      }
    }
  } catch (error) {
    // Element might not be loaded yet, ignore
  }
}

async function deleteElement(domain, index) {
  try {
    const result = await chrome.storage.local.get(domain);
    const hiddenElements = result[domain] || [];
    
    hiddenElements.splice(index, 1);
    
    if (hiddenElements.length === 0) {
      await chrome.storage.local.remove(domain);
    } else {
      await chrome.storage.local.set({ [domain]: hiddenElements });
    }
    
    // Update badge
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.runtime.sendMessage({
      action: 'updateBadge',
      tabId: tab.id
    });
  } catch (error) {
    console.error('Error deleting element:', error);
  }
}

// Listen for storage changes to update the list
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (tabs[0]) {
        const url = new URL(tabs[0].url);
        const domain = url.hostname;
        await loadHiddenElements(domain);
        setTimeout(() => {
          refreshPreviewStates();
        }, 200);
      }
    });
  }
});

// Setup area selection functionality
function setupAreaSelection() {
  const selectAreaBtn = document.getElementById('selectAreaBtn');
  
  selectAreaBtn.addEventListener('click', async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
        return;
      }
      
      // Try to send message to content script
      let response;
      try {
        response = await chrome.tabs.sendMessage(tab.id, {
          action: 'toggleSelectionMode'
        });
      } catch (error) {
        // Content script might not be ready, inject it first
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
          });
          
          // Wait a bit for content script to initialize
          await new Promise(resolve => setTimeout(resolve, 200));
          
          // Try sending message again
          response = await chrome.tabs.sendMessage(tab.id, {
            action: 'toggleSelectionMode'
          });
        } catch (injectError) {
          console.error('Error injecting content script:', injectError);
          return;
        }
      }
      
      if (response && response.success && response.isActive) {
        // Close popup immediately so user can see the page and select area
        window.close();
      }
    } catch (error) {
      console.error('Error activating selection mode:', error);
    }
  });
}

// Check if selection mode is currently active (not needed since popup closes)
async function checkSelectionModeStatus() {
  // Popup closes when selection starts, so no need to check status
  // This function is kept for compatibility but does nothing
}

// Periodically refresh the list to catch once-hidden elements
setInterval(async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://')) {
      const url = new URL(tab.url);
      const domain = url.hostname;
      await loadHiddenElements(domain);
      setTimeout(() => {
        refreshPreviewStates();
      }, 100);
    }
  } catch (error) {
    // Ignore errors (popup might be closed)
  }
}, 1000); // Refresh every second when popup is open

