// Content script to handle element hiding on web pages

let hiddenElements = new Map(); // Map of selector -> { elements, isPreviewing, type }
let savedSelectors = []; // Selectors saved for this domain
let blurIntensity = 10; // Default blur intensity
let redactColor = '#000000'; // Default redact color
let selectionModeActive = false; // Area selection mode state
let selectionStart = null; // { x, y } for area selection
let selectionOverlay = null; // Overlay element for selection rectangle
let selectionElements = []; // Elements within selected area

// Zoom functionality variables
let zoomActive = false;
let zoomKeyPressed = false;
let currentZoom = 1.0;
let targetZoom = 1.0;
let zoomSettings = {
  keyBinding: 'Control', // 'Control', 'Alt', 'Shift', 'Z'
  zoomAmount: 2.0, // Multiplier (e.g., 2.0 = 200%)
  smoothness: 0.15 // Interpolation speed (0-1, lower = smoother)
};
let zoomWrapper = null;
let animationFrameId = null;
let zoomCursorX = 0; // Cursor X position in viewport
let zoomCursorY = 0; // Cursor Y position in viewport
let lastMouseX = 0; // Last known mouse X position (for keyboard-triggered zoom)
let lastMouseY = 0; // Last known mouse Y position (for keyboard-triggered zoom)
let zoomStartScrollX = 0; // Scroll X when zoom started
let zoomStartScrollY = 0; // Scroll Y when zoom started
let zoomDocX = 0; // Document X position under cursor when zoom started (unscaled)
let zoomDocY = 0; // Document Y position under cursor when zoom started (unscaled)

// Initialize on page load
init();

async function init() {
  // Initialize mouse position tracking early
  document.addEventListener('mousemove', (e) => {
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
  }, { passive: true });
  
  // Load settings
  await loadSettings();
  
  // Get current domain and load saved hidden elements
  const domain = window.location.hostname;
  loadSavedElements(domain);
  
  // Listen for messages from popup and background
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    handleMessage(request, sender, sendResponse);
    return true; // Keep channel open for async response
  });
  
  // Listen for storage changes to update zoom settings
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
      if (changes.zoomKeyBinding || changes.zoomAmount || changes.zoomSmoothness) {
        loadSettings();
      }
    }
  });
}

// Load settings from storage
async function loadSettings() {
  try {
    const result = await chrome.storage.local.get(['blurIntensity', 'redactColor', 'zoomKeyBinding', 'zoomAmount', 'zoomSmoothness']);
    blurIntensity = result.blurIntensity || 10;
    redactColor = result.redactColor || '#000000';
    
    // Load zoom settings - use saved preference or default to 'Control'
    zoomSettings.keyBinding = result.zoomKeyBinding || 'Control';
    if (result.zoomAmount !== undefined) {
      zoomSettings.zoomAmount = parseFloat(result.zoomAmount) || 2.0;
    }
    if (result.zoomSmoothness !== undefined) {
      zoomSettings.smoothness = parseFloat(result.zoomSmoothness) || 0.15;
    }
    
    // Initialize zoom functionality
    initZoom();
  } catch (error) {
    console.error('Error loading settings:', error);
  }
}

async function loadSavedElements(domain) {
  try {
    const result = await chrome.storage.local.get(domain);
    savedSelectors = result[domain] || [];
    
    // Apply CSS to hide/blur saved elements
    savedSelectors.forEach(item => {
      try {
        const elements = document.querySelectorAll(item.selector);
        const type = item.type || 'hide'; // Default to 'hide' for backward compatibility
        
        elements.forEach(element => {
          // Clear any previous visibility effects before applying saved one
          clearAllVisibilityEffects(element);
          
          // Store original display if not already stored
          if (!element.dataset.originalDisplay) {
            const originalDisplay = window.getComputedStyle(element).display;
            element.dataset.originalDisplay = originalDisplay;
          }
          
          // Store original filter if blurring
          if (type === 'blur' && !element.dataset.originalFilter) {
            const originalFilter = window.getComputedStyle(element).filter;
            element.dataset.originalFilter = originalFilter || 'none';
          }
          
          // Store original text content if asterisking
          if (type === 'asterisk' && !element.dataset.originalTextStored) {
            const walker = document.createTreeWalker(
              element,
              NodeFilter.SHOW_TEXT,
              null,
              false
            );
            const textNodes = [];
            let node;
            while (node = walker.nextNode()) {
              textNodes.push(node);
            }
            textNodes.forEach(textNode => {
              if (!textNode.dataset.originalText) {
                textNode.dataset.originalText = textNode.textContent;
              }
            });
            element.dataset.originalTextStored = 'true';
          }
          
          // Store original position and color if redacting
          if (type === 'redact' && !element.dataset.originalPosition) {
            const computedStyle = window.getComputedStyle(element);
            element.dataset.originalPosition = computedStyle.position || 'static';
            element.dataset.originalColor = computedStyle.color || '';
          }
          
          // Apply effect based on type
          if (type === 'blur') {
            element.style.setProperty('filter', `blur(${blurIntensity}px)`, 'important');
            element.style.setProperty('pointer-events', 'none', 'important');
          } else if (type === 'asterisk') {
            // Replace text content with asterisks
            const walker = document.createTreeWalker(
              element,
              NodeFilter.SHOW_TEXT,
              null,
              false
            );
            let node;
            while (node = walker.nextNode()) {
              const originalText = node.dataset.originalText || node.textContent;
              if (!node.dataset.originalText) {
                node.dataset.originalText = originalText;
              }
              node.textContent = '*'.repeat(Math.max(originalText.length, 3));
            }
          } else if (type === 'redact') {
            // Cover with solid color overlay
            element.style.setProperty('position', 'relative', 'important');
            element.style.setProperty('color', 'transparent', 'important');
            if (!element.querySelector('.redact-overlay')) {
              const overlay = document.createElement('div');
              overlay.className = 'redact-overlay';
              overlay.style.cssText = `position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: ${redactColor}; z-index: 9999; pointer-events: none;`;
              element.appendChild(overlay);
            } else {
              // Update existing overlay color
              const overlay = element.querySelector('.redact-overlay');
              overlay.style.background = redactColor;
            }
          } else {
            element.style.setProperty('display', 'none', 'important');
          }
          
          // Track in hiddenElements map
          if (!hiddenElements.has(item.selector)) {
            hiddenElements.set(item.selector, {
              elements: [],
              isPreviewing: false,
              type: type
            });
          }
          const hiddenData = hiddenElements.get(item.selector);
          if (!hiddenData.elements.includes(element)) {
            hiddenData.elements.push(element);
          }
          hiddenData.type = type;
        });
      } catch (error) {
        console.error(`Error hiding/blurring element with selector ${item.selector}:`, error);
      }
    });
    
    // Update badge count
    updateBadgeCount();
  } catch (error) {
    console.error('Error loading saved elements:', error);
  }
}

async function handleMessage(request, sender, sendResponse) {
  try {
    console.log('Content script received message:', request);
    
    switch (request.action) {
      case 'hideElement':
        console.log('Handling hideElement action');
        await hideElement(request.elementInfo, request.save, 'hide');
        sendResponse({ success: true });
        break;
        
      case 'blurElement':
        console.log('Handling blurElement action');
        await hideElement(request.elementInfo, request.save, 'blur');
        sendResponse({ success: true });
        break;
        
      case 'asteriskElement':
        console.log('Handling asteriskElement action');
        await hideElement(request.elementInfo, request.save, 'asterisk');
        sendResponse({ success: true });
        break;
        
      case 'redactElement':
        console.log('Handling redactElement action');
        await hideElement(request.elementInfo, request.save, 'redact');
        sendResponse({ success: true });
        break;
        
      case 'preview':
        togglePreview(request.selector);
        sendResponse({ success: true });
        break;
        
      case 'refresh':
        const domain = window.location.hostname;
        await loadSavedElements(domain);
        updateBadgeCount();
        sendResponse({ success: true });
        break;
        
      case 'showElement':
        showElementBySelector(request.selector);
        sendResponse({ success: true });
        break;
        
      case 'getElements':
        // Return both saved and once-hidden elements
        const allElements = Array.from(hiddenElements.entries()).map(([selector, data]) => {
          // Check if this selector is saved (persistent)
          const isSaved = savedSelectors.some(item => item.selector === selector);
          return {
            selector,
            type: data.type || 'hide',
            isPreviewing: data.isPreviewing,
            isPersistent: isSaved
          };
        });
        sendResponse({ 
          success: true, 
          elements: allElements
        });
        break;
        
      case 'getAllHiddenElements':
        // Get all hidden elements (both persistent and once) for popup display
        const allHiddenElements = Array.from(hiddenElements.entries()).map(([selector, data]) => {
          const savedItem = savedSelectors.find(item => item.selector === selector);
          return {
            selector,
            description: savedItem?.description || selector.substring(0, 50) + (selector.length > 50 ? '...' : ''),
            type: data.type || 'hide',
            isPersistent: !!savedItem,
            isPreviewing: data.isPreviewing
          };
        });
        sendResponse({ 
          success: true, 
          elements: allHiddenElements
        });
        break;
        
      case 'updateBlurIntensity':
        blurIntensity = request.intensity || 10;
        // Update all blurred elements
        updateAllBlurredElements();
        sendResponse({ success: true });
        break;
        
      case 'updateRedactColor':
        redactColor = request.color || '#000000';
        // Update all redacted elements
        updateAllRedactedElements();
        sendResponse({ success: true });
        break;
        
      case 'toggleSelectionMode':
        selectionModeActive = !selectionModeActive;
        if (selectionModeActive) {
          enableSelectionMode();
        } else {
          disableSelectionMode();
        }
        sendResponse({ success: true, isActive: selectionModeActive });
        break;
        
      case 'cancelSelectionMode':
        selectionModeActive = false;
        disableSelectionMode();
        sendResponse({ success: true });
        break;
        
      case 'getSelectionModeStatus':
        sendResponse({ success: true, isActive: selectionModeActive });
        break;
        
      case 'applyAreaSelection':
        applyAreaSelection(request.elements, request.type, request.save);
        sendResponse({ success: true });
        break;
        
      case 'asteriskTextSelection':
        console.log('Handling asteriskTextSelection action');
        await handleTextSelection(request.textSelection, request.save, 'asterisk');
        sendResponse({ success: true });
        break;
        
      case 'redactTextSelection':
        console.log('Handling redactTextSelection action');
        await handleTextSelection(request.textSelection, request.save, 'redact');
        sendResponse({ success: true });
        break;
        
      case 'updateZoomSettings':
        zoomSettings.keyBinding = request.keyBinding || zoomSettings.keyBinding;
        zoomSettings.zoomAmount = request.zoomAmount !== undefined ? parseFloat(request.zoomAmount) : zoomSettings.zoomAmount;
        zoomSettings.smoothness = request.smoothness !== undefined ? parseFloat(request.smoothness) : zoomSettings.smoothness;
        // Reinitialize zoom with new settings
        cleanupZoom();
        initZoom();
        sendResponse({ success: true });
        break;
        
      default:
        sendResponse({ success: false, error: 'Unknown action' });
    }
  } catch (error) {
    console.error('Error handling message:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle text selection for asterisk/redact
async function handleTextSelection(textSelectionInfo, save = false, type = 'asterisk') {
  try {
    // Try to get current selection first (should still be available)
    const selection = window.getSelection();
    let range = null;
    
    if (selection && selection.rangeCount > 0 && !selection.isCollapsed) {
      // Use current selection if available
      range = selection.getRangeAt(0).cloneRange();
    } else {
      // Selection was cleared, try to reconstruct from stored info
      // Find the container element
      const container = document.querySelector(textSelectionInfo.selector);
      if (!container) {
        console.error('Container element not found:', textSelectionInfo.selector);
        return;
      }
      
      // Search for the selected text in the container
      const selectedText = textSelectionInfo.selectedText;
      const walker = document.createTreeWalker(
        container,
        NodeFilter.SHOW_TEXT,
        null,
        false
      );
      
      const textNodes = [];
      let node;
      while (node = walker.nextNode()) {
        textNodes.push(node);
      }
      
      // Find the text by searching for it
      let fullText = '';
      let startNode = null;
      let startOffset = 0;
      let endNode = null;
      let endOffset = 0;
      
      for (let i = 0; i < textNodes.length; i++) {
        const nodeText = textNodes[i].textContent;
        const combinedText = fullText + nodeText;
        const foundIndex = combinedText.indexOf(selectedText);
        
        if (foundIndex !== -1) {
          // Found the text - calculate positions
          if (foundIndex < fullText.length) {
            // Starts in previous node
            if (i > 0) {
              startNode = textNodes[i - 1];
              startOffset = foundIndex - (fullText.length - textNodes[i - 1].textContent.length);
            } else {
              startNode = textNodes[i];
              startOffset = foundIndex;
            }
          } else {
            startNode = textNodes[i];
            startOffset = foundIndex - fullText.length;
          }
          
          const endPos = foundIndex + selectedText.length;
          let currentPos = fullText.length + nodeText.length;
          
          if (endPos <= currentPos) {
            // Ends in same node
            endNode = textNodes[i];
            endOffset = endPos - fullText.length;
          } else {
            // Spans multiple nodes
            let j = i + 1;
            while (j < textNodes.length && currentPos < endPos) {
              currentPos += textNodes[j].textContent.length;
              j++;
            }
            if (j > 0) {
              endNode = textNodes[j - 1];
              const prevPos = currentPos - textNodes[j - 1].textContent.length;
              endOffset = endPos - prevPos;
            }
          }
          
          if (startNode && endNode) {
            range = document.createRange();
            range.setStart(startNode, startOffset);
            range.setEnd(endNode, endOffset);
            break;
          }
        }
        
        fullText += nodeText;
      }
    }
    
    if (!range) {
      console.error('Could not create range for text selection');
      return;
    }
    
    // Apply the effect to the selected text
    if (type === 'asterisk') {
      applyAsteriskToRange(range, textSelectionInfo);
    } else if (type === 'redact') {
      applyRedactToRange(range, textSelectionInfo);
    }
    
    // Clear selection
    if (selection) {
      selection.removeAllRanges();
    }
    
    // Generate a unique selector for this text selection
    const container = range.commonAncestorContainer;
    let containerElement = container.nodeType === 1 ? container : container.parentElement;
    const selector = generateSelector(containerElement);
    const uniqueId = `text-selection-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    // Track this text selection
    if (!hiddenElements.has(uniqueId)) {
      hiddenElements.set(uniqueId, {
        elements: [containerElement],
        isPreviewing: false,
        type: type,
        textSelection: true,
        rangeInfo: textSelectionInfo
      });
    }
    
    // If saving, add to storage
    if (save) {
      await saveElement(uniqueId, {
        selector: selector,
        description: textSelectionInfo.selectedText.substring(0, 50)
      }, type);
    }
    
    // Update badge
    updateBadgeCount();
  } catch (error) {
    console.error('Error handling text selection:', error);
  }
}

// Apply asterisk to a text range
function applyAsteriskToRange(range, textSelectionInfo) {
  const selectedText = range.toString();
  if (!selectedText || selectedText.trim().length === 0) {
    return;
  }
  
  // Store original text
  const originalText = selectedText;
  
  // Replace selected text with asterisks
  const asteriskText = '*'.repeat(Math.max(originalText.length, 3));
  
  // Delete the selected content and insert asterisks
  range.deleteContents();
  const textNode = document.createTextNode(asteriskText);
  range.insertNode(textNode);
  
  // Store original text in the text node for restoration
  textNode.dataset.originalText = originalText;
  textNode.dataset.isAsterisked = 'true';
}

// Apply redact to a text range
function applyRedactToRange(range, textSelectionInfo) {
  const selectedText = range.toString();
  if (!selectedText || selectedText.trim().length === 0) {
    return;
  }
  
  // Extract the selected content
  const contents = range.extractContents();
  
  // Create a span wrapper with redact styling
  const redactSpan = document.createElement('span');
  redactSpan.className = 'redact-text-selection';
  redactSpan.style.cssText = `
    background-color: ${redactColor};
    color: ${redactColor};
    padding: 2px 0;
    display: inline-block;
  `;
  redactSpan.dataset.originalText = selectedText;
  redactSpan.dataset.isRedacted = 'true';
  
  // Add the extracted content (which will be invisible due to color matching background)
  redactSpan.appendChild(contents);
  
  // Insert the redacted span
  range.insertNode(redactSpan);
}

async function hideElement(elementInfo, save = false, type = 'hide') {
  const selector = elementInfo.selector;
  
  console.log('hideElement called:', { selector, save, type });
  
  // Hide or blur the element immediately
  hideElementBySelector(selector, false, type);
  
  // If saving, add to storage
  if (save) {
    await saveElement(selector, elementInfo, type);
  }
  
  // Update badge
  updateBadgeCount();
}

// Helper function to clear all previous visibility effects
function clearAllVisibilityEffects(element) {
  // Clear display (if hidden) - restore original or remove style
  const currentDisplay = window.getComputedStyle(element).display;
  if (currentDisplay === 'none' || element.style.display === 'none') {
    if (element.dataset.originalDisplay) {
      element.style.setProperty('display', element.dataset.originalDisplay, 'important');
    } else {
      element.style.removeProperty('display');
    }
  }
  
  // Clear blur filter - restore original or remove style
  const currentFilter = window.getComputedStyle(element).filter;
  if (currentFilter && currentFilter.includes('blur')) {
    if (element.dataset.originalFilter) {
      element.style.setProperty('filter', element.dataset.originalFilter, 'important');
    } else {
      element.style.removeProperty('filter');
    }
    element.style.removeProperty('pointer-events');
  }
  
  // Clear asterisk (restore original text) - always check and restore if needed
  if (element.dataset.originalTextStored === 'true') {
    const walker = document.createTreeWalker(
      element,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    let node;
    while (node = walker.nextNode()) {
      if (node.dataset.originalText) {
        node.textContent = node.dataset.originalText;
      }
    }
  }
  
  // Clear redact overlay - always remove if present
  const overlay = element.querySelector('.redact-overlay');
  if (overlay) {
    overlay.remove();
  }
  // Restore position if it was changed for redact
  if (element.dataset.originalPosition) {
    const originalPosition = element.dataset.originalPosition;
    if (originalPosition !== 'relative') {
      element.style.setProperty('position', originalPosition, 'important');
    } else {
      element.style.removeProperty('position');
    }
  }
  // Restore color if it was changed for redact
  if (element.dataset.originalColor !== undefined) {
    const originalColor = element.dataset.originalColor;
    if (originalColor) {
      element.style.setProperty('color', originalColor, 'important');
    } else {
      element.style.removeProperty('color');
    }
  }
}

function hideElementBySelector(selector, isPreviewing, type = 'hide') {
  try {
    const elements = document.querySelectorAll(selector);
    console.log(`hideElementBySelector: Found ${elements.length} elements for selector "${selector}", type: ${type}`);
    
    if (elements.length === 0) {
      console.warn(`No elements found for selector: ${selector}`);
      return;
    }
    
    elements.forEach((element, index) => {
      // Clear any previous visibility effects before applying new one
      clearAllVisibilityEffects(element);
      
      // Store original display style if not already stored
      if (!element.dataset.originalDisplay) {
        const originalDisplay = window.getComputedStyle(element).display;
        element.dataset.originalDisplay = originalDisplay;
        console.log(`Stored original display for element ${index}: ${originalDisplay}`);
      }
      
      // Store original filter if blurring
      if (type === 'blur' && !element.dataset.originalFilter) {
        const originalFilter = window.getComputedStyle(element).filter;
        element.dataset.originalFilter = originalFilter || 'none';
        console.log(`Stored original filter for element ${index}: ${originalFilter || 'none'}`);
      }
      
      // Store original text content if asterisking
      if (type === 'asterisk' && !element.dataset.originalTextStored) {
        const walker = document.createTreeWalker(
          element,
          NodeFilter.SHOW_TEXT,
          null,
          false
        );
        const textNodes = [];
        let node;
        while (node = walker.nextNode()) {
          textNodes.push(node);
        }
        textNodes.forEach(textNode => {
          if (!textNode.dataset.originalText) {
            textNode.dataset.originalText = textNode.textContent;
          }
        });
        element.dataset.originalTextStored = 'true';
        console.log(`Stored original text for element ${index}`);
      }
      
      // Store original position and color if redacting
      if (type === 'redact' && !element.dataset.originalPosition) {
        const computedStyle = window.getComputedStyle(element);
        element.dataset.originalPosition = computedStyle.position || 'static';
        element.dataset.originalColor = computedStyle.color || '';
        console.log(`Stored original position/color for element ${index}`);
      }
      
      // Apply effect based on type
      if (type === 'blur') {
        element.style.setProperty('filter', `blur(${blurIntensity}px)`, 'important');
        element.style.setProperty('pointer-events', 'none', 'important');
        console.log(`Applied blur to element ${index}`);
      } else if (type === 'asterisk') {
        // Replace text content with asterisks
        const walker = document.createTreeWalker(
          element,
          NodeFilter.SHOW_TEXT,
          null,
          false
        );
        let node;
        while (node = walker.nextNode()) {
          const originalText = node.dataset.originalText || node.textContent;
          if (!node.dataset.originalText) {
            node.dataset.originalText = originalText;
          }
          node.textContent = '*'.repeat(Math.max(originalText.length, 3));
        }
        console.log(`Applied asterisk to element ${index}`);
      } else if (type === 'redact') {
        // Cover with solid color overlay
        element.style.setProperty('position', 'relative', 'important');
        element.style.setProperty('color', 'transparent', 'important');
        if (!element.querySelector('.redact-overlay')) {
          const overlay = document.createElement('div');
          overlay.className = 'redact-overlay';
          overlay.style.cssText = `position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: ${redactColor}; z-index: 9999; pointer-events: none;`;
          element.appendChild(overlay);
        } else {
          // Update existing overlay color
          const overlay = element.querySelector('.redact-overlay');
          overlay.style.background = redactColor;
        }
        console.log(`Applied redact to element ${index}`);
      } else {
        element.style.setProperty('display', 'none', 'important');
        console.log(`Applied hide to element ${index}`);
      }
      
      // Track hidden/blurred element
      if (!hiddenElements.has(selector)) {
        hiddenElements.set(selector, {
          elements: [],
          isPreviewing: isPreviewing,
          type: type
        });
      }
      
      const hiddenData = hiddenElements.get(selector);
      if (!hiddenData.elements.includes(element)) {
        hiddenData.elements.push(element);
      }
      hiddenData.isPreviewing = isPreviewing;
      hiddenData.type = type;
    });
    
    console.log(`Successfully processed ${elements.length} elements`);
  } catch (error) {
    console.error('Error hiding/blurring element:', error);
  }
}

function togglePreview(selector) {
  const hiddenData = hiddenElements.get(selector);
  
  if (!hiddenData) {
    // If not in map, try to find and show it (might be a saved element that was just loaded)
    try {
      const elements = document.querySelectorAll(selector);
      // Find type from saved selectors
      const savedItem = savedSelectors.find(item => item.selector === selector);
      const type = savedItem?.type || 'hide';
      
      elements.forEach(element => {
        const currentDisplay = window.getComputedStyle(element).display;
        const currentFilter = window.getComputedStyle(element).filter;
        
        const hasRedactOverlay = element.querySelector('.redact-overlay');
        const isAsterisked = Array.from(element.childNodes).some(node => 
          node.nodeType === Node.TEXT_NODE && node.textContent && node.textContent.match(/^\*+$/)
        );
        
        if (currentDisplay === 'none' || currentFilter.includes('blur') || hasRedactOverlay || isAsterisked) {
          // Element is hidden, blurred, redacted, or asterisked, show it for preview
          const originalDisplay = element.dataset.originalDisplay || 'block';
          element.style.setProperty('display', originalDisplay, 'important');
          
          if (type === 'blur' || currentFilter.includes('blur')) {
            const originalFilter = element.dataset.originalFilter || 'none';
            element.style.setProperty('filter', originalFilter, 'important');
            element.style.removeProperty('pointer-events');
          } else if (type === 'asterisk' || isAsterisked) {
            // Restore original text
            const walker = document.createTreeWalker(
              element,
              NodeFilter.SHOW_TEXT,
              null,
              false
            );
            let node;
            while (node = walker.nextNode()) {
              if (node.dataset.originalText) {
                node.textContent = node.dataset.originalText;
              }
            }
          } else if (type === 'redact' || hasRedactOverlay) {
            // Remove redact overlay and restore color
            const overlay = element.querySelector('.redact-overlay');
            if (overlay) {
              overlay.remove();
            }
            const originalColor = element.dataset.originalColor || '';
            if (originalColor) {
              element.style.setProperty('color', originalColor, 'important');
            } else {
              element.style.removeProperty('color');
            }
            const originalPosition = element.dataset.originalPosition || 'static';
            if (originalPosition !== 'relative') {
              element.style.setProperty('position', originalPosition, 'important');
            } else {
              element.style.removeProperty('position');
            }
          }
          
          // Track it
          if (!hiddenElements.has(selector)) {
            hiddenElements.set(selector, {
              elements: [],
              isPreviewing: true,
              type: type
            });
          }
          const data = hiddenElements.get(selector);
          if (!data.elements.includes(element)) {
            data.elements.push(element);
          }
          data.isPreviewing = true;
          data.type = type;
        }
      });
    } catch (error) {
      console.error('Error previewing element:', error);
    }
    return;
  }
  
  hiddenData.isPreviewing = !hiddenData.isPreviewing;
  const type = hiddenData.type || 'hide';
  
  hiddenData.elements.forEach(element => {
    if (hiddenData.isPreviewing) {
      // Show element temporarily (restore original state)
      const originalDisplay = element.dataset.originalDisplay || 'block';
      element.style.setProperty('display', originalDisplay, 'important');
      
      if (type === 'blur') {
        const originalFilter = element.dataset.originalFilter || 'none';
        element.style.setProperty('filter', originalFilter, 'important');
        element.style.removeProperty('pointer-events');
      } else if (type === 'asterisk') {
        // Restore original text
        const walker = document.createTreeWalker(
          element,
          NodeFilter.SHOW_TEXT,
          null,
          false
        );
        let node;
        while (node = walker.nextNode()) {
          if (node.dataset.originalText) {
            node.textContent = node.dataset.originalText;
          }
        }
      } else if (type === 'redact') {
        // Remove redact overlay and restore color
        const overlay = element.querySelector('.redact-overlay');
        if (overlay) {
          overlay.remove();
        }
        const originalColor = element.dataset.originalColor || '';
        if (originalColor) {
          element.style.setProperty('color', originalColor, 'important');
        } else {
          element.style.removeProperty('color');
        }
        const originalPosition = element.dataset.originalPosition || 'static';
        if (originalPosition !== 'relative') {
          element.style.setProperty('position', originalPosition, 'important');
        } else {
          element.style.removeProperty('position');
        }
      }
    } else {
      // Apply effect again
      if (type === 'blur') {
        element.style.setProperty('filter', `blur(${blurIntensity}px)`, 'important');
        element.style.setProperty('pointer-events', 'none', 'important');
      } else if (type === 'asterisk') {
        // Replace text content with asterisks
        const walker = document.createTreeWalker(
          element,
          NodeFilter.SHOW_TEXT,
          null,
          false
        );
        let node;
        while (node = walker.nextNode()) {
          const originalText = node.dataset.originalText || node.textContent;
          if (!node.dataset.originalText) {
            node.dataset.originalText = originalText;
          }
          node.textContent = '*'.repeat(Math.max(originalText.length, 3));
        }
      } else if (type === 'redact') {
        // Cover with solid color overlay
        element.style.setProperty('position', 'relative', 'important');
        element.style.setProperty('color', 'transparent', 'important');
        if (!element.querySelector('.redact-overlay')) {
          const overlay = document.createElement('div');
          overlay.className = 'redact-overlay';
          overlay.style.cssText = `position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: ${redactColor}; z-index: 9999; pointer-events: none;`;
          element.appendChild(overlay);
        } else {
          // Update existing overlay color
          const overlay = element.querySelector('.redact-overlay');
          overlay.style.background = redactColor;
        }
      } else {
        element.style.setProperty('display', 'none', 'important');
      }
    }
  });
}

function showElementBySelector(selector) {
  try {
    const hiddenData = hiddenElements.get(selector);
    
    const elements = document.querySelectorAll(selector);
    elements.forEach(element => {
      // Clear all visibility effects (regardless of type)
      clearAllVisibilityEffects(element);
      
      // Restore original display
      const originalDisplay = element.dataset.originalDisplay || window.getComputedStyle(element).display || 'block';
      element.style.setProperty('display', originalDisplay, 'important');
      
      // Restore original filter if it was stored
      if (element.dataset.originalFilter) {
        element.style.setProperty('filter', element.dataset.originalFilter, 'important');
      } else {
        element.style.removeProperty('filter');
      }
      element.style.removeProperty('pointer-events');
      
      // Restore original text if asterisked
      if (element.dataset.originalTextStored === 'true') {
        const walker = document.createTreeWalker(
          element,
          NodeFilter.SHOW_TEXT,
          null,
          false
        );
        let node;
        while (node = walker.nextNode()) {
          if (node.dataset.originalText) {
            node.textContent = node.dataset.originalText;
          }
        }
        delete element.dataset.originalTextStored;
      }
      
      // Clean up redact overlay and restore position/color if redacted
      const overlay = element.querySelector('.redact-overlay');
      if (overlay) {
        overlay.remove();
      }
      if (element.dataset.originalPosition) {
        const originalPosition = element.dataset.originalPosition;
        if (originalPosition !== 'relative') {
          element.style.setProperty('position', originalPosition, 'important');
        } else {
          element.style.removeProperty('position');
        }
        delete element.dataset.originalPosition;
      }
      if (element.dataset.originalColor !== undefined) {
        const originalColor = element.dataset.originalColor;
        if (originalColor) {
          element.style.setProperty('color', originalColor, 'important');
        } else {
          element.style.removeProperty('color');
        }
        delete element.dataset.originalColor;
      }
      
      // Clean up all stored original values
      delete element.dataset.originalDisplay;
      delete element.dataset.originalFilter;
    });
    // Remove from hidden elements map
    hiddenElements.delete(selector);
  } catch (error) {
    console.error('Error showing element:', error);
  }
}

async function saveElement(selector, elementInfo, type = 'hide') {
  const domain = window.location.hostname;
  
  try {
    const result = await chrome.storage.local.get(domain);
    const hiddenElements = result[domain] || [];
    
    // Check if already saved
    const exists = hiddenElements.some(item => item.selector === selector);
    if (!exists) {
      hiddenElements.push({
        selector: selector,
        description: elementInfo.description || selector,
        type: type,
        timestamp: Date.now()
      });
      
      await chrome.storage.local.set({ [domain]: hiddenElements });
      savedSelectors = hiddenElements;
    }
  } catch (error) {
    console.error('Error saving element:', error);
  }
}

function updateBadgeCount() {
  // Count all hidden elements (both persistent and once-hidden)
  const count = hiddenElements.size;
  
  chrome.runtime.sendMessage({
    action: 'updateBadge',
    count: count
  });
}

// Update all blurred elements with new intensity
function updateAllBlurredElements() {
  hiddenElements.forEach((data, selector) => {
    if (data.type === 'blur' && !data.isPreviewing) {
      data.elements.forEach(element => {
        element.style.setProperty('filter', `blur(${blurIntensity}px)`, 'important');
      });
    }
  });
}

// Update all redacted elements with new color
function updateAllRedactedElements() {
  hiddenElements.forEach((data, selector) => {
    if (data.type === 'redact' && !data.isPreviewing) {
      data.elements.forEach(element => {
        const overlay = element.querySelector('.redact-overlay');
        if (overlay) {
          overlay.style.background = redactColor;
        }
      });
    }
  });
}

// Generate unique CSS selector for an element
function generateSelector(element) {
  if (element.id) {
    return `#${element.id}`;
  }
  
  // Try to build a unique selector
  let selector = element.tagName.toLowerCase();
  
  if (element.className) {
    const classes = element.className.split(' ').filter(c => c.length > 0);
    if (classes.length > 0) {
      selector += '.' + classes.join('.');
    }
  }
  
  // Add nth-child if needed for uniqueness
  const parent = element.parentElement;
  if (parent) {
    const siblings = Array.from(parent.children);
    const index = siblings.indexOf(element) + 1;
    selector += `:nth-child(${index})`;
  }
  
  return selector;
}

// Initialize zoom functionality
function initZoom() {
  // Clean up any existing zoom setup
  cleanupZoom();
  
  // Create zoom wrapper if it doesn't exist
  if (!zoomWrapper) {
    zoomWrapper = document.createElement('div');
    zoomWrapper.id = 'smoothzoom-wrapper';
    zoomWrapper.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 2147483647;
      transform-origin: 0 0;
      transition: none;
    `;
    
    // Move body content into wrapper (we'll use transform on body instead)
    // Actually, we'll apply transform directly to body for better compatibility
  }
  
  // Add event listeners for key and mouse
  document.addEventListener('keydown', handleZoomKeyDown, true);
  document.addEventListener('keyup', handleZoomKeyUp, true);
  document.addEventListener('mousemove', handleZoomMouseMove, true);
  // Use { passive: false } to allow preventDefault() on wheel events
  document.addEventListener('wheel', handleZoomWheel, { passive: false, capture: true });
  window.addEventListener('scroll', handleZoomScroll, true);
  
  // Prevent default zoom behavior when zoom key is held
  document.addEventListener('keydown', (e) => {
    if (isZoomKeyPressed(e)) {
      e.preventDefault();
      e.stopPropagation();
    }
  }, true);
}

// Cleanup zoom functionality
function cleanupZoom() {
  document.removeEventListener('keydown', handleZoomKeyDown, true);
  document.removeEventListener('keyup', handleZoomKeyUp, true);
  document.removeEventListener('mousemove', handleZoomMouseMove, true);
  // Remove with same options used for addEventListener
  document.removeEventListener('wheel', handleZoomWheel, { passive: false, capture: true });
  window.removeEventListener('scroll', handleZoomScroll, true);
  
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId);
    animationFrameId = null;
  }
  
  // Reset zoom
  if (zoomActive) {
    resetZoom();
  }
}

// Check if zoom key is pressed
function isZoomKeyPressed(e) {
  // Don't trigger zoom if user is typing in an input field (for Z key)
  const target = e.target;
  const isInputField = target && (
    target.tagName === 'INPUT' ||
    target.tagName === 'TEXTAREA' ||
    target.isContentEditable ||
    target.getAttribute('contenteditable') === 'true'
  );
  
  if (isInputField && zoomSettings.keyBinding === 'Z') {
    return false; // Don't zoom when typing in input fields with Z key
  }
  
  const key = zoomSettings.keyBinding;
  if (key === 'Control') {
    return e.ctrlKey && !e.altKey && !e.shiftKey && !e.metaKey;
  } else if (key === 'Alt') {
    return e.altKey && !e.ctrlKey && !e.shiftKey && !e.metaKey;
  } else if (key === 'Shift') {
    return e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey;
  } else if (key === 'Z') {
    // Check for 'Z' key (case-insensitive)
    return (e.key === 'z' || e.key === 'Z') && !e.ctrlKey && !e.altKey && !e.metaKey;
  }
  return false;
}

// Handle zoom key down
function handleZoomKeyDown(e) {
  // Only process if the current binding key is pressed
  if (isZoomKeyPressed(e) && !zoomKeyPressed) {
    zoomKeyPressed = true;
    if (!zoomActive) {
      startZoom(e);
    }
  }
}

// Handle zoom key up
function handleZoomKeyUp(e) {
  const key = zoomSettings.keyBinding;
  
  // Check if the current binding key was released
  let keyReleased = false;
  
  if (key === 'Control') {
    keyReleased = !e.ctrlKey;
  } else if (key === 'Alt') {
    keyReleased = !e.altKey;
  } else if (key === 'Shift') {
    keyReleased = !e.shiftKey;
  } else if (key === 'Z') {
    // For Z key, check if Z was released (keyup event for z/Z)
    keyReleased = (e.key === 'z' || e.key === 'Z');
  }
  
  // Only process if the active binding key was released
  if (keyReleased && zoomKeyPressed) {
    zoomKeyPressed = false;
    if (zoomActive) {
      stopZoom(); // This will animate back to zoom 1.0
    }
  }
}

// Handle mouse move during zoom
function handleZoomMouseMove(e) {
  // Always track last mouse position for keyboard-triggered zoom
  lastMouseX = e.clientX;
  lastMouseY = e.clientY;
  
  if (zoomActive) {
    zoomCursorX = e.clientX;
    zoomCursorY = e.clientY;
    updateZoomPosition(e.clientX, e.clientY);
  } else if (zoomKeyPressed) {
    // Track cursor even when not zoomed yet (key pressed but zoom animating)
    zoomCursorX = e.clientX;
    zoomCursorY = e.clientY;
    // Update zoom position if zoom is already active but cursor moved
    if (currentZoom !== 1.0) {
      updateZoomPosition(e.clientX, e.clientY);
    }
  }
}

// Handle scroll during zoom (to maintain cursor position)
let isAdjustingScroll = false; // Flag to prevent feedback loops

function handleZoomScroll(e) {
  if (zoomActive && currentZoom !== 1.0 && !isAdjustingScroll) {
    try {
      // When user scrolls while zoomed, update the fixed document point
      // to account for the new scroll position, keeping cursor position stable
      const currentScrollX = window.scrollX || window.pageXOffset;
      const currentScrollY = window.scrollY || window.pageYOffset;
      
      // Recalculate the document position under cursor at current zoom level
      // This ensures the zoom stays centered on the cursor after scrolling
      zoomDocX = currentScrollX + (zoomCursorX / currentZoom);
      zoomDocY = currentScrollY + (zoomCursorY / currentZoom);
      
      // Use requestAnimationFrame to adjust scroll on next frame
      // This prevents feedback loops and ensures smooth updates
      requestAnimationFrame(() => {
        if (zoomActive && currentZoom !== 1.0) {
          isAdjustingScroll = true;
          adjustScrollForZoom(zoomCursorX, zoomCursorY);
          // Reset flag after a short delay to allow scroll to settle
          setTimeout(() => {
            isAdjustingScroll = false;
          }, 50);
        }
      });
    } catch (error) {
      // Silently handle errors during scroll (don't spam console)
      isAdjustingScroll = false;
    }
  }
}

// Handle wheel during zoom (for fine adjustment)
function handleZoomWheel(e) {
  if (zoomActive && zoomKeyPressed) {
    try {
      e.preventDefault();
      e.stopPropagation();
      
      // Update cursor position from wheel event
      if (e.clientX !== undefined && e.clientY !== undefined) {
        zoomCursorX = e.clientX;
        zoomCursorY = e.clientY;
        lastMouseX = e.clientX;
        lastMouseY = e.clientY;
      } else {
        // Fallback to last known position if wheel event doesn't have coordinates
        if (lastMouseX > 0 && lastMouseY > 0) {
          zoomCursorX = lastMouseX;
          zoomCursorY = lastMouseY;
        }
      }
      
      // Ensure cursor position is valid
      if (!zoomCursorX || !zoomCursorY || zoomCursorX <= 0 || zoomCursorY <= 0) {
        zoomCursorX = zoomCursorX || window.innerWidth / 2;
        zoomCursorY = zoomCursorY || window.innerHeight / 2;
      }
      
      const delta = e.deltaY > 0 ? -0.1 : 0.1;
      zoomSettings.zoomAmount = Math.max(1.1, Math.min(5.0, zoomSettings.zoomAmount + delta));
      targetZoom = zoomSettings.zoomAmount;
      
      // Update the fixed document point when adjusting zoom with wheel
      // This keeps the cursor position stable during wheel adjustments
      if (currentZoom !== 1.0 && currentZoom > 0) {
        const currentScrollX = window.scrollX || window.pageXOffset || 0;
        const currentScrollY = window.scrollY || window.pageYOffset || 0;
        
        // Prevent division by zero or invalid calculations
        if (currentZoom > 0 && isFinite(zoomCursorX) && isFinite(zoomCursorY)) {
          zoomDocX = currentScrollX + (zoomCursorX / currentZoom);
          zoomDocY = currentScrollY + (zoomCursorY / currentZoom);
        }
      }
    } catch (error) {
      console.error('Error in handleZoomWheel:', error);
      // Don't break zoom functionality if wheel handling fails
    }
  }
}

// Start zoom
function startZoom(e) {
  zoomActive = true;
  targetZoom = zoomSettings.zoomAmount;
  currentZoom = 1.0;
  
  // Get initial mouse position - prefer event coordinates, then last known position, then center
  if (e && typeof e.clientX === 'number' && typeof e.clientY === 'number') {
    zoomCursorX = e.clientX;
    zoomCursorY = e.clientY;
  } else if (lastMouseX > 0 || lastMouseY > 0) {
    // Use last known mouse position (for keyboard-triggered zoom)
    zoomCursorX = lastMouseX;
    zoomCursorY = lastMouseY;
  } else {
    // Fallback to center of viewport
    zoomCursorX = window.innerWidth / 2;
    zoomCursorY = window.innerHeight / 2;
  }
  
  // Store initial scroll position (at zoom 1.0)
  zoomStartScrollX = window.scrollX || window.pageXOffset;
  zoomStartScrollY = window.scrollY || window.pageYOffset;
  
  // Calculate and store the ABSOLUTE document position under cursor (at zoom 1.0)
  // This is the fixed point on the page we want to keep under the cursor
  // docPos = scrollPos + viewportPos (at zoom 1.0)
  zoomDocX = zoomStartScrollX + zoomCursorX;
  zoomDocY = zoomStartScrollY + zoomCursorY;
  
  // Set transform origin to cursor position (this makes zoom center on cursor)
  document.body.style.transformOrigin = `${zoomCursorX}px ${zoomCursorY}px`;
  
  animateZoom();
}

// Stop zoom - returns to default position (zoom 1.0)
function stopZoom() {
  zoomActive = false;
  targetZoom = 1.0;
  
  // When releasing the key, we want to smoothly return to zoom 1.0
  // The animation will handle the smooth transition
  animateZoom();
}

// Reset zoom immediately
function resetZoom() {
  zoomActive = false;
  zoomKeyPressed = false;
  currentZoom = 1.0;
  targetZoom = 1.0;
  zoomCursorX = 0;
  zoomCursorY = 0;
  zoomStartScrollX = 0;
  zoomStartScrollY = 0;
  zoomDocX = 0;
  zoomDocY = 0;
  
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId);
    animationFrameId = null;
  }
  
  document.body.style.transform = '';
  document.body.style.transformOrigin = '';
}

// Update zoom position (called when cursor moves during zoom)
function updateZoomPosition(mouseX, mouseY) {
  // Update cursor position
  zoomCursorX = mouseX;
  zoomCursorY = mouseY;
  
  // Update transform origin to new cursor position
  document.body.style.transformOrigin = `${mouseX}px ${mouseY}px`;
  
  // When cursor moves during zoom, recalculate the fixed document point
  // This allows the zoom to follow the cursor as it moves
  const currentScrollX = window.scrollX || window.pageXOffset;
  const currentScrollY = window.scrollY || window.pageYOffset;
  
  // Calculate the NEW document position under cursor at current zoom level
  // At zoom level z: docPos = scrollPos + (viewportPos / z)
  // This becomes the new fixed point to keep under the cursor
  const newDocX = currentScrollX + (mouseX / currentZoom);
  const newDocY = currentScrollY + (mouseY / currentZoom);
  
  // Update the fixed document point to follow cursor movement
  zoomDocX = newDocX;
  zoomDocY = newDocY;
  
  // Adjust scroll to keep the new document position under cursor
  if (currentZoom !== 1.0) {
    adjustScrollForZoom(mouseX, mouseY);
  }
}

// Adjust scroll position to keep cursor position fixed during zoom
function adjustScrollForZoom(mouseX, mouseY) {
  // We want to keep the document point (zoomDocX, zoomDocY) under the cursor at viewport position (mouseX, mouseY)
  // 
  // When content is scaled by currentZoom with transform-origin at (mouseX, mouseY):
  // - The document point at zoomDocX is visually positioned at: (zoomDocX - scrollX) * currentZoom + scrollX
  // - But we want it at viewport position mouseX
  // - Since transform-origin is at mouseX, the scaling happens around that point
  // - The correct formula: mouseX = (zoomDocX - scrollX) * currentZoom
  // - Solving for scrollX: scrollX = zoomDocX - (mouseX / currentZoom)
  
  const newScrollX = zoomDocX - (mouseX / currentZoom);
  const newScrollY = zoomDocY - (mouseY / currentZoom);
  
  // Clamp scroll values to valid ranges
  const maxScrollX = Math.max(0, document.documentElement.scrollWidth - window.innerWidth);
  const maxScrollY = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
  
  const clampedScrollX = Math.max(0, Math.min(newScrollX, maxScrollX));
  const clampedScrollY = Math.max(0, Math.min(newScrollY, maxScrollY));
  
  // Only apply scroll if it's different from current scroll (avoid unnecessary updates)
  const currentScrollX = window.scrollX || window.pageXOffset;
  const currentScrollY = window.scrollY || window.pageYOffset;
  
  if (Math.abs(clampedScrollX - currentScrollX) > 0.1 || Math.abs(clampedScrollY - currentScrollY) > 0.1) {
    // Apply scroll adjustment
    window.scrollTo({
      left: clampedScrollX,
      top: clampedScrollY,
      behavior: 'auto'
    });
  }
}

// Animate zoom with smooth interpolation
function animateZoom() {
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId);
  }
  
  const animate = () => {
    // Smooth interpolation using exponential easing
    const diff = targetZoom - currentZoom;
    if (Math.abs(diff) < 0.001) {
      currentZoom = targetZoom;
      if (!zoomActive && currentZoom === 1.0) {
        // Reset transform when zoom returns to 1.0
        document.body.style.transform = '';
        document.body.style.transformOrigin = '';
        
        // Restore scroll to original position (approximately)
        // When zoom is 1.0, the scroll should naturally return to the original position
        // The adjustScrollForZoom will handle this, but we ensure it's called one last time
        if (zoomDocX > 0 && zoomDocY > 0) {
          // Restore scroll to keep the document point at cursor position
          const finalScrollX = zoomDocX - zoomCursorX;
          const finalScrollY = zoomDocY - zoomCursorY;
          window.scrollTo({
            left: Math.max(0, finalScrollX),
            top: Math.max(0, finalScrollY),
            behavior: 'auto'
          });
        }
        
        animationFrameId = null;
        return;
      }
    } else {
      // Interpolate based on smoothness setting
      // Lower smoothness value = smoother (slower) interpolation
      const lerpSpeed = Math.max(0.01, Math.min(0.5, zoomSettings.smoothness));
      currentZoom += diff * lerpSpeed;
    }
    
    // Apply transform with origin at cursor position
    document.body.style.transform = `scale(${currentZoom})`;
    
    // Continuously adjust scroll during animation to keep the fixed document point under cursor
    // This interpolates smoothly from normal view to zoomed view
    if (currentZoom !== 1.0) {
      adjustScrollForZoom(zoomCursorX, zoomCursorY);
    }
    
    // Continue animation if needed
    if (zoomActive || Math.abs(currentZoom - targetZoom) > 0.001) {
      animationFrameId = requestAnimationFrame(animate);
    } else {
      animationFrameId = null;
    }
  };
  
  animationFrameId = requestAnimationFrame(animate);
}

// Get current mouse position (fallback if event not available)
function getCurrentMousePosition() {
  // Try to get from last known position or use center of viewport
  return {
    x: window.innerWidth / 2,
    y: window.innerHeight / 2
  };
}

// Expose function for context menu usage
window.hideElementFromContextMenu = function(element) {
  const selector = generateSelector(element);
  const description = element.textContent?.substring(0, 50) || selector;
  
  // Show prompt to save or one-time hide
  const save = confirm(`Hide element?\n\nSelector: ${selector}\n\nClick OK to save (persists on reload)\nClick Cancel for one-time hide`);
  
  hideElement({
    selector: selector,
    description: description,
    element: element
  }, save);
};

// Enable area selection mode
function enableSelectionMode() {
  document.body.style.cursor = 'crosshair';
  document.addEventListener('mousedown', handleSelectionStart, true);
  document.addEventListener('mousemove', handleSelectionMove, true);
  document.addEventListener('mouseup', handleSelectionEnd, true);
  
  // Prevent text selection during selection mode
  document.addEventListener('selectstart', preventSelection, true);
  
  // Create selection overlay
  if (!selectionOverlay) {
    selectionOverlay = document.createElement('div');
    selectionOverlay.id = 'element-hider-selection-overlay';
    selectionOverlay.style.cssText = `
      position: fixed;
      border: 2px dashed #4299e1;
      background: rgba(66, 153, 225, 0.1);
      pointer-events: none;
      z-index: 999999;
      display: none;
    `;
    document.body.appendChild(selectionOverlay);
  }
}

// Disable area selection mode
function disableSelectionMode() {
  document.body.style.cursor = '';
  document.removeEventListener('mousedown', handleSelectionStart, true);
  document.removeEventListener('mousemove', handleSelectionMove, true);
  document.removeEventListener('mouseup', handleSelectionEnd, true);
  document.removeEventListener('selectstart', preventSelection, true);
  
  // Remove selection overlay
  if (selectionOverlay) {
    selectionOverlay.style.display = 'none';
  }
  
  // Clear selection state
  selectionStart = null;
  selectionElements = [];
  
  // Notify popup that selection mode is disabled
  try {
    chrome.runtime.sendMessage({
      action: 'selectionModeChanged',
      isActive: false
    });
  } catch (error) {
    // Ignore errors if popup is closed
  }
}

// Prevent text selection during selection mode
function preventSelection(e) {
  if (selectionModeActive) {
    e.preventDefault();
    return false;
  }
}

// Handle selection start
function handleSelectionStart(e) {
  if (!selectionModeActive || e.button !== 0) return; // Only left mouse button
  
  e.preventDefault();
  e.stopPropagation();
  
  const rect = document.documentElement.getBoundingClientRect();
  selectionStart = {
    x: e.clientX,
    y: e.clientY
  };
  
  selectionOverlay.style.display = 'block';
  updateSelectionOverlay(selectionStart.x, selectionStart.y, selectionStart.x, selectionStart.y);
}

// Handle selection move
function handleSelectionMove(e) {
  if (!selectionModeActive || !selectionStart) return;
  
  e.preventDefault();
  e.stopPropagation();
  
  updateSelectionOverlay(selectionStart.x, selectionStart.y, e.clientX, e.clientY);
}

// Handle selection end
function handleSelectionEnd(e) {
  if (!selectionModeActive || !selectionStart) return;
  
  e.preventDefault();
  e.stopPropagation();
  
  const rect = {
    left: Math.min(selectionStart.x, e.clientX),
    top: Math.min(selectionStart.y, e.clientY),
    right: Math.max(selectionStart.x, e.clientX),
    bottom: Math.max(selectionStart.y, e.clientY)
  };
  
  // Find all elements within the selected area
  selectionElements = findElementsInArea(rect);
  
  // Store the selected elements before disabling selection mode
  const selectedElements = [...selectionElements];
  
  // Disable selection mode immediately after selection ends
  selectionModeActive = false;
  disableSelectionMode();
  
  if (selectedElements.length > 0) {
    // Show dialog to choose effect type
    showAreaSelectionDialog(selectedElements);
  } else {
    // No elements found, selection mode already disabled
  }
}

// Update selection overlay rectangle
function updateSelectionOverlay(x1, y1, x2, y2) {
  const left = Math.min(x1, x2);
  const top = Math.min(y1, y2);
  const width = Math.abs(x2 - x1);
  const height = Math.abs(y2 - y1);
  
  selectionOverlay.style.left = left + 'px';
  selectionOverlay.style.top = top + 'px';
  selectionOverlay.style.width = width + 'px';
  selectionOverlay.style.height = height + 'px';
}

// Find all elements within the selected area
function findElementsInArea(rect) {
  let elements = [];
  const allElements = document.querySelectorAll('*');
  
  allElements.forEach(element => {
    const elementRect = element.getBoundingClientRect();
    
    // Check if element overlaps with selection area
    if (
      elementRect.left < rect.right &&
      elementRect.right > rect.left &&
      elementRect.top < rect.bottom &&
      elementRect.bottom > rect.top
    ) {
      // Check if element is at least 50% within the selection area
      const overlapArea = Math.max(0, Math.min(elementRect.right, rect.right) - Math.max(elementRect.left, rect.left)) *
                         Math.max(0, Math.min(elementRect.bottom, rect.bottom) - Math.max(elementRect.top, rect.top));
      const elementArea = elementRect.width * elementRect.height;
      
      if (elementArea > 0 && (overlapArea / elementArea) >= 0.5) {
        // Skip if element is already hidden or is a child of another selected element
        const isChild = elements.some(el => el.contains(element));
        if (!isChild) {
          // Remove children of this element from the list
          elements = elements.filter(el => !element.contains(el));
          elements.push(element);
        }
      }
    }
  });
  
  return elements;
}

// Show dialog to choose effect type for selected area
function showAreaSelectionDialog(elements) {
  // Keep selection overlay visible and ensure it stays in place
  if (selectionOverlay) {
    selectionOverlay.style.display = 'block';
    selectionOverlay.style.zIndex = '999998';
    selectionOverlay.style.pointerEvents = 'none'; // Don't interfere with dialog
  }
  
  // Calculate position near the selection area (top-right of selection)
  const overlayRect = selectionOverlay ? selectionOverlay.getBoundingClientRect() : null;
  let dialogTop = '50%';
  let dialogLeft = '50%';
  let transform = 'translate(-50%, -50%)';
  
  if (overlayRect) {
    // Position dialog near the selection, but ensure it's visible
    const dialogWidth = 380;
    const dialogHeight = 300;
    const padding = 20;
    
    // Try to position above the selection, aligned to the right
    if (overlayRect.top > dialogHeight + padding) {
      dialogTop = (overlayRect.top - dialogHeight / 2) + 'px';
      dialogLeft = Math.min(overlayRect.right - dialogWidth / 2, window.innerWidth - dialogWidth - padding) + 'px';
      transform = 'translate(-50%, -50%)';
    } else {
      // Position below the selection
      dialogTop = (overlayRect.bottom + dialogHeight / 2 + padding) + 'px';
      dialogLeft = Math.min(overlayRect.right - dialogWidth / 2, window.innerWidth - dialogWidth - padding) + 'px';
      transform = 'translate(-50%, -50%)';
    }
  }
  
  // Create dialog overlay (semi-transparent, but don't block interaction with selection)
  const dialog = document.createElement('div');
  dialog.id = 'element-hider-area-dialog';
  dialog.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    z-index: 999997;
    display: flex;
    align-items: flex-start;
    justify-content: flex-start;
    pointer-events: auto;
  `;
  
  const dialogContent = document.createElement('div');
  dialogContent.style.cssText = `
    position: fixed;
    top: ${dialogTop};
    left: ${dialogLeft};
    transform: ${transform};
    background: #ffffff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
    max-width: 380px;
    width: 90%;
    border: 1px solid #e2e8f0;
  `;
  
  dialogContent.innerHTML = `
    <h3 style="margin: 0 0 12px 0; font-size: 16px; color: #2d3748; font-weight: 600;">Select Effect Type</h3>
    <p style="margin: 0 0 16px 0; font-size: 13px; color: #718096; line-height: 1.5;">
      Found ${elements.length} element(s) in selected area. Choose an effect:
    </p>
    <div style="display: flex; flex-direction: column; gap: 8px; margin-bottom: 16px;">
      <button class="effect-btn" data-type="blur" style="padding: 10px 14px; background: #f0f4f8; color: #4a5568; border: 1px solid #cbd5e0; border-radius: 6px; cursor: pointer; font-weight: 500; font-size: 14px; transition: all 0.2s;">Blur</button>
      <button class="effect-btn" data-type="hide" style="padding: 10px 14px; background: #f7fafc; color: #4a5568; border: 1px solid #cbd5e0; border-radius: 6px; cursor: pointer; font-weight: 500; font-size: 14px; transition: all 0.2s;">Hide</button>
      <button class="effect-btn" data-type="asterisk" style="padding: 10px 14px; background: #fafafa; color: #4a5568; border: 1px solid #cbd5e0; border-radius: 6px; cursor: pointer; font-weight: 500; font-size: 14px; transition: all 0.2s;">Asterisk</button>
      <button class="effect-btn" data-type="redact" style="padding: 10px 14px; background: #edf2f7; color: #2d3748; border: 1px solid #cbd5e0; border-radius: 6px; cursor: pointer; font-weight: 500; font-size: 14px; transition: all 0.2s;">Redact</button>
    </div>
    <div style="display: flex; gap: 8px; margin-bottom: 16px;">
      <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
        <input type="checkbox" id="savePersistent" checked style="cursor: pointer;">
        <span style="font-size: 13px; color: #718096;">Save (Persistent)</span>
      </label>
    </div>
    <div style="display: flex; gap: 8px;">
      <button id="cancelDialog" style="flex: 1; padding: 10px 14px; background: #ffffff; color: #718096; border: 1px solid #e2e8f0; border-radius: 6px; cursor: pointer; font-weight: 500; font-size: 14px; transition: all 0.2s;">Cancel</button>
    </div>
  `;
  
  // Add hover effects with subtle color changes
  const style = document.createElement('style');
  style.textContent = `
    .effect-btn:hover {
      background: #e2e8f0 !important;
      border-color: #a0aec0 !important;
      transform: translateY(-1px);
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
    }
    .effect-btn:active {
      transform: translateY(0);
      background: #cbd5e0 !important;
    }
    .effect-btn[data-type="blur"]:hover {
      background: #e6f2ff !important;
      border-color: #90cdf4 !important;
      color: #2c5282 !important;
    }
    .effect-btn[data-type="hide"]:hover {
      background: #fed7d7 !important;
      border-color: #fc8181 !important;
      color: #c53030 !important;
    }
    .effect-btn[data-type="asterisk"]:hover {
      background: #fef5e7 !important;
      border-color: #f6e05e !important;
      color: #b7791f !important;
    }
    .effect-btn[data-type="redact"]:hover {
      background: #4a5568 !important;
      border-color: #2d3748 !important;
      color: #ffffff !important;
    }
    #cancelDialog:hover {
      background: #f7fafc !important;
      border-color: #cbd5e0 !important;
      color: #4a5568 !important;
    }
    #cancelDialog:active {
      background: #edf2f7 !important;
    }
  `;
  document.head.appendChild(style);
  
  dialog.appendChild(dialogContent);
  document.body.appendChild(dialog);
  
  // Handle effect button clicks
  dialogContent.querySelectorAll('.effect-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.getAttribute('data-type');
      const save = dialogContent.querySelector('#savePersistent').checked;
      
      applyAreaSelection(elements, type, save);
      
      // Clean up
      if (selectionOverlay) {
        selectionOverlay.style.display = 'none';
      }
      document.body.removeChild(dialog);
      document.head.removeChild(style);
      
      // Update badge
      updateBadgeCount();
      
      // Refresh page if persistent elements were saved
      if (save) {
        setTimeout(() => {
          window.location.reload();
        }, 500);
      }
    });
  });
  
  // Handle cancel
  dialogContent.querySelector('#cancelDialog').addEventListener('click', () => {
    if (selectionOverlay) {
      selectionOverlay.style.display = 'none';
    }
    document.body.removeChild(dialog);
    document.head.removeChild(style);
  });
  
  // Close on outside click
  dialog.addEventListener('click', (e) => {
    if (e.target === dialog) {
      if (selectionOverlay) {
        selectionOverlay.style.display = 'none';
      }
      document.body.removeChild(dialog);
      document.head.removeChild(style);
    }
  });
}

// Apply effect to elements in selected area
async function applyAreaSelection(elements, type, save) {
  const domain = window.location.hostname;
  const processedSelectors = new Set();
  
  for (const element of elements) {
    const selector = generateSelector(element);
    
    // Skip if already processed
    if (processedSelectors.has(selector)) continue;
    processedSelectors.add(selector);
    
    const elementInfo = {
      selector: selector,
      description: element.textContent?.substring(0, 50) || selector
    };
    
    // Apply effect
    await hideElement(elementInfo, save, type);
  }
  
  // Update badge
  updateBadgeCount();
}

