# Icons

Place your extension icons here:
- `icon16.png` (16x16 pixels)
- `icon48.png` (48x48 pixels)
- `icon128.png` (128x128 pixels)

You can create these icons using any image editor. The icons should represent the astrology/horoscope theme of the extension.

For a quick solution, you can:
1. Use an online icon generator
2. Create simple icons with a star or zodiac symbol
3. Use a placeholder image temporarily

The extension will work without icons, but Chrome will show a default icon.


