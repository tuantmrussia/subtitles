# Starcrossed Horoscope Chrome Extension

A beautiful Chrome extension that replaces your new tab page with an astrology and horoscope interface, similar to the Starcrossed app.

## Features

- **Zodiac Chart**: Calculate and display your personalized birth chart with planets, zodiac signs, and houses
- **Daily Horoscope**: Get daily horoscope readings for your zodiac sign
- **Compatibility Check**: Analyze relationship compatibility between two zodiac signs
- **Modern Design**: Clean, minimalist interface inspired by the Starcrossed app
- **Data Persistence**: Your birth data and preferences are saved locally

## Installation

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" (toggle in the top right)
3. Click "Load unpacked"
4. Select the folder containing this extension
5. The extension will now replace your new tab page

## Usage

### Zodiac Chart
1. Enter your birth date, time, and location
2. Click "Calculate Chart" to generate your personalized zodiac chart
3. View your planetary placements, signs, and houses

### Daily Horoscope
1. Select your zodiac sign from the dropdown
2. Click "Get Horoscope" to see your daily reading
3. Includes insights for love, career, and daily life

### Compatibility
1. Select your zodiac sign and your partner's sign
2. Click "Check Compatibility" to see your relationship analysis
3. View compatibility score and detailed insights

## Files Structure

```
ChoroscopeNewTab/
├── manifest.json       # Extension configuration
├── newtab.html         # New tab page HTML
├── styles.css          # Styling
├── app.js              # Main functionality
├── icons/              # Extension icons
└── README.md           # This file
```

## Notes

- This extension uses simplified astrology calculations. For professional astrological readings, consider integrating with an astrology API
- All data is stored locally in Chrome's storage
- The extension works offline for basic features

## Future Enhancements

- Integration with astrology APIs for accurate chart calculations
- More detailed compatibility analysis
- Birth chart visualization
- Multiple chart storage
- Export chart functionality

## License

This project is for personal use and educational purposes.


