// Tab switching functionality
document.addEventListener('DOMContentLoaded', () => {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-tab');

            // Remove active class from all buttons and contents
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            // Add active class to clicked button and corresponding content
            button.classList.add('active');
            document.getElementById(`${targetTab}-tab`).classList.add('active');
        });
    });

    // Load saved birth data
    loadSavedBirthData();

    // Load saved zodiac sign preference
    loadSavedZodiacSign();

    // Load saved soulmate chart data
    loadSavedSoulmateData();
});

// Zodiac signs data
const zodiacSigns = [
    'Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo',
    'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'
];

// Planet symbols mapping
const planetSymbols = {
    'Sun': '☉',
    'Moon': '☽',
    'Rising': '↑',
    'Mercury': '☿',
    'Venus': '♀',
    'Mars': '♂',
    'Jupiter': '♃',
    'Saturn': '♄',
    'Uranus': '♅',
    'Neptune': '♆',
    'Pluto': '♇'
};

// Calculate zodiac sign from date
function getZodiacSign(month, day) {
    const dates = [
        [3, 21, 'Aries'], [4, 20, 'Taurus'], [5, 21, 'Gemini'],
        [6, 21, 'Cancer'], [7, 23, 'Leo'], [8, 23, 'Virgo'],
        [9, 23, 'Libra'], [10, 23, 'Scorpio'], [11, 22, 'Sagittarius'],
        [12, 22, 'Capricorn'], [1, 20, 'Aquarius'], [2, 19, 'Pisces']
    ];

    for (let i = 0; i < dates.length; i++) {
        const [m, d, sign] = dates[i];
        if ((month === m && day >= d) || (month === m + 1 && day < dates[(i + 1) % 12][1])) {
            return sign;
        }
    }
    return 'Capricorn';
}

// Calculate house (simplified - based on rising sign and planet position)
function calculateHouse(planetIndex, risingSignIndex) {
    // Simplified house calculation
    const house = ((planetIndex + risingSignIndex) % 12) + 1;
    return house;
}

// Generate birth chart
function generateBirthChart(birthDate, birthTime, birthLocation) {
    const date = new Date(birthDate);
    const month = date.getMonth() + 1;
    const day = date.getDate();

    // Get sun sign
    const sunSign = getZodiacSign(month, day);
    const sunSignIndex = zodiacSigns.indexOf(sunSign);

    // Simplified chart generation (in a real app, you'd use an astrology API)
    const planets = [
        { name: 'Sun', sign: sunSign, house: 1 },
        { name: 'Moon', sign: zodiacSigns[(sunSignIndex + 1) % 12], house: 2 },
        { name: 'Rising', sign: zodiacSigns[(sunSignIndex + 3) % 12], house: 1 },
        { name: 'Mercury', sign: zodiacSigns[(sunSignIndex + 2) % 12], house: 3 },
        { name: 'Venus', sign: zodiacSigns[(sunSignIndex + 4) % 12], house: 5 },
        { name: 'Mars', sign: zodiacSigns[(sunSignIndex + 5) % 12], house: 6 },
        { name: 'Jupiter', sign: zodiacSigns[(sunSignIndex + 6) % 12], house: 9 },
        { name: 'Saturn', sign: zodiacSigns[(sunSignIndex + 7) % 12], house: 10 }
    ];

    return planets;
}

// Display chart in table
function displayChart(planets) {
    const chartBody = document.getElementById('chart-body');
    chartBody.innerHTML = '';

    planets.forEach(planet => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><span class="planet-icon">${planetSymbols[planet.name] || '•'}</span> ${planet.name}</td>
            <td>${planet.sign.toUpperCase()}</td>
            <td>House ${planet.house}</td>
        `;
        chartBody.appendChild(row);
    });
}

// Save birth data
function saveBirthData(birthDate, birthTime, birthLocation) {
    chrome.storage.local.set({
        birthDate,
        birthTime,
        birthLocation
    });
}

// Load saved birth data
function loadSavedBirthData() {
    chrome.storage.local.get(['birthDate', 'birthTime', 'birthLocation'], (result) => {
        if (result.birthDate) {
            document.getElementById('birth-date').value = result.birthDate;
        }
        if (result.birthTime) {
            document.getElementById('birth-time').value = result.birthTime;
        }
        if (result.birthLocation) {
            document.getElementById('birth-location').value = result.birthLocation;
        }
    });
}

// Load saved zodiac sign
function loadSavedZodiacSign() {
    chrome.storage.local.get(['zodiacSign'], (result) => {
        if (result.zodiacSign) {
            document.getElementById('zodiac-sign').value = result.zodiacSign;
        }
    });
}

// Calculate chart button
document.getElementById('calculate-chart')?.addEventListener('click', () => {
    const birthDate = document.getElementById('birth-date').value;
    const birthTime = document.getElementById('birth-time').value;
    const birthLocation = document.getElementById('birth-location').value;

    if (!birthDate) {
        alert('Please enter your birth date');
        return;
    }

    // Save birth data
    saveBirthData(birthDate, birthTime, birthLocation);

    // Generate and display chart
    const planets = generateBirthChart(birthDate, birthTime, birthLocation);
    displayChart(planets);
});

// Horoscope data (simplified - in production, use an API)
const horoscopeData = {
    aries: {
        today: "Today brings new opportunities for leadership. Trust your instincts and take bold action. Your energy is high, so channel it into productive endeavors.",
        love: "Passion is in the air. Express your feelings openly and honestly.",
        career: "A new project may present itself. Don't hesitate to take the lead."
    },
    taurus: {
        today: "Stability and comfort are your focus today. Take time to appreciate the beauty around you. Financial matters may require attention.",
        love: "Romance blossoms through patience and understanding.",
        career: "Steady progress is more valuable than rushing ahead."
    },
    gemini: {
        today: "Communication is key today. You'll find success through networking and expressing your ideas clearly. Stay curious and open-minded.",
        love: "Meaningful conversations deepen your connections.",
        career: "Collaboration leads to innovative solutions."
    },
    cancer: {
        today: "Emotional depth guides your day. Trust your intuition and nurture your relationships. Home and family matters take priority.",
        love: "Emotional intimacy creates stronger bonds.",
        career: "Your caring nature makes you a valuable team member."
    },
    leo: {
        today: "Your creative energy shines brightly today. Express yourself boldly and share your talents. Recognition may come your way.",
        love: "Your charisma attracts positive attention.",
        career: "Leadership opportunities arise naturally."
    },
    virgo: {
        today: "Attention to detail serves you well today. Organize your thoughts and tackle tasks methodically. Health matters deserve focus.",
        love: "Practical gestures show your care and devotion.",
        career: "Efficiency and precision lead to success."
    },
    libra: {
        today: "Balance and harmony are your goals today. Seek fairness in all interactions. Relationships require your diplomatic touch.",
        love: "Partnership flourishes through mutual respect.",
        career: "Collaboration brings the best results."
    },
    scorpio: {
        today: "Transformation is possible today. Embrace change and let go of what no longer serves you. Your intensity is a strength.",
        love: "Deep connections reveal hidden truths.",
        career: "Strategic thinking leads to breakthroughs."
    },
    sagittarius: {
        today: "Adventure calls to you today. Expand your horizons through learning and exploration. Optimism guides your path forward.",
        love: "Shared adventures strengthen your bond.",
        career: "New opportunities await in distant places."
    },
    capricorn: {
        today: "Ambition drives you forward today. Set clear goals and work steadily toward them. Your discipline pays off.",
        love: "Commitment deepens through shared goals.",
        career: "Recognition for your hard work is coming."
    },
    aquarius: {
        today: "Innovation and originality mark your day. Think outside the box and embrace your uniqueness. Social connections inspire you.",
        love: "Friendship forms the foundation of romance.",
        career: "Creative solutions set you apart."
    },
    pisces: {
        today: "Intuition and compassion guide you today. Trust your inner voice and help those in need. Artistic pursuits bring joy.",
        love: "Empathy creates deep emotional connections.",
        career: "Your creativity inspires others."
    }
};

// Get horoscope
document.getElementById('get-horoscope')?.addEventListener('click', () => {
    const sign = document.getElementById('zodiac-sign').value;
    const content = document.getElementById('horoscope-content');

    // Save zodiac sign preference
    chrome.storage.local.set({ zodiacSign: sign });

    content.innerHTML = '<div class="loading">Loading your horoscope</div>';

    // Simulate API call
    setTimeout(() => {
        const horoscope = horoscopeData[sign];
        if (horoscope) {
            content.innerHTML = `
                <h3 style="margin-bottom: 20px; color: #000;">Today's Reading for ${sign.charAt(0).toUpperCase() + sign.slice(1)}</h3>
                <p style="margin-bottom: 20px;"><strong>Daily:</strong> ${horoscope.today}</p>
                <p style="margin-bottom: 20px;"><strong>Love:</strong> ${horoscope.love}</p>
                <p><strong>Career:</strong> ${horoscope.career}</p>
            `;
        } else {
            content.innerHTML = '<p class="placeholder-text">Horoscope not available for this sign.</p>';
        }
    }, 500);
});

// Compatibility data - comprehensive matrix for all signs
function getCompatibility(sign1, sign2) {
    // Fire signs
    const fire = ['aries', 'leo', 'sagittarius'];
    // Earth signs
    const earth = ['taurus', 'virgo', 'capricorn'];
    // Air signs
    const air = ['gemini', 'libra', 'aquarius'];
    // Water signs
    const water = ['cancer', 'scorpio', 'pisces'];
    
    const sign1Element = fire.includes(sign1) ? 'fire' : 
                        earth.includes(sign1) ? 'earth' :
                        air.includes(sign1) ? 'air' : 'water';
    const sign2Element = fire.includes(sign2) ? 'fire' : 
                        earth.includes(sign2) ? 'earth' :
                        air.includes(sign2) ? 'air' : 'water';
    
    // Same element = high compatibility
    if (sign1Element === sign2Element) {
        return { score: 85, text: `Both ${sign1} and ${sign2} share the same ${sign1Element} element, creating natural harmony and understanding.` };
    }
    
    // Compatible elements (Fire-Air, Earth-Water)
    if ((sign1Element === 'fire' && sign2Element === 'air') || 
        (sign1Element === 'air' && sign2Element === 'fire') ||
        (sign1Element === 'earth' && sign2Element === 'water') ||
        (sign1Element === 'water' && sign2Element === 'earth')) {
        return { score: 80, text: `${sign1.charAt(0).toUpperCase() + sign1.slice(1)} and ${sign2.charAt(0).toUpperCase() + sign2.slice(1)} have compatible elements, creating a balanced and supportive relationship.` };
    }
    
    // Challenging combinations
    if ((sign1Element === 'fire' && sign2Element === 'water') ||
        (sign1Element === 'water' && sign2Element === 'fire') ||
        (sign1Element === 'earth' && sign2Element === 'air') ||
        (sign1Element === 'air' && sign2Element === 'earth')) {
        return { score: 60, text: `${sign1.charAt(0).toUpperCase() + sign1.slice(1)} and ${sign2.charAt(0).toUpperCase() + sign2.slice(1)} have different approaches, but with understanding and compromise, they can create a unique and complementary bond.` };
    }
    
    // Default
    return { score: 70, text: `${sign1.charAt(0).toUpperCase() + sign1.slice(1)} and ${sign2.charAt(0).toUpperCase() + sign2.slice(1)} have potential for a meaningful connection. Communication and mutual respect are key to success.` };
}

// Specific compatibility descriptions for better accuracy
const compatibilityDetails = {
    'aries-leo': { score: 90, text: "Aries and Leo share fire energy, creating a passionate and exciting partnership. Both love adventure and leadership." },
    'aries-sagittarius': { score: 95, text: "Aries and Sagittarius are a perfect match - both love adventure, freedom, and living life to the fullest." },
    'taurus-virgo': { score: 85, text: "Taurus and Virgo share earth energy, creating a stable and practical partnership built on trust and reliability." },
    'taurus-capricorn': { score: 90, text: "Taurus and Capricorn form a strong, grounded partnership with shared values and long-term goals." },
    'gemini-libra': { score: 90, text: "Gemini and Libra share air energy, creating an intellectual and harmonious partnership full of communication and social connection." },
    'gemini-aquarius': { score: 85, text: "Gemini and Aquarius share air energy, creating an innovative and freedom-loving partnership." },
    'cancer-scorpio': { score: 90, text: "Cancer and Scorpio share water energy, creating an intense and deeply emotional connection." },
    'cancer-pisces': { score: 85, text: "Cancer and Pisces share water energy, creating a nurturing and empathetic partnership." },
    'leo-sagittarius': { score: 90, text: "Leo and Sagittarius share fire energy, creating an enthusiastic and adventurous partnership." },
    'virgo-capricorn': { score: 85, text: "Virgo and Capricorn share earth energy, creating a practical and goal-oriented partnership." },
    'libra-aquarius': { score: 90, text: "Libra and Aquarius share air energy, creating an intellectual and socially harmonious partnership." },
    'scorpio-pisces': { score: 85, text: "Scorpio and Pisces share water energy, creating a deep and intuitive emotional connection." }
};

function getDetailedCompatibility(sign1, sign2) {
    const key1 = `${sign1}-${sign2}`;
    const key2 = `${sign2}-${sign1}`;
    
    if (compatibilityDetails[key1]) return compatibilityDetails[key1];
    if (compatibilityDetails[key2]) return compatibilityDetails[key2];
    
    return getCompatibility(sign1, sign2);
}

// Check compatibility
document.getElementById('check-compatibility')?.addEventListener('click', () => {
    const sign1 = document.getElementById('sign1').value;
    const sign2 = document.getElementById('sign2').value;
    const result = document.getElementById('compatibility-result');

    result.innerHTML = '<div class="loading">Analyzing compatibility</div>';

    setTimeout(() => {
        const compatibility = getDetailedCompatibility(sign1, sign2);

        const sign1Name = sign1.charAt(0).toUpperCase() + sign1.slice(1);
        const sign2Name = sign2.charAt(0).toUpperCase() + sign2.slice(1);

        result.innerHTML = `
            <h3 style="margin-bottom: 20px; color: #000;">${sign1Name} & ${sign2Name}</h3>
            <div class="compatibility-score">${compatibility.score}%</div>
            <div class="compatibility-details">
                <p>${compatibility.text}</p>
            </div>
        `;
    }, 500);
});

// Auto-load horoscope if sign is saved
chrome.storage.local.get(['zodiacSign'], (result) => {
    if (result.zodiacSign) {
        // Auto-load when horoscope tab is opened
        const horoscopeTab = document.getElementById('horoscope-tab');
        const observer = new MutationObserver(() => {
            if (horoscopeTab.classList.contains('active')) {
                const sign = document.getElementById('zodiac-sign').value;
                if (sign) {
                    document.getElementById('get-horoscope').click();
                }
            }
        });
        observer.observe(horoscopeTab, { attributes: true, attributeFilter: ['class'] });
    }
});

// Generate soulmate charts for comparison
function generateSoulmateCharts(person1Data, person2Data) {
    const person1Chart = generateBirthChart(
        person1Data.birthDate,
        person1Data.birthTime,
        person1Data.birthLocation
    );
    const person2Chart = generateBirthChart(
        person2Data.birthDate,
        person2Data.birthTime,
        person2Data.birthLocation
    );
    return { person1Chart, person2Chart };
}

// Display soulmate comparison chart
function displaySoulmateComparison(person1Chart, person2Chart) {
    const chartBody = document.getElementById('soulmate-chart-body');
    chartBody.innerHTML = '';

    // Ensure both charts have the same planets in the same order
    const planetOrder = ['Sun', 'Moon', 'Rising', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn'];
    
    planetOrder.forEach(planetName => {
        const person1Planet = person1Chart.find(p => p.name === planetName);
        const person2Planet = person2Chart.find(p => p.name === planetName);

        if (person1Planet && person2Planet) {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><span class="planet-icon">${planetSymbols[planetName] || '•'}</span> ${planetName}</td>
                <td>${person1Planet.sign.toUpperCase()}</td>
                <td>${person2Planet.sign.toUpperCase()}</td>
            `;
            chartBody.appendChild(row);
        }
    });
}

// Save soulmate chart data
function saveSoulmateData(person1Data, person2Data) {
    chrome.storage.local.set({
        person1BirthDate: person1Data.birthDate,
        person1BirthTime: person1Data.birthTime,
        person1BirthLocation: person1Data.birthLocation,
        person2BirthDate: person2Data.birthDate,
        person2BirthTime: person2Data.birthTime,
        person2BirthLocation: person2Data.birthLocation
    });
}

// Load saved soulmate chart data
function loadSavedSoulmateData() {
    chrome.storage.local.get([
        'person1BirthDate', 'person1BirthTime', 'person1BirthLocation',
        'person2BirthDate', 'person2BirthTime', 'person2BirthLocation'
    ], (result) => {
        if (result.person1BirthDate) {
            document.getElementById('person1-birth-date').value = result.person1BirthDate;
        }
        if (result.person1BirthTime) {
            document.getElementById('person1-birth-time').value = result.person1BirthTime;
        }
        if (result.person1BirthLocation) {
            document.getElementById('person1-birth-location').value = result.person1BirthLocation;
        }
        if (result.person2BirthDate) {
            document.getElementById('person2-birth-date').value = result.person2BirthDate;
        }
        if (result.person2BirthTime) {
            document.getElementById('person2-birth-time').value = result.person2BirthTime;
        }
        if (result.person2BirthLocation) {
            document.getElementById('person2-birth-location').value = result.person2BirthLocation;
        }
    });
}

// Calculate soulmate charts button
document.getElementById('calculate-soulmate-charts')?.addEventListener('click', () => {
    const person1Data = {
        birthDate: document.getElementById('person1-birth-date').value,
        birthTime: document.getElementById('person1-birth-time').value,
        birthLocation: document.getElementById('person1-birth-location').value
    };

    const person2Data = {
        birthDate: document.getElementById('person2-birth-date').value,
        birthTime: document.getElementById('person2-birth-time').value,
        birthLocation: document.getElementById('person2-birth-location').value
    };

    if (!person1Data.birthDate || !person2Data.birthDate) {
        alert('Please enter birth dates for both people');
        return;
    }

    // Save soulmate data
    saveSoulmateData(person1Data, person2Data);

    // Generate and display comparison charts
    const { person1Chart, person2Chart } = generateSoulmateCharts(person1Data, person2Data);
    displaySoulmateComparison(person1Chart, person2Chart);
});

