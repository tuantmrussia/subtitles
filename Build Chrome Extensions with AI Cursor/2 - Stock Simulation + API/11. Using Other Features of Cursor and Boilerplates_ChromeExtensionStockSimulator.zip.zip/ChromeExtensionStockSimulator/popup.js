// Popup script for Stock Simulator extension

// Default starting balance
const DEFAULT_BALANCE = 100000;

// Global API service instance
let apiService = null;
let currentStockData = null;
let currentTimeRange = '6M';
let currentHistoricalData = null; // Store historical OHLCV data
let priceChart = null; // Chart.js instance
let equityChart = null; // Equity curve chart instance
let currentProfile = 'default'; // Current active profile

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
  await initializeProfiles();
  await initializePortfolio();
  await initializeAPIService();
  await initializeAchievements();
  await initializeLearning();
  setupEventListeners();
  loadPortfolioView();
});

// Initialize API service
async function initializeAPIService() {
  const result = await chrome.storage.local.get(['apiKey', 'apiProvider']);
  const apiKey = result.apiKey;
  const apiProvider = result.apiProvider || 'alphavantage';
  
  if (apiKey) {
    apiService = new StockAPIService(apiProvider, apiKey);
  }
  
  // Load settings tab values
  loadSettingsTab();
}

// Setup event listeners
function setupEventListeners() {
  // Tab switching
  document.querySelectorAll('.tab-button').forEach(button => {
    button.addEventListener('click', (e) => {
      const tab = e.target.dataset.tab;
      switchTab(tab);
    });
  });

  // Search functionality
  document.getElementById('searchButton').addEventListener('click', handleSearch);
  const stockSearchInput = document.getElementById('stockSearch');
  stockSearchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      const selectedItem = document.querySelector('.autocomplete-item.selected');
      if (selectedItem) {
        const symbol = selectedItem.dataset.symbol;
        stockSearchInput.value = symbol;
        hideAutocomplete();
        handleSearch();
      } else {
        handleSearch();
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      navigateAutocomplete(1);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      navigateAutocomplete(-1);
    } else if (e.key === 'Escape') {
      hideAutocomplete();
    }
  });

  // Autocomplete on input
  let autocompleteTimeout = null;
  stockSearchInput.addEventListener('input', (e) => {
    const query = e.target.value.trim();
    
    // Clear previous timeout
    if (autocompleteTimeout) {
      clearTimeout(autocompleteTimeout);
    }

    // Hide dropdown if query is too short
    if (query.length < 2) {
      hideAutocomplete();
      return;
    }

    // Debounce API calls
    autocompleteTimeout = setTimeout(() => {
      performAutocompleteSearch(query);
    }, 300);
  });

  // Hide autocomplete when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.search-input-wrapper')) {
      hideAutocomplete();
    }
  });

  // Time range selector
  document.querySelectorAll('.time-range-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.time-range-btn').forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');
      const range = e.target.dataset.range;
      if (window.currentStockSymbol) {
        loadStockDetails(window.currentStockSymbol, range);
      }
    });
  });

  // Share quantity input handler
  const shareQuantityInput = document.getElementById('shareQuantityInput');
  if (shareQuantityInput) {
    shareQuantityInput.addEventListener('input', updateTradeTotal);
  }

  // Time range buttons
  document.querySelectorAll('.time-range-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const range = e.target.dataset.range;
      selectTimeRange(range);
    });
  });

  // Share quantity input - update total in real-time
  document.getElementById('shareQuantityInput').addEventListener('input', updateTradeTotal);

  // Buy/Sell buttons
  document.getElementById('buyButton').addEventListener('click', handleBuy);
  document.getElementById('sellButton').addEventListener('click', handleSell);

  // Options button
  document.getElementById('optionsButton').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  // Settings tab event listeners
  document.getElementById('saveApiKeyBtn').addEventListener('click', saveApiKeyFromPopup);
  document.getElementById('toggleApiKeyVisibility').addEventListener('click', toggleApiKeyVisibility);
  document.getElementById('openOptionsPage').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });
  
  // Update help text when provider changes in settings
  document.getElementById('popupApiProvider').addEventListener('change', updateSettingsHelpText);

  // Analytics: Compare index checkbox
  const compareIndexCheckbox = document.getElementById('compareIndex');
  if (compareIndexCheckbox) {
    compareIndexCheckbox.addEventListener('change', () => {
      loadAnalyticsView();
    });
  }

  // Profile selector
  const profileSelector = document.getElementById('profileSelector');
  if (profileSelector) {
    profileSelector.addEventListener('change', async (e) => {
      await switchProfile(e.target.value);
    });
  }

  // Manage profiles button
  const manageProfilesBtn = document.getElementById('manageProfilesBtn');
  if (manageProfilesBtn) {
    manageProfilesBtn.addEventListener('click', () => {
      openProfileModal();
    });
  }

  // Profile modal close
  const closeProfileModalBtn = document.getElementById('closeProfileModal');
  if (closeProfileModalBtn) {
    closeProfileModalBtn.addEventListener('click', () => {
      closeProfileModal();
    });
  }

  // Create profile button
  const createProfileBtn = document.getElementById('createProfileBtn');
  if (createProfileBtn) {
    createProfileBtn.addEventListener('click', async () => {
      await createProfile();
    });
  }

  // Create profile on Enter key
  const newProfileNameInput = document.getElementById('newProfileName');
  if (newProfileNameInput) {
    newProfileNameInput.addEventListener('keypress', async (e) => {
      if (e.key === 'Enter') {
        await createProfile();
      }
    });
  }

  // Learning tabs
  document.querySelectorAll('.learning-tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const tab = e.target.dataset.learningTab;
      switchLearningTab(tab);
    });
  });

  // Quiz controls
  const startQuizBtn = document.getElementById('startQuizBtn');
  if (startQuizBtn) {
    startQuizBtn.addEventListener('click', startQuiz);
  }

  const quizNextBtn = document.getElementById('quizNextBtn');
  if (quizNextBtn) {
    quizNextBtn.addEventListener('click', nextQuizQuestion);
  }

  const quizFinishBtn = document.getElementById('quizFinishBtn');
  if (quizFinishBtn) {
    quizFinishBtn.addEventListener('click', finishQuiz);
  }

  const quizRestartBtn = document.getElementById('quizRestartBtn');
  if (quizRestartBtn) {
    quizRestartBtn.addEventListener('click', resetQuiz);
  }

  const tipsCategorySelect = document.getElementById('tipsCategory');
  if (tipsCategorySelect) {
    tipsCategorySelect.addEventListener('change', () => {
      loadLearningTips();
    });
  }
}

// Tab switching
function switchTab(tabName) {
  // Update tab buttons
  document.querySelectorAll('.tab-button').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

  // Update tab content
  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.add('hidden');
  });
  document.getElementById(`${tabName}Tab`).classList.remove('hidden');

  // Load appropriate view
  if (tabName === 'portfolio') {
    loadPortfolioView();
  } else if (tabName === 'search') {
    // Clear search results when switching to search tab
    document.getElementById('searchResults').innerHTML = '';
    document.getElementById('stockDetailsSection').style.display = 'none';
    document.getElementById('timeRangeSelector').style.display = 'none';
    document.getElementById('chartContainer').style.display = 'none';
    hideAutocomplete();
  } else if (tabName === 'analytics') {
    hideAutocomplete();
    loadAnalyticsView();
  } else if (tabName === 'achievements') {
    loadAchievementsView();
  } else if (tabName === 'learn') {
    loadLearningView();
  } else if (tabName === 'settings') {
    loadSettingsTab();
  }
}

// ==================== PROFILE MANAGEMENT ====================

// Initialize profiles system
async function initializeProfiles() {
  const result = await chrome.storage.local.get(['currentProfile', 'profiles']);
  
  // Migrate old data to default profile if needed
  if (!result.profiles) {
    const oldData = await chrome.storage.local.get(['portfolio', 'balance', 'initialBalance', 'transactions', 'portfolioHistory']);
    
    // Check if there's old data to migrate
    if (oldData.portfolio !== undefined || oldData.balance !== undefined) {
      const defaultProfileData = {
        portfolio: oldData.portfolio || [],
        balance: oldData.balance || DEFAULT_BALANCE,
        initialBalance: oldData.initialBalance || DEFAULT_BALANCE,
        transactions: oldData.transactions || [],
        portfolioHistory: oldData.portfolioHistory || [],
        createdAt: Date.now()
      };
      
      await chrome.storage.local.set({
        profiles: { default: defaultProfileData },
        currentProfile: 'default'
      });
      
      // Clear old data
      await chrome.storage.local.remove(['portfolio', 'balance', 'initialBalance', 'transactions', 'portfolioHistory']);
    } else {
      // Initialize empty profiles structure
      await chrome.storage.local.set({
        profiles: {},
        currentProfile: 'default'
      });
    }
  }
  
  // Ensure currentProfile is set
  currentProfile = result.currentProfile || 'default';
  
  // Create default profile if it doesn't exist
  const profiles = result.profiles || {};
  if (!profiles.default) {
    profiles.default = {
      portfolio: [],
      balance: DEFAULT_BALANCE,
      initialBalance: DEFAULT_BALANCE,
      transactions: [],
      portfolioHistory: [],
      createdAt: Date.now()
    };
    await chrome.storage.local.set({ profiles: profiles });
  }
  
  // Update profile selector
  updateProfileSelector();
}

// Get profile storage key
function getProfileKey(key) {
  return `profile_${currentProfile}_${key}`;
}

// Profile-aware storage helpers
async function getProfileData(keys) {
  const profileKeys = Array.isArray(keys) ? keys.map(k => getProfileKey(k)) : [getProfileKey(keys)];
  const result = await chrome.storage.local.get(profileKeys);
  
  // Extract values and remove profile prefix
  const extracted = {};
  Object.keys(result).forEach(key => {
    if (key.startsWith(`profile_${currentProfile}_`)) {
      const originalKey = key.replace(`profile_${currentProfile}_`, '');
      extracted[originalKey] = result[key];
    }
  });
  
  return Array.isArray(keys) ? extracted : extracted[keys];
}

async function setProfileData(data) {
  const profileData = {};
  Object.keys(data).forEach(key => {
    profileData[getProfileKey(key)] = data[key];
  });
  await chrome.storage.local.set(profileData);
}

// Update profile selector dropdown
async function updateProfileSelector() {
  const result = await chrome.storage.local.get(['profiles', 'currentProfile']);
  const profiles = result.profiles || {};
  const selector = document.getElementById('profileSelector');
  
  if (!selector) return;
  
  selector.innerHTML = '';
  Object.keys(profiles).forEach(profileName => {
    const option = document.createElement('option');
    option.value = profileName;
    option.textContent = profileName === 'default' ? 'Default Profile' : profileName;
    if (profileName === currentProfile) {
      option.selected = true;
    }
    selector.appendChild(option);
  });
}

// Switch to a different profile
async function switchProfile(profileName) {
  if (!profileName || profileName === currentProfile) return;
  
  const result = await chrome.storage.local.get(['profiles']);
  const profiles = result.profiles || {};
  
  if (!profiles[profileName]) {
    alert('Profile not found');
    return;
  }
  
  currentProfile = profileName;
  await chrome.storage.local.set({ currentProfile: profileName });
  
  // Reload views
  await initializePortfolio();
  loadPortfolioView();
  updateProfileSelector();
}

// Create a new profile
async function createProfile() {
  const nameInput = document.getElementById('newProfileName');
  const profileName = nameInput.value.trim();
  
  if (!profileName) {
    alert('Please enter a profile name');
    return;
  }
  
  // Validate name (alphanumeric, spaces, hyphens, underscores)
  if (!/^[a-zA-Z0-9 _-]+$/.test(profileName)) {
    alert('Profile name can only contain letters, numbers, spaces, hyphens, and underscores');
    return;
  }
  
  const result = await chrome.storage.local.get(['profiles']);
  const profiles = result.profiles || {};
  
  if (profiles[profileName]) {
    alert('A profile with this name already exists');
    return;
  }
  
  // Create new profile with default values
  profiles[profileName] = {
    portfolio: [],
    balance: DEFAULT_BALANCE,
    initialBalance: DEFAULT_BALANCE,
    transactions: [],
    portfolioHistory: [],
    createdAt: Date.now()
  };
  
  await chrome.storage.local.set({ profiles: profiles });
  
  // Clear input and refresh list
  nameInput.value = '';
  updateProfilesList();
  updateProfileSelector();
}

// Delete a profile
async function deleteProfile(profileName) {
  if (profileName === 'default') {
    alert('Cannot delete the default profile');
    return;
  }
  
  if (!confirm(`Are you sure you want to delete the profile "${profileName}"? This cannot be undone.`)) {
    return;
  }
  
  const result = await chrome.storage.local.get(['profiles', 'currentProfile']);
  const profiles = result.profiles || {};
  
  delete profiles[profileName];
  
  await chrome.storage.local.set({ profiles: profiles });
  
  // If deleted profile was active, switch to default
  if (result.currentProfile === profileName) {
    await switchProfile('default');
  }
  
  updateProfilesList();
  updateProfileSelector();
}

// Update profiles list in modal
async function updateProfilesList() {
  const result = await chrome.storage.local.get(['profiles', 'currentProfile']);
  const profiles = result.profiles || {};
  const listContainer = document.getElementById('profilesList');
  
  if (!listContainer) return;
  
  if (Object.keys(profiles).length === 0) {
    listContainer.innerHTML = '<div class="empty-state">No profiles</div>';
    return;
  }
  
  listContainer.innerHTML = Object.keys(profiles).map(profileName => {
    const profile = profiles[profileName];
    const isActive = profileName === currentProfile;
    const holdingsCount = profile.portfolio ? profile.portfolio.length : 0;
    const isDefault = profileName === 'default';
    
    return `
      <div class="profile-item ${isActive ? 'active' : ''}">
        <div class="profile-info">
          <div class="profile-name">${profileName === 'default' ? 'Default Profile' : profileName} ${isActive ? '(Active)' : ''}</div>
          <div class="profile-details">
            ${holdingsCount} holdings • $${(profile.balance || DEFAULT_BALANCE).toFixed(2)} cash
          </div>
        </div>
        <div class="profile-actions">
          ${!isDefault ? `<button class="btn-delete-profile" onclick="deleteProfileFromUI('${profileName}')">Delete</button>` : ''}
        </div>
      </div>
    `;
  }).join('');
}

// Open profile management modal
function openProfileModal() {
  const modal = document.getElementById('profileModal');
  if (modal) {
    modal.classList.remove('hidden');
    updateProfilesList();
  }
}

// Close profile management modal
function closeProfileModal() {
  const modal = document.getElementById('profileModal');
  if (modal) {
    modal.classList.add('hidden');
  }
}

// Delete profile from UI (called from onclick)
window.deleteProfileFromUI = async function(profileName) {
  await deleteProfile(profileName);
};

// Initialize portfolio data (profile-aware)
async function initializePortfolio() {
  const profileData = await getProfileData(['portfolio', 'balance', 'initialBalance', 'transactions', 'portfolioHistory']);
  
  // Initialize if first time for this profile
  if (profileData.portfolio === undefined) {
    await setProfileData({
      portfolio: [],
      balance: DEFAULT_BALANCE,
      initialBalance: DEFAULT_BALANCE,
      transactions: [],
      portfolioHistory: []
    });
  }
  
  // Migrate old data: ensure arrays exist
  if (!profileData.transactions) {
    await setProfileData({ transactions: [] });
  }
  
  if (!profileData.portfolioHistory) {
    await setProfileData({ portfolioHistory: [] });
  }
  
  // Ensure initialBalance is set
  if (!profileData.initialBalance) {
    await setProfileData({
      initialBalance: profileData.balance || DEFAULT_BALANCE
    });
  }
}

// Load portfolio view with current prices
async function loadPortfolioView() {
  const result = await getProfileData(['portfolio', 'balance', 'initialBalance', 'transactions']);
  const portfolio = result.portfolio || [];
  const balance = result.balance || DEFAULT_BALANCE;
  const initialBalance = result.initialBalance || DEFAULT_BALANCE;

  // Update portfolio list
  const portfolioList = document.getElementById('portfolioList');
  
  if (portfolio.length === 0) {
    portfolioList.innerHTML = '<div class="empty-state">No stocks in portfolio yet</div>';
    // Still update portfolio value with cash only
    const changeElement = document.getElementById('portfolioChange');
    const portfolioChange = balance - initialBalance;
    const portfolioChangePercent = ((portfolioChange / initialBalance) * 100).toFixed(2);
    document.getElementById('portfolioValue').textContent = `$${balance.toFixed(2)}`;
    changeElement.textContent = `${portfolioChange >= 0 ? '+' : ''}$${portfolioChange.toFixed(2)} (${portfolioChangePercent}%)`;
    changeElement.className = `balance-change ${portfolioChange >= 0 ? 'positive' : 'negative'}`;
    return;
  }

  // Show loading state
  portfolioList.innerHTML = '<div class="empty-state">Loading current prices...</div>';

  try {
    // Fetch current prices for all holdings
    if (!apiService) {
      await initializeAPIService();
    }

    if (!apiService) {
      // If no API service, use stored prices
      renderPortfolioItems(portfolio, balance, initialBalance);
      return;
    }

    // Fetch quotes for all symbols in parallel
    const symbols = portfolio.map(s => s.symbol);
    const quotes = await apiService.fetchQuotes(symbols);
    
    // Create a map of symbol to quote
    const quoteMap = {};
    quotes.forEach(quote => {
      quoteMap[quote.symbol] = quote;
    });

    // Update portfolio with current prices
    let portfolioValue = balance;
    let totalUnrealizedPL = 0;

    const updatedPortfolio = portfolio.map((stock, index) => {
      const quote = quoteMap[stock.symbol];
      const currentPrice = quote ? quote.price : stock.currentPrice;
      const change = currentPrice - stock.purchasePrice;
      const changePercent = ((change / stock.purchasePrice) * 100).toFixed(2);
      const totalValue = currentPrice * stock.shares;
      const unrealizedPL = change * stock.shares;
      
      totalUnrealizedPL += unrealizedPL;
      portfolioValue += totalValue;

      return {
        ...stock,
        currentPrice: currentPrice,
        totalValue: totalValue,
        unrealizedPL: unrealizedPL,
        changePercent: changePercent
      };
    });

    // Update stored current prices
    portfolio.forEach((stock, index) => {
      const quote = quoteMap[stock.symbol];
      if (quote) {
        stock.currentPrice = quote.price;
      }
    });
    await setProfileData({ portfolio: portfolio });

    // Render portfolio items
    renderPortfolioItems(updatedPortfolio, balance, initialBalance, portfolioValue, totalUnrealizedPL);

  } catch (error) {
    console.error('Error fetching current prices:', error);
    // Fallback to stored prices
    renderPortfolioItems(portfolio, balance, initialBalance);
  }
}

// Render portfolio items in the UI
function renderPortfolioItems(portfolio, balance, initialBalance, portfolioValue = null, totalUnrealizedPL = null) {
  const portfolioList = document.getElementById('portfolioList');
  
  // Calculate portfolio value if not provided
  if (portfolioValue === null) {
    portfolioValue = balance;
    portfolio.forEach(stock => {
      portfolioValue += (stock.currentPrice || stock.purchasePrice) * stock.shares;
    });
  }

  if (totalUnrealizedPL === null) {
    totalUnrealizedPL = 0;
    portfolio.forEach(stock => {
      const currentPrice = stock.currentPrice || stock.purchasePrice;
      const change = currentPrice - stock.purchasePrice;
      totalUnrealizedPL += change * stock.shares;
    });
  }

  // Render portfolio items
  portfolioList.innerHTML = `
    <div class="cash-balance-display">
      <div class="cash-label">Cash Balance</div>
      <div class="cash-amount">$${balance.toFixed(2)}</div>
    </div>
    ${portfolio.map((stock, index) => {
      const currentPrice = stock.currentPrice || stock.purchasePrice;
      const change = currentPrice - stock.purchasePrice;
      const changePercent = stock.changePercent || ((change / stock.purchasePrice) * 100).toFixed(2);
      const totalValue = stock.totalValue || (currentPrice * stock.shares);
      const unrealizedPL = stock.unrealizedPL || (change * stock.shares);
      
      return `
        <div class="stock-item">
          <div class="stock-item-content">
            <div class="stock-info">
              <div class="stock-symbol">${stock.symbol}</div>
              <div class="stock-details">
                <span>${stock.shares} shares</span>
                <span class="separator">•</span>
                <span>Avg: $${stock.purchasePrice.toFixed(2)}</span>
                <span class="separator">•</span>
                <span>Current: $${currentPrice.toFixed(2)}</span>
              </div>
            </div>
            <div class="stock-value">
              <div class="stock-price">$${totalValue.toFixed(2)}</div>
              <div class="stock-change ${change >= 0 ? 'positive' : 'negative'}">
                ${change >= 0 ? '+' : ''}$${unrealizedPL.toFixed(2)} (${change >= 0 ? '+' : ''}${changePercent}%)
              </div>
            </div>
          </div>
          <div class="stock-item-actions">
            <button class="btn-sell-small" onclick="sellStockFromPortfolio('${stock.symbol}', ${index})">Sell</button>
          </div>
        </div>
      `;
    }).join('')}
  `;

  // Update portfolio value display
  const portfolioChange = portfolioValue - initialBalance;
  const portfolioChangePercent = ((portfolioChange / initialBalance) * 100).toFixed(2);

  document.getElementById('portfolioValue').textContent = `$${portfolioValue.toFixed(2)}`;
  const changeElement = document.getElementById('portfolioChange');
  changeElement.textContent = `${portfolioChange >= 0 ? '+' : ''}$${portfolioChange.toFixed(2)} (${portfolioChangePercent}%)`;
  changeElement.className = `balance-change ${portfolioChange >= 0 ? 'positive' : 'negative'}`;
}

// Sell stock from portfolio
window.sellStockFromPortfolio = async function(symbol, index) {
  const result = await getProfileData(['portfolio', 'balance', 'transactions']);
  const portfolio = result.portfolio || [];
  const stock = portfolio[index];
  
  if (!stock) return;

  // Fetch current price for accurate sale
  let currentPrice = stock.currentPrice || stock.purchasePrice;
  try {
    if (apiService) {
      const quote = await apiService.fetchQuote(symbol);
      if (quote) {
        currentPrice = quote.price;
        stock.currentPrice = quote.price;
      }
    }
  } catch (error) {
    console.error('Error fetching current price:', error);
  }

  const sharesToSell = prompt(`How many shares of ${symbol} do you want to sell? (You own ${stock.shares} shares)`);
  const quantity = parseInt(sharesToSell);

  if (!quantity || quantity < 1 || quantity > stock.shares) {
    alert('Invalid number of shares');
    return;
  }

  // Calculate sale value at current price
  const saleValue = currentPrice * quantity;
  const newBalance = (result.balance || DEFAULT_BALANCE) + saleValue;

  // Record transaction
  const transactions = result.transactions || [];
  const realizedPL = (currentPrice - stock.purchasePrice) * quantity;
  transactions.push({
    type: 'SELL',
    symbol: symbol,
    name: stock.name || symbol,
    quantity: quantity,
    price: currentPrice,
    totalValue: saleValue,
    purchasePrice: stock.purchasePrice,
    realizedPL: realizedPL,
    date: new Date().toISOString(),
    timestamp: Date.now()
  });

  // Update portfolio
  if (quantity === stock.shares) {
    // Remove stock completely
    portfolio.splice(index, 1);
  } else {
    // Reduce shares
    stock.shares -= quantity;
  }

  // Save all data to chrome.storage.local immediately using profile-aware storage
  await setProfileData({
    portfolio: portfolio,
    balance: newBalance,
    transactions: transactions
  });

  // Request service worker to record snapshot
  chrome.runtime.sendMessage({ action: 'recordSnapshot' });

  // Check for achievements after trade
  const newAchievements = await checkAchievements();
  if (newAchievements.length > 0) {
    showAchievementNotification(newAchievements);
  }

  loadPortfolioView();
  const plText = realizedPL >= 0 ? `Profit: $${realizedPL.toFixed(2)}` : `Loss: $${Math.abs(realizedPL).toFixed(2)}`;
  alert(`Successfully sold ${quantity} share(s) of ${symbol} for $${saleValue.toFixed(2)}! ${plText}`);
};

// Autocomplete search
let autocompleteResults = [];
let selectedAutocompleteIndex = -1;

async function performAutocompleteSearch(query) {
  if (!apiService) {
    await initializeAPIService();
  }

  if (!apiService) {
    return;
  }

  try {
    const results = await apiService.searchStocks(query);
    autocompleteResults = results;
    selectedAutocompleteIndex = -1;
    displayAutocompleteResults(results);
  } catch (error) {
    console.error('Autocomplete error:', error);
    hideAutocomplete();
  }
}

function displayAutocompleteResults(results) {
  const dropdown = document.getElementById('autocompleteDropdown');
  
  if (!results || results.length === 0) {
    dropdown.innerHTML = '<div class="autocomplete-item">No results found</div>';
    dropdown.classList.remove('hidden');
    return;
  }

  dropdown.innerHTML = results.map((result, index) => {
    const exchange = result.exchangeShortName || result.stockExchange || result.region || '';
    return `
      <div class="autocomplete-item" data-symbol="${result.symbol}" data-index="${index}">
        <div class="autocomplete-item-symbol">${result.symbol}</div>
        <div class="autocomplete-item-name">${result.name}</div>
        ${exchange ? `<div class="autocomplete-item-exchange">${exchange}</div>` : ''}
      </div>
    `;
  }).join('');

  // Add click handlers
  dropdown.querySelectorAll('.autocomplete-item').forEach(item => {
    item.addEventListener('click', () => {
      const symbol = item.dataset.symbol;
      document.getElementById('stockSearch').value = symbol;
      hideAutocomplete();
      handleSearch();
    });
  });

  dropdown.classList.remove('hidden');
}

function hideAutocomplete() {
  const dropdown = document.getElementById('autocompleteDropdown');
  dropdown.classList.add('hidden');
  selectedAutocompleteIndex = -1;
}

function navigateAutocomplete(direction) {
  const items = document.querySelectorAll('.autocomplete-item');
  if (items.length === 0) return;

  // Remove previous selection
  items.forEach(item => item.classList.remove('selected'));

  // Update index
  selectedAutocompleteIndex += direction;
  if (selectedAutocompleteIndex < 0) {
    selectedAutocompleteIndex = items.length - 1;
  } else if (selectedAutocompleteIndex >= items.length) {
    selectedAutocompleteIndex = 0;
  }

  // Add selection
  const selectedItem = items[selectedAutocompleteIndex];
  if (selectedItem) {
    selectedItem.classList.add('selected');
    selectedItem.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }
}

// Handle stock search
async function handleSearch() {
  const symbol = document.getElementById('stockSearch').value.trim().toUpperCase();
  
  // Hide autocomplete dropdown
  hideAutocomplete();
  
  if (!symbol) {
    alert('Please enter a stock symbol');
    return;
  }

  const searchResults = document.getElementById('searchResults');
  searchResults.innerHTML = '<div class="empty-state">Searching...</div>';
  document.getElementById('stockDetailsSection').style.display = 'none';
  document.getElementById('timeRangeSelector').style.display = 'none';
  document.getElementById('chartContainer').style.display = 'none';

  try {
    // Check if API key is set
    const result = await chrome.storage.local.get(['apiKey', 'apiProvider']);
    const apiKey = result.apiKey;

    if (!apiKey) {
      searchResults.innerHTML = `
        <div class="empty-state">
          <p>API key not configured.</p>
          <p>Please set your API key in Settings.</p>
        </div>
      `;
      return;
    }

    // Initialize API service if needed
    if (!apiService) {
      const apiProvider = result.apiProvider || 'alphavantage';
      apiService = new StockAPIService(apiProvider, apiKey);
    }

    // Fetch stock data
    window.currentStockSymbol = symbol;
    const stockData = await fetchStockData(symbol, apiKey);
    
    if (stockData) {
      currentStockData = stockData;
      displayStockDetails(stockData);
      document.getElementById('searchResults').innerHTML = '';
      document.getElementById('stockDetailsSection').style.display = 'block';
      document.getElementById('timeRangeSelector').style.display = 'flex';
      
      // Load initial historical data for default range (6M)
      try {
        const historicalData = await apiService.fetchHistoricalData(symbol, '6M');
        currentHistoricalData = historicalData;
        if (historicalData && historicalData.length > 0) {
          console.log(`Loaded ${historicalData.length} historical data points`);
          renderPriceChart(historicalData);
        }
      } catch (error) {
        console.error('Error loading initial historical data:', error);
        document.getElementById('chartContainer').style.display = 'none';
      }
      
      updateTradeTotal();
      updateSellButtonState();
    } else {
      searchResults.innerHTML = '<div class="empty-state">Stock not found or error occurred</div>';
    }
  } catch (error) {
    console.error('Search error:', error);
    const errorMsg = error.message || 'Error searching for stock. Please try again.';
    searchResults.innerHTML = `<div class="empty-state">${errorMsg}</div>`;
  }
}

// Fetch stock data from API using API service
async function fetchStockData(symbol, apiKey) {
  try {
    if (!apiService) {
      await initializeAPIService();
    }

    if (!apiService) {
      throw new Error('API service not initialized. Please check your API key in Settings.');
    }

    // Fetch quote and profile in parallel
    const [quote, profile] = await Promise.all([
      apiService.fetchQuote(symbol).catch(err => {
        console.error('Error fetching quote:', err);
        return null;
      }),
      apiService.fetchCompanyProfile(symbol).catch(err => {
        console.error('Error fetching profile:', err);
        return null;
      })
    ]);

    if (!quote) {
      throw new Error('Stock not found or API error occurred');
    }

    return {
      symbol: quote.symbol,
      name: quote.name || profile?.name || symbol,
      price: quote.price,
      change: quote.change,
      changePercent: quote.changePercent,
      volume: quote.volume,
      marketCap: quote.marketCap || profile?.marketCap || 0,
      yearHigh: quote.yearHigh || 0,
      yearLow: quote.yearLow || 0,
      description: profile?.description || 'No description available.',
      sector: profile?.sector || 'N/A',
      industry: profile?.industry || 'N/A',
      website: profile?.website || null,
      ceo: profile?.ceo || null,
      exchange: profile?.exchange || quote.exchange || 'N/A',
      beta: profile?.beta || 0,
      peRatio: profile?.peRatio || quote.peRatio || 0,
      eps: profile?.eps || quote.eps || 0
    };
  } catch (error) {
    console.error('Error fetching stock data:', error);
    throw error;
  }
}

// Display stock details
function displayStockDetails(stockData) {
  const changeClass = stockData.change >= 0 ? 'positive' : 'negative';
  const changeSign = stockData.change >= 0 ? '+' : '';
  
  // Format large numbers
  const formatVolume = (vol) => {
    if (vol >= 1e9) return (vol / 1e9).toFixed(2) + 'B';
    if (vol >= 1e6) return (vol / 1e6).toFixed(2) + 'M';
    if (vol >= 1e3) return (vol / 1e3).toFixed(2) + 'K';
    return vol.toLocaleString();
  };

  const formatMarketCap = (cap) => {
    if (cap >= 1e12) return '$' + (cap / 1e12).toFixed(2) + 'T';
    if (cap >= 1e9) return '$' + (cap / 1e9).toFixed(2) + 'B';
    if (cap >= 1e6) return '$' + (cap / 1e6).toFixed(2) + 'M';
    return '$' + cap.toLocaleString();
  };

  // Update header
  document.getElementById('stockSymbolLarge').textContent = stockData.symbol;
  document.getElementById('stockCompanyName').textContent = stockData.name;
  document.getElementById('stockPriceLarge').textContent = `$${stockData.price.toFixed(2)}`;
  
  // Update price change
  const priceChangeEl = document.getElementById('stockPriceChange');
  priceChangeEl.textContent = `${changeSign}$${stockData.change.toFixed(2)} (${changeSign}${stockData.changePercent.toFixed(2)}%)`;
  priceChangeEl.className = `stock-price-change ${changeClass}`;
  
  // Update info grid
  document.getElementById('stockVolume').textContent = formatVolume(stockData.volume);
  document.getElementById('stockMarketCap').textContent = formatMarketCap(stockData.marketCap);
  document.getElementById('stock52WHigh').textContent = `$${stockData.yearHigh.toFixed(2)}`;
  document.getElementById('stock52WLow').textContent = `$${stockData.yearLow.toFixed(2)}`;
  
  // Update company info with beta, sector, description
  let companyInfoHtml = `<strong>${stockData.sector}</strong> • ${stockData.industry}`;
  
  // Add beta if available
  if (stockData.beta && stockData.beta > 0) {
    companyInfoHtml += ` • Beta: ${stockData.beta.toFixed(2)}`;
  }
  
  companyInfoHtml += '<br><br>';
  companyInfoHtml += stockData.description.substring(0, 300);
  if (stockData.description.length > 300) {
    companyInfoHtml += '...';
  }
  
  // Add additional metrics
  const metrics = [];
  if (stockData.peRatio && stockData.peRatio > 0) {
    metrics.push(`P/E: ${stockData.peRatio.toFixed(2)}`);
  }
  if (stockData.eps && stockData.eps > 0) {
    metrics.push(`EPS: $${stockData.eps.toFixed(2)}`);
  }
  if (metrics.length > 0) {
    companyInfoHtml += `<br><br><small style="color: #6c757d;">${metrics.join(' • ')}</small>`;
  }
  
  if (stockData.website) {
    companyInfoHtml += `<br><br><a href="${stockData.website}" target="_blank" style="color: #667eea; text-decoration: none;">Visit Website →</a>`;
  }
  document.getElementById('companyInfo').innerHTML = companyInfoHtml;
  
  // Reset share quantity
  document.getElementById('shareQuantityInput').value = '';
}

// Select time range and fetch historical OHLCV data
async function selectTimeRange(range) {
  currentTimeRange = range;
  
  // Update button states
  document.querySelectorAll('.time-range-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelector(`[data-range="${range}"]`).classList.add('active');
  
  // Load historical data for the selected range if we have a current symbol
  if (window.currentStockSymbol && apiService) {
    try {
      // Fetch historical time-series data with OHLCV (Open/High/Low/Close/Volume)
      const historicalData = await apiService.fetchHistoricalData(window.currentStockSymbol, range);
      
      // Store historical data for potential chart rendering
      currentHistoricalData = historicalData;
      
      // Verify data structure contains all required fields
      if (historicalData && historicalData.length > 0) {
        const sample = historicalData[0];
        console.log(`Loaded ${historicalData.length} data points for ${range}`);
        console.log('Sample data point:', {
          date: sample.date,
          open: sample.open,
          high: sample.high,
          low: sample.low,
          close: sample.close,
          volume: sample.volume
        });
        
        // Calculate and display price statistics
        displayHistoricalStats(historicalData);
        
        // Render price chart
        renderPriceChart(historicalData);
      } else {
        // Hide chart if no data
        document.getElementById('chartContainer').style.display = 'none';
      }
    } catch (error) {
      console.error('Error loading historical data:', error);
      currentHistoricalData = null;
      document.getElementById('chartContainer').style.display = 'none';
    }
  }
}

// Display statistics from historical OHLCV data
function displayHistoricalStats(historicalData) {
  if (!historicalData || historicalData.length === 0) return;
  
  // Calculate statistics from the historical data
  const closes = historicalData.map(d => d.close).filter(v => v > 0);
  const volumes = historicalData.map(d => d.volume).filter(v => v > 0);
  
  if (closes.length === 0) return;
  
  const minPrice = Math.min(...closes);
  const maxPrice = Math.max(...closes);
  const avgVolume = volumes.length > 0 ? volumes.reduce((a, b) => a + b, 0) / volumes.length : 0;
  
  // Display in console for now (can be enhanced to show in UI)
  console.log(`Price Range: $${minPrice.toFixed(2)} - $${maxPrice.toFixed(2)}`);
  console.log(`Average Volume: ${formatNumber(avgVolume)}`);
}

// Render price chart using Chart.js
function renderPriceChart(historicalData) {
  if (!historicalData || historicalData.length === 0) {
    document.getElementById('chartContainer').style.display = 'none';
    return;
  }

  const chartContainer = document.getElementById('chartContainer');
  const chartCanvas = document.getElementById('priceChart');
  
  // Show chart container
  chartContainer.style.display = 'block';

  // Prepare data for chart
  const labels = historicalData.map(d => {
    const date = new Date(d.date);
    // Format date based on time range
    if (currentTimeRange === '1W' || currentTimeRange === '1M') {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
    }
  });
  
  const closePrices = historicalData.map(d => d.close);
  const highPrices = historicalData.map(d => d.high);
  const lowPrices = historicalData.map(d => d.low);

  // Determine if price went up or down overall
  const firstPrice = closePrices[0];
  const lastPrice = closePrices[closePrices.length - 1];
  const isPositive = lastPrice >= firstPrice;
  const chartColor = isPositive ? '#28a745' : '#dc3545';
  const chartBgColor = isPositive ? 'rgba(40, 167, 69, 0.1)' : 'rgba(220, 53, 69, 0.1)';

  // Destroy existing chart if it exists
  if (priceChart) {
    priceChart.destroy();
  }

  // Create new chart
  const ctx = chartCanvas.getContext('2d');
  priceChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Close Price',
          data: closePrices,
          borderColor: chartColor,
          backgroundColor: chartBgColor,
          borderWidth: 2,
          fill: true,
          tension: 0.1,
          pointRadius: 0,
          pointHoverRadius: 4,
          pointHoverBackgroundColor: chartColor,
          pointHoverBorderColor: '#fff',
          pointHoverBorderWidth: 2
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          mode: 'index',
          intersect: false,
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          padding: 12,
          titleFont: {
            size: 12,
            weight: 'bold'
          },
          bodyFont: {
            size: 11
          },
          callbacks: {
            label: function(context) {
              const index = context.dataIndex;
              const data = historicalData[index];
              return [
                `Open: $${data.open.toFixed(2)}`,
                `High: $${data.high.toFixed(2)}`,
                `Low: $${data.low.toFixed(2)}`,
                `Close: $${data.close.toFixed(2)}`,
                `Volume: ${formatNumber(data.volume)}`
              ];
            },
            title: function(context) {
              return new Date(historicalData[context[0].dataIndex].date).toLocaleDateString('en-US', {
                weekday: 'short',
                year: 'numeric',
                month: 'short',
                day: 'numeric'
              });
            }
          }
        }
      },
      scales: {
        x: {
          display: true,
          grid: {
            display: false
          },
          ticks: {
            maxTicksLimit: 8,
            font: {
              size: 10
            },
            color: '#6c757d'
          }
        },
        y: {
          display: true,
          position: 'right',
          grid: {
            color: 'rgba(0, 0, 0, 0.05)'
          },
          ticks: {
            font: {
              size: 10
            },
            color: '#6c757d',
            callback: function(value) {
              return '$' + value.toFixed(2);
            }
          }
        }
      },
      interaction: {
        mode: 'index',
        intersect: false
      }
    }
  });
}

// Helper function to format numbers
function formatNumber(num) {
  if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
  if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
  if (num >= 1e3) return (num / 1e3).toFixed(2) + 'K';
  return num.toLocaleString();
}

// Update trade total
function updateTradeTotal() {
  if (!currentStockData) return;
  
  const quantity = parseInt(document.getElementById('shareQuantityInput').value) || 0;
  const total = currentStockData.price * quantity;
  
  document.getElementById('tradeTotal').textContent = `Total: $${total.toFixed(2)}`;
}

// Update sell button state based on portfolio
async function updateSellButtonState() {
  if (!currentStockData) return;
  
  const result = await getProfileData(['portfolio']);
  const portfolio = result.portfolio || [];
  const stock = portfolio.find(s => s.symbol === currentStockData.symbol);
  
  const sellButton = document.getElementById('sellButton');
  if (stock && stock.shares > 0) {
    sellButton.disabled = false;
    sellButton.title = `You own ${stock.shares} shares`;
  } else {
    sellButton.disabled = true;
    sellButton.title = 'You don\'t own this stock';
  }
}

// Handle buy
async function handleBuy() {
  if (!currentStockData) {
    alert('Please search for a stock first');
    return;
  }

  const quantityInput = document.getElementById('shareQuantityInput');
  const quantity = parseInt(quantityInput.value);
  
  if (!quantity || quantity < 1) {
    alert('Please enter a valid number of shares');
    return;
  }

  const totalCost = currentStockData.price * quantity;
  
  // Check balance
  const result = await getProfileData(['balance', 'portfolio', 'transactions']);
  const balance = result.balance || DEFAULT_BALANCE;
  
  if (totalCost > balance) {
    alert(`Insufficient funds. You need $${totalCost.toFixed(2)} but only have $${balance.toFixed(2)}`);
    return;
  }

  // Update portfolio
  const portfolio = result.portfolio || [];
  const existingStock = portfolio.find(s => s.symbol === currentStockData.symbol);
  
  if (existingStock) {
    // Add to existing position
    const newTotalShares = existingStock.shares + quantity;
    const newAveragePrice = ((existingStock.purchasePrice * existingStock.shares) + (currentStockData.price * quantity)) / newTotalShares;
    
    existingStock.shares = newTotalShares;
    existingStock.purchasePrice = newAveragePrice;
    existingStock.currentPrice = currentStockData.price;
  } else {
    // Add new stock
    portfolio.push({
      symbol: currentStockData.symbol,
      name: currentStockData.name,
      shares: quantity,
      purchasePrice: currentStockData.price,
      currentPrice: currentStockData.price
    });
  }

  // Record transaction
  const transactions = result.transactions || [];
  transactions.push({
    type: 'BUY',
    symbol: currentStockData.symbol,
    name: currentStockData.name,
    quantity: quantity,
    price: currentStockData.price,
    totalValue: totalCost,
    date: new Date().toISOString(),
    timestamp: Date.now()
  });

  // Update balance
  const newBalance = balance - totalCost;
  
  await setProfileData({
    portfolio: portfolio,
    balance: newBalance,
    transactions: transactions
  });

  // Refresh views
  loadPortfolioView();
  updateSellButtonState();
  quantityInput.value = '';
  updateTradeTotal();
  
  // Request service worker to record snapshot
  chrome.runtime.sendMessage({ action: 'recordSnapshot', profile: currentProfile });
  
  alert(`Successfully purchased ${quantity} share(s) of ${currentStockData.symbol} for $${totalCost.toFixed(2)}!`);
}

// Handle sell
async function handleSell() {
  if (!currentStockData) {
    alert('Please search for a stock first');
    return;
  }

  const quantityInput = document.getElementById('shareQuantityInput');
  const quantity = parseInt(quantityInput.value);
  
  if (!quantity || quantity < 1) {
    alert('Please enter a valid number of shares');
    return;
  }

  // Check if user owns the stock
  const result = await getProfileData(['portfolio', 'balance', 'transactions']);
  const portfolio = result.portfolio || [];
  const existingStock = portfolio.find(s => s.symbol === currentStockData.symbol);
  
  if (!existingStock || existingStock.shares < quantity) {
    alert(`You don't own enough shares. You own ${existingStock ? existingStock.shares : 0} share(s)`);
    return;
  }

  // Calculate sale value
  const saleValue = currentStockData.price * quantity;
  const newBalance = (result.balance || DEFAULT_BALANCE) + saleValue;

  // Record transaction
  const transactions = result.transactions || [];
  transactions.push({
    type: 'SELL',
    symbol: currentStockData.symbol,
    name: existingStock.name || currentStockData.name,
    quantity: quantity,
    price: currentStockData.price,
    totalValue: saleValue,
    purchasePrice: existingStock.purchasePrice, // For P/L calculation
    realizedPL: (currentStockData.price - existingStock.purchasePrice) * quantity,
    date: new Date().toISOString(),
    timestamp: Date.now()
  });

  // Update portfolio
  if (quantity === existingStock.shares) {
    // Remove stock completely
    const index = portfolio.indexOf(existingStock);
    portfolio.splice(index, 1);
  } else {
    // Reduce shares
    existingStock.shares -= quantity;
  }

  // Save all data to chrome.storage.local immediately
  await setProfileData({
    portfolio: portfolio,
    balance: newBalance,
    transactions: transactions
  });

  // Request service worker to record snapshot
  chrome.runtime.sendMessage({ action: 'recordSnapshot' });
  
  // Check for achievements after trade
  const newAchievements = await checkAchievements();
  if (newAchievements.length > 0) {
    showAchievementNotification(newAchievements);
  }

  // Refresh views
  loadPortfolioView();
  updateSellButtonState();
  quantityInput.value = '';
  updateTradeTotal();
  
  const realizedPL = (currentStockData.price - existingStock.purchasePrice) * quantity;
  const plText = realizedPL >= 0 ? `Profit: $${realizedPL.toFixed(2)}` : `Loss: $${Math.abs(realizedPL).toFixed(2)}`;
  alert(`Successfully sold ${quantity} share(s) of ${currentStockData.symbol} for $${saleValue.toFixed(2)}! ${plText}`);
}

// Load analytics view with equity curve
async function loadAnalyticsView() {
  const profileData = await getProfileData(['portfolioHistory', 'balance', 'initialBalance', 'portfolio']);
  const apiSettings = await chrome.storage.local.get(['apiKey', 'apiProvider']);
  
  const portfolioHistory = profileData.portfolioHistory || [];
  const balance = profileData.balance || DEFAULT_BALANCE;
  const initialBalance = profileData.initialBalance || DEFAULT_BALANCE;
  const portfolio = profileData.portfolio || [];
  
  // Calculate current portfolio value if we have holdings
  let currentValue = balance;
  if (portfolio.length > 0 && apiService) {
    try {
      const symbols = portfolio.map(s => s.symbol);
      const quotes = await apiService.fetchQuotes(symbols);
      quotes.forEach(quote => {
        const stock = portfolio.find(s => s.symbol === quote.symbol);
        if (stock) {
          currentValue += quote.price * stock.shares;
        }
      });
    } catch (error) {
      console.error('Error fetching current prices for analytics:', error);
      // Use cached prices
      portfolio.forEach(stock => {
        currentValue += (stock.currentPrice || stock.purchasePrice) * stock.shares;
      });
    }
  }
  
  // Calculate metrics
  const metrics = calculateMetrics(portfolioHistory, currentValue, initialBalance);
  displayAnalyticsMetrics(metrics);
  
  // Render equity curve chart
  const compareIndex = document.getElementById('compareIndex')?.checked || false;
  await renderEquityCurve(portfolioHistory, currentValue, initialBalance, compareIndex);
}

// Calculate performance metrics
function calculateMetrics(portfolioHistory, currentValue, initialBalance) {
  const totalReturn = currentValue - initialBalance;
  const totalReturnPercent = ((totalReturn / initialBalance) * 100);
  
  // Calculate daily returns if we have history
  let avgDailyReturn = 0;
  let bestDay = null;
  let worstDay = null;
  let daysTracked = portfolioHistory.length;
  
  if (portfolioHistory.length > 1) {
    const dailyReturns = [];
    for (let i = 1; i < portfolioHistory.length; i++) {
      const prevValue = portfolioHistory[i - 1].totalValue;
      const currValue = portfolioHistory[i].totalValue;
      const dailyReturn = ((currValue - prevValue) / prevValue) * 100;
      dailyReturns.push(dailyReturn);
      
      if (!bestDay || dailyReturn > bestDay.return) {
        bestDay = { date: portfolioHistory[i].date, return: dailyReturn };
      }
      if (!worstDay || dailyReturn < worstDay.return) {
        worstDay = { date: portfolioHistory[i].date, return: dailyReturn };
      }
    }
    
    if (dailyReturns.length > 0) {
      avgDailyReturn = dailyReturns.reduce((a, b) => a + b, 0) / dailyReturns.length;
    }
  }
  
  // Calculate time-weighted return (simple for now)
  const firstSnapshot = portfolioHistory.length > 0 ? portfolioHistory[0] : null;
  const startDate = firstSnapshot ? new Date(firstSnapshot.date) : new Date();
  const daysSinceStart = Math.max(1, Math.floor((Date.now() - startDate.getTime()) / (1000 * 60 * 60 * 24)));
  const annualizedReturn = daysSinceStart > 0 ? (totalReturnPercent / daysSinceStart) * 365 : 0;
  
  return {
    currentValue,
    initialBalance,
    totalReturn,
    totalReturnPercent,
    avgDailyReturn,
    bestDay,
    worstDay,
    daysTracked,
    annualizedReturn,
    daysSinceStart
  };
}

// Display analytics metrics
function displayAnalyticsMetrics(metrics) {
  const metricsContainer = document.getElementById('analyticsMetrics');
  
  metricsContainer.innerHTML = `
    <div class="metrics-grid">
      <div class="metric-item">
        <div class="metric-label">Total Return</div>
        <div class="metric-value ${metrics.totalReturn >= 0 ? 'positive' : 'negative'}">
          ${metrics.totalReturn >= 0 ? '+' : ''}$${metrics.totalReturn.toFixed(2)}
        </div>
        <div class="metric-subvalue">${metrics.totalReturn >= 0 ? '+' : ''}${metrics.totalReturnPercent.toFixed(2)}%</div>
      </div>
      <div class="metric-item">
        <div class="metric-label">Current Value</div>
        <div class="metric-value">$${metrics.currentValue.toFixed(2)}</div>
        <div class="metric-subvalue">From $${metrics.initialBalance.toFixed(2)}</div>
      </div>
      <div class="metric-item">
        <div class="metric-label">Days Tracked</div>
        <div class="metric-value">${metrics.daysTracked}</div>
        <div class="metric-subvalue">${metrics.daysSinceStart > 0 ? `${metrics.daysSinceStart} days since start` : 'Just started'}</div>
      </div>
      <div class="metric-item">
        <div class="metric-label">Avg Daily Return</div>
        <div class="metric-value ${metrics.avgDailyReturn >= 0 ? 'positive' : 'negative'}">
          ${metrics.avgDailyReturn >= 0 ? '+' : ''}${metrics.avgDailyReturn.toFixed(2)}%
        </div>
        <div class="metric-subvalue">${metrics.annualizedReturn >= 0 ? '+' : ''}${metrics.annualizedReturn.toFixed(2)}% annualized</div>
      </div>
    </div>
    ${metrics.bestDay && metrics.worstDay ? `
      <div class="metrics-extras">
        <div class="metric-extra">
          <span class="extra-label">Best Day:</span>
          <span class="extra-value positive">${metrics.bestDay.date} (+${metrics.bestDay.return.toFixed(2)}%)</span>
        </div>
        <div class="metric-extra">
          <span class="extra-label">Worst Day:</span>
          <span class="extra-value negative">${metrics.worstDay.date} (${metrics.worstDay.return.toFixed(2)}%)</span>
        </div>
      </div>
    ` : ''}
  `;
}

// Render equity curve chart
async function renderEquityCurve(portfolioHistory, currentValue, initialBalance, compareIndex = false) {
  const chartCanvas = document.getElementById('equityChart');
  if (!chartCanvas) return;
  
  // Destroy existing chart if it exists
  if (equityChart) {
    equityChart.destroy();
  }
  
  // Prepare data
  const historyData = [...portfolioHistory];
  
  // Add today's value if not already recorded
  const today = new Date().toISOString().split('T')[0];
  const lastSnapshot = historyData.length > 0 ? historyData[historyData.length - 1] : null;
  if (!lastSnapshot || lastSnapshot.date !== today) {
    historyData.push({
      date: today,
      totalValue: currentValue,
      timestamp: Date.now()
    });
  }
  
  if (historyData.length === 0) {
    chartCanvas.parentElement.innerHTML = '<div class="empty-state">No portfolio history yet. Start trading to see your equity curve!</div>';
    return;
  }
  
  // Sort by date
  historyData.sort((a, b) => new Date(a.date) - new Date(b.date));
  
  const labels = historyData.map(s => {
    const date = new Date(s.date);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  });
  
  const portfolioValues = historyData.map(s => s.totalValue);
  
  // Prepare datasets
  const datasets = [
    {
      label: 'Portfolio Value',
      data: portfolioValues,
      borderColor: '#667eea',
      backgroundColor: 'rgba(102, 126, 234, 0.1)',
      borderWidth: 2,
      fill: true,
      tension: 0.1,
      pointRadius: 0,
      pointHoverRadius: 4
    }
  ];
  
  // Add index comparison if requested
  if (compareIndex && apiService && historyData.length > 0) {
    try {
      const indexData = await fetchIndexComparisonData(historyData, initialBalance);
      if (indexData && indexData.length > 0) {
        datasets.push({
          label: 'S&P 500 (SPY)',
          data: indexData,
          borderColor: '#6c757d',
          backgroundColor: 'rgba(108, 117, 125, 0.1)',
          borderWidth: 2,
          fill: false,
          tension: 0.1,
          pointRadius: 0,
          pointHoverRadius: 4,
          borderDash: [5, 5]
        });
      }
    } catch (error) {
      console.error('Error fetching index comparison:', error);
    }
  }
  
  // Create chart
  const ctx = chartCanvas.getContext('2d');
  equityChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: datasets
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: 'top'
        },
        tooltip: {
          mode: 'index',
          intersect: false,
          callbacks: {
            label: function(context) {
              const value = context.parsed.y;
              const returnPercent = ((value - initialBalance) / initialBalance) * 100;
              return `${context.dataset.label}: $${value.toFixed(2)} (${returnPercent >= 0 ? '+' : ''}${returnPercent.toFixed(2)}%)`;
            }
          }
        }
      },
      scales: {
        x: {
          display: true,
          grid: {
            display: false
          },
          ticks: {
            maxTicksLimit: 10,
            font: {
              size: 10
            }
          }
        },
        y: {
          display: true,
          position: 'right',
          grid: {
            color: 'rgba(0, 0, 0, 0.05)'
          },
          ticks: {
            callback: function(value) {
              return '$' + value.toFixed(0);
            },
            font: {
              size: 10
            }
          }
        }
      },
      interaction: {
        mode: 'index',
        intersect: false
      }
    }
  });
}

// Fetch index comparison data (S&P 500 / SPY)
async function fetchIndexComparisonData(portfolioHistory, initialBalance) {
  if (!apiService || portfolioHistory.length === 0) return null;
  
  try {
    const firstDate = portfolioHistory[0].date;
    const lastDate = portfolioHistory[portfolioHistory.length - 1].date;
    
    // Fetch SPY historical data
    const historicalData = await apiService.fetchHistoricalData('SPY', '1Y');
    if (!historicalData || historicalData.length === 0) return null;
    
    // Create a map of dates to prices
    const priceMap = {};
    historicalData.forEach(item => {
      priceMap[item.date] = item.close;
    });
    
    // Calculate index values normalized to initial balance
    const firstPrice = priceMap[firstDate] || historicalData[0].close;
    const normalizedValues = portfolioHistory.map(snapshot => {
      const price = priceMap[snapshot.date];
      if (price) {
        // Normalize to start at initialBalance
        return (price / firstPrice) * initialBalance;
      }
      return null;
    }).filter(v => v !== null);
    
    return normalizedValues.length > 0 ? normalizedValues : null;
  } catch (error) {
    console.error('Error fetching index data:', error);
    return null;
  }
}

// ==================== LEARNING & QUIZ SYSTEM ====================

let currentQuiz = null;
let currentQuestionIndex = 0;
let quizAnswers = [];
let quizSelectedQuestions = [];

// Load learning view
async function loadLearningView() {
  // Populate category dropdowns
  const categories = getCategories();
  const quizCategorySelect = document.getElementById('quizCategory');
  const tipsCategorySelect = document.getElementById('tipsCategory');
  
  if (quizCategorySelect) {
    // Clear existing options except "All"
    while (quizCategorySelect.children.length > 1) {
      quizCategorySelect.removeChild(quizCategorySelect.lastChild);
    }
    categories.forEach(cat => {
      const option = document.createElement('option');
      option.value = cat;
      option.textContent = cat;
      quizCategorySelect.appendChild(option);
    });
  }
  
  if (tipsCategorySelect) {
    while (tipsCategorySelect.children.length > 1) {
      tipsCategorySelect.removeChild(tipsCategorySelect.lastChild);
    }
    categories.forEach(cat => {
      const option = document.createElement('option');
      option.value = cat;
      option.textContent = cat;
      tipsCategorySelect.appendChild(option);
    });
  }
  
  // Load quiz scores
  await loadQuizScores();
  
  // Load learning tips
  loadLearningTips();
}

// Switch learning tab
function switchLearningTab(tabName) {
  document.querySelectorAll('.learning-tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelector(`[data-learning-tab="${tabName}"]`).classList.add('active');
  
  document.querySelectorAll('.learning-tab-content').forEach(content => {
    content.classList.remove('active');
  });
  
  if (tabName === 'quizzes') {
    document.getElementById('quizzesContent').classList.add('active');
  } else if (tabName === 'tips') {
    document.getElementById('tipsContent').classList.add('active');
    loadLearningTips();
  }
}

// Start quiz
function startQuiz() {
  const category = document.getElementById('quizCategory').value;
  const questions = getQuestionsByCategory(category);
  
  if (questions.length === 0) {
    alert('No questions available for this category.');
    return;
  }
  
  // Select 5 random questions
  const shuffled = [...questions].sort(() => Math.random() - 0.5);
  quizSelectedQuestions = shuffled.slice(0, Math.min(5, shuffled.length));
  
  currentQuiz = {
    questions: quizSelectedQuestions,
    category: category,
    startTime: Date.now()
  };
  
  currentQuestionIndex = 0;
  quizAnswers = [];
  
  // Hide start button and show quiz
  document.getElementById('startQuizBtn').style.display = 'none';
  document.getElementById('quizContainer').classList.remove('hidden');
  document.getElementById('quizResults').classList.add('hidden');
  document.getElementById('quizScoresList').classList.add('hidden');
  
  displayQuizQuestion();
}

// Display current quiz question
function displayQuizQuestion() {
  if (!currentQuiz || currentQuestionIndex >= currentQuiz.questions.length) {
    finishQuiz();
    return;
  }
  
  const question = currentQuiz.questions[currentQuestionIndex];
  const totalQuestions = currentQuiz.questions.length;
  
  // Update progress
  const progressPercent = ((currentQuestionIndex + 1) / totalQuestions) * 100;
  document.getElementById('quizProgressFill').style.width = progressPercent + '%';
  document.getElementById('quizProgressText').textContent = `Question ${currentQuestionIndex + 1} of ${totalQuestions}`;
  
  // Display question
  document.getElementById('quizQuestion').innerHTML = `
    <div class="quiz-question-category">${question.category}</div>
    <div class="quiz-question-text">${question.question}</div>
  `;
  
  // Display options
  const optionsContainer = document.getElementById('quizOptions');
  optionsContainer.innerHTML = question.options.map((option, index) => `
    <button class="quiz-option" data-option="${index}" onclick="selectQuizOption(${index})">
      ${option}
    </button>
  `).join('');
  
  // Hide feedback and buttons
  document.getElementById('quizFeedback').classList.add('hidden');
  document.getElementById('quizNextBtn').classList.add('hidden');
  document.getElementById('quizFinishBtn').classList.add('hidden');
}

// Select quiz option
window.selectQuizOption = function(optionIndex) {
  if (quizAnswers[currentQuestionIndex] !== undefined) {
    return; // Already answered
  }
  
  const question = currentQuiz.questions[currentQuestionIndex];
  const isCorrect = optionIndex === question.correct;
  
  quizAnswers[currentQuestionIndex] = {
    questionId: question.id,
    selected: optionIndex,
    correct: question.correct,
    isCorrect: isCorrect
  };
  
  // Show feedback
  const feedbackEl = document.getElementById('quizFeedback');
  feedbackEl.classList.remove('hidden');
  feedbackEl.innerHTML = `
    <div class="quiz-feedback-content ${isCorrect ? 'correct' : 'incorrect'}">
      <div class="quiz-feedback-icon">${isCorrect ? '✓' : '✗'}</div>
      <div class="quiz-feedback-text">
        ${isCorrect ? '<strong>Correct!</strong>' : '<strong>Incorrect.</strong>'}
        ${question.explanation}
      </div>
    </div>
  `;
  
  // Disable options
  document.querySelectorAll('.quiz-option').forEach((btn, idx) => {
    btn.disabled = true;
    if (idx === question.correct) {
      btn.classList.add('correct-answer');
    } else if (idx === optionIndex && !isCorrect) {
      btn.classList.add('wrong-answer');
    }
  });
  
  // Show next/finish button
  if (currentQuestionIndex < currentQuiz.questions.length - 1) {
    document.getElementById('quizNextBtn').classList.remove('hidden');
  } else {
    document.getElementById('quizFinishBtn').classList.remove('hidden');
  }
};

// Next quiz question
function nextQuizQuestion() {
  currentQuestionIndex++;
  displayQuizQuestion();
}

// Finish quiz
async function finishQuiz() {
  const score = quizAnswers.filter(a => a.isCorrect).length;
  const totalQuestions = currentQuiz.questions.length;
  const percentage = Math.round((score / totalQuestions) * 100);
  
  // Save score
  const quizId = `quiz_${Date.now()}`;
  await saveQuizScore(quizId, score, totalQuestions);
  
  // Display results
  document.getElementById('quizContainer').classList.add('hidden');
  document.getElementById('quizResults').classList.remove('hidden');
  
  document.getElementById('quizScore').innerHTML = `
    <div class="quiz-score-value ${percentage >= 70 ? 'good' : percentage >= 50 ? 'average' : 'poor'}">
      ${score} / ${totalQuestions} (${percentage}%)
    </div>
  `;
  
  // Show summary
  const summaryHtml = currentQuiz.questions.map((q, idx) => {
    const answer = quizAnswers[idx];
    return `
      <div class="quiz-summary-item ${answer.isCorrect ? 'correct' : 'incorrect'}">
        <div class="quiz-summary-icon">${answer.isCorrect ? '✓' : '✗'}</div>
        <div class="quiz-summary-question">${q.question}</div>
      </div>
    `;
  }).join('');
  
  document.getElementById('quizSummary').innerHTML = summaryHtml;
  
  // Reload scores
  await loadQuizScores();
  
  // Reset quiz state
  currentQuiz = null;
  currentQuestionIndex = 0;
  quizAnswers = [];
  quizSelectedQuestions = [];
}

// Reset quiz
function resetQuiz() {
  document.getElementById('quizResults').classList.add('hidden');
  document.getElementById('quizContainer').classList.add('hidden');
  document.getElementById('startQuizBtn').style.display = 'block';
  document.getElementById('quizScoresList').classList.remove('hidden');
  currentQuiz = null;
  currentQuestionIndex = 0;
  quizAnswers = [];
  quizSelectedQuestions = [];
}

// Load quiz scores
async function loadQuizScores() {
  const scores = await getQuizScores();
  const scoresContent = document.getElementById('quizScoresContent');
  
  if (!scoresContent) return;
  
  const scoreEntries = Object.entries(scores).sort((a, b) => b[1].timestamp - a[1].timestamp);
  
  if (scoreEntries.length === 0) {
    scoresContent.innerHTML = '<div class="empty-state">No quiz scores yet. Take a quiz to get started!</div>';
    return;
  }
  
  scoresContent.innerHTML = scoreEntries.map(([id, score]) => `
    <div class="quiz-score-item">
      <div class="quiz-score-date">${new Date(score.completedAt).toLocaleDateString()}</div>
      <div class="quiz-score-value-small ${score.percentage >= 70 ? 'good' : score.percentage >= 50 ? 'average' : 'poor'}">
        ${score.score} / ${score.totalQuestions} (${score.percentage}%)
      </div>
    </div>
  `).join('');
}

// ==================== SETTINGS TAB ====================

// Load settings tab with current API key
async function loadSettingsTab() {
  const result = await chrome.storage.local.get(['apiKey', 'apiProvider']);
  
  // Set API provider
  document.getElementById('popupApiProvider').value = result.apiProvider || 'alphavantage';
  
  // Set API key (masked)
  const apiKeyInput = document.getElementById('popupApiKey');
  if (result.apiKey) {
    apiKeyInput.value = result.apiKey;
    apiKeyInput.type = 'password'; // Ensure it's masked
  } else {
    apiKeyInput.value = '';
  }
  
  // Update help text
  updateSettingsHelpText();
  
  // Clear status message
  const statusDiv = document.getElementById('apiKeyStatus');
  statusDiv.classList.add('hidden');
  statusDiv.className = 'api-key-status hidden';
}

// Update help text based on selected provider
function updateSettingsHelpText() {
  const provider = document.getElementById('popupApiProvider').value;
  const helpText = document.querySelector('.api-key-section .help-text');
  
  if (provider === 'alphavantage') {
    helpText.innerHTML = `
      Don't have an API key? 
      <a href="https://www.alphavantage.co/support/#api-key" target="_blank" class="api-key-link">
        Get a free Alpha Vantage API key →
      </a>
      <br>
      <small style="color: #6c757d;">Free tier: 25 requests per day</small>
    `;
  } else {
    helpText.innerHTML = `
      Don't have an API key? 
      <a href="https://site.financialmodelingprep.com/developer/docs/" target="_blank" class="api-key-link">
        Get a free FMP API key →
      </a>
      <br>
      <small style="color: #6c757d;">Free tier: 250 requests per day</small>
    `;
  }
}

// Toggle API key visibility
function toggleApiKeyVisibility() {
  const apiKeyInput = document.getElementById('popupApiKey');
  const toggleBtn = document.getElementById('toggleApiKeyVisibility');
  
  if (apiKeyInput.type === 'password') {
    apiKeyInput.type = 'text';
    toggleBtn.textContent = '🙈';
  } else {
    apiKeyInput.type = 'password';
    toggleBtn.textContent = '👁️';
  }
}

// Save API key from popup settings
async function saveApiKeyFromPopup() {
  const apiKey = document.getElementById('popupApiKey').value.trim();
  const apiProvider = document.getElementById('popupApiProvider').value;
  const statusDiv = document.getElementById('apiKeyStatus');
  
  if (!apiKey) {
    statusDiv.textContent = 'Please enter an API key';
    statusDiv.className = 'api-key-status error';
    statusDiv.classList.remove('hidden');
    return;
  }

  // Validate API key if possible
  try {
    if (typeof StockAPIService !== 'undefined') {
      const testApiService = new StockAPIService(apiProvider, apiKey);
      const isValid = await testApiService.validateAPIKey();
      
      if (!isValid) {
        statusDiv.textContent = 'API key validation failed. Please check your key.';
        statusDiv.className = 'api-key-status error';
        statusDiv.classList.remove('hidden');
        return;
      }
    }
  } catch (error) {
    console.error('Error validating API key:', error);
    // Continue anyway - might be network issue
  }
  
  // Save to storage
  await chrome.storage.local.set({ 
    apiKey: apiKey,
    apiProvider: apiProvider
  });
  
  // Update API service instance
  apiService = new StockAPIService(apiProvider, apiKey);
  
  // Show success message
  statusDiv.textContent = 'API key saved successfully!';
  statusDiv.className = 'api-key-status success';
  statusDiv.classList.remove('hidden');
  
  // Hide message after 3 seconds
  setTimeout(() => {
    statusDiv.classList.add('hidden');
  }, 3000);
}

// Load learning tips
function loadLearningTips() {
  const category = document.getElementById('tipsCategory')?.value || 'All';
  const tips = getLearningTips(category);
  const tipsList = document.getElementById('tipsList');
  
  if (!tipsList) return;
  
  tipsList.innerHTML = tips.map(tip => `
    <div class="tip-card">
      <div class="tip-header">
        <div class="tip-category">${tip.category}</div>
        <h4 class="tip-title">${tip.title}</h4>
      </div>
      <div class="tip-content">${tip.content}</div>
    </div>
  `).join('');
}
