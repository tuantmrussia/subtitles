// Service Worker for Stock Simulator extension (Manifest V3)

// Load API service script (importScripts is synchronous in service workers)
try {
  importScripts('api-service.js');
} catch (error) {
  console.error('Error loading API service:', error);
}

// Initialize extension
chrome.runtime.onInstalled.addListener(() => {
  console.log('Stock Simulator extension installed');
  
  // Set default values
  chrome.storage.local.get(['portfolio', 'balance', 'initialBalance', 'portfolioHistory', 'apiKey', 'apiProvider'], (result) => {
    if (!result.portfolio) {
      chrome.storage.local.set({
        portfolio: [],
        balance: 100000,
        initialBalance: 100000,
        portfolioHistory: []
      });
    }
    
    // Initialize portfolio history if not exists
    if (!result.portfolioHistory) {
      chrome.storage.local.set({
        portfolioHistory: []
      });
    }
    
    // Note: API key should be set by user via Settings tab
  });
  
  // Set up daily alarm for portfolio snapshot
  chrome.alarms.create('dailyPortfolioSnapshot', {
    periodInMinutes: 1440 // 24 hours
  });
  
  // Also create a periodic update alarm (every 4 hours)
  chrome.alarms.create('updatePrices', {
    periodInMinutes: 240 // 4 hours
  });
  
  // Run initial snapshot
  recordPortfolioSnapshot();
});

// Listen for messages from popup or other parts of the extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateStockPrices') {
    updateStockPrices().then(() => {
      sendResponse({ success: true });
    });
    return true; // Indicates we will send a response asynchronously
  } else if (request.action === 'recordSnapshot') {
    recordPortfolioSnapshot(request.profile || null).then(() => {
      sendResponse({ success: true });
    });
    return true;
  } else if (request.action === 'addStockToPortfolio') {
    addStockToPortfolioFromContent(request.symbol).then((result) => {
      sendResponse(result);
    }).catch((error) => {
      sendResponse({ success: false, error: error.message });
    });
    return true; // Indicates we will send a response asynchronously
  }
});

// Update stock prices in portfolio (can be called periodically)
async function updateStockPrices() {
  try {
    const result = await chrome.storage.local.get([
      'apiKey', 
      'apiProvider',
      'currentProfile',
      'profiles'
    ]);
    
    const apiKey = result.apiKey;
    const apiProvider = result.apiProvider || 'alphavantage';
    const currentProfile = result.currentProfile || 'default';
    const profiles = result.profiles || {};
    const profileData = profiles[currentProfile] || { portfolio: [] };
    const portfolio = profileData.portfolio || [];

    if (portfolio.length === 0 || !apiKey) {
      return;
    }

    // Create API service instance (should be available after importScripts)
    if (typeof StockAPIService === 'undefined') {
      console.error('StockAPIService not loaded');
      return;
    }
    
    const apiService = new StockAPIService(apiProvider, apiKey);

    // Get all symbols
    const symbols = portfolio.map(stock => stock.symbol);
    
    // Fetch current prices using API service
    const quotes = await apiService.fetchQuotes(symbols);

    if (quotes && Array.isArray(quotes)) {
      // Update prices in portfolio
      portfolio.forEach(stock => {
        const quote = quotes.find(q => q.symbol === stock.symbol);
        if (quote) {
          stock.currentPrice = quote.price;
        }
      });

      // Update profile data
      profileData.portfolio = portfolio;
      profiles[currentProfile] = profileData;
      await chrome.storage.local.set({ profiles: profiles });
    }
  } catch (error) {
    console.error('Error updating stock prices:', error);
  }
}

// Listen for alarm events
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'dailyPortfolioSnapshot') {
    recordPortfolioSnapshot();
  } else if (alarm.name === 'updatePrices') {
    updateStockPrices();
  }
});

// Record daily portfolio snapshot for equity curve
async function recordPortfolioSnapshot() {
  try {
    const result = await chrome.storage.local.get([
      'apiKey',
      'apiProvider',
      'currentProfile',
      'profiles'
    ]);
    
    const apiKey = result.apiKey;
    const apiProvider = result.apiProvider || 'alphavantage';
    const currentProfile = result.currentProfile || 'default';
    const profiles = result.profiles || {};
    const profileData = profiles[currentProfile] || {
      portfolio: [],
      balance: 100000,
      initialBalance: 100000,
      portfolioHistory: []
    };
    
    const portfolio = profileData.portfolio || [];
    const balance = profileData.balance || 100000;
    const initialBalance = profileData.initialBalance || 100000;
    const portfolioHistory = profileData.portfolioHistory || [];
    
    // Calculate current portfolio value
    let holdingsValue = 0;
    
    if (portfolio.length > 0 && apiKey) {
      try {
        // Try to fetch current prices
        if (typeof StockAPIService !== 'undefined') {
          const apiService = new StockAPIService(apiProvider, apiKey);
          const symbols = portfolio.map(stock => stock.symbol);
          const quotes = await apiService.fetchQuotes(symbols);
          
          if (quotes && Array.isArray(quotes)) {
            portfolio.forEach(stock => {
              const quote = quotes.find(q => q.symbol === stock.symbol);
              if (quote) {
                holdingsValue += quote.price * stock.shares;
                stock.currentPrice = quote.price; // Update cached price
              } else {
                holdingsValue += (stock.currentPrice || stock.purchasePrice) * stock.shares;
              }
            });
            
            // Update portfolio with new prices
            profileData.portfolio = portfolio;
          } else {
            // Fallback to cached prices
            portfolio.forEach(stock => {
              holdingsValue += (stock.currentPrice || stock.purchasePrice) * stock.shares;
            });
          }
        } else {
          // Fallback to cached prices
          portfolio.forEach(stock => {
            holdingsValue += (stock.currentPrice || stock.purchasePrice) * stock.shares;
          });
        }
      } catch (error) {
        console.error('Error fetching prices for snapshot:', error);
        // Fallback to cached prices
        portfolio.forEach(stock => {
          holdingsValue += (stock.currentPrice || stock.purchasePrice) * stock.shares;
        });
      }
    }
    
    const totalValue = balance + holdingsValue;
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    
    // Check if we already have a snapshot for today
    const todayIndex = portfolioHistory.findIndex(s => s.date === today);
    
    const snapshot = {
      date: today,
      timestamp: Date.now(),
      cashBalance: balance,
      holdingsValue: holdingsValue,
      totalValue: totalValue,
      initialBalance: initialBalance,
      returnPercent: ((totalValue - initialBalance) / initialBalance) * 100,
      holdingsCount: portfolio.length
    };
    
    if (todayIndex >= 0) {
      // Update today's snapshot
      portfolioHistory[todayIndex] = snapshot;
    } else {
      // Add new snapshot
      portfolioHistory.push(snapshot);
      
      // Keep only last 365 days to avoid storage bloat
      if (portfolioHistory.length > 365) {
        portfolioHistory.shift();
      }
    }
    
    // Sort by date
    portfolioHistory.sort((a, b) => new Date(a.date) - new Date(b.date));
    
    // Update profile data
    profileData.portfolioHistory = portfolioHistory;
    profiles[currentProfile] = profileData;
    await chrome.storage.local.set({ profiles: profiles });
    console.log('Portfolio snapshot recorded:', snapshot);
  } catch (error) {
    console.error('Error recording portfolio snapshot:', error);
  }
}

// Add stock to portfolio from content script
async function addStockToPortfolioFromContent(symbol) {
  try {
    if (!symbol) {
      throw new Error('Symbol is required');
    }

    const result = await chrome.storage.local.get([
      'portfolio', 
      'balance', 
      'transactions',
      'apiKey',
      'apiProvider',
      'currentProfile',
      'profiles'
    ]);

    const apiKey = result.apiKey;
    const apiProvider = result.apiProvider || 'fmp';
    
    if (!apiKey) {
      throw new Error('API key not configured. Please set your API key in Settings.');
    }

    // Get current profile data
    const currentProfile = result.currentProfile || 'default';
    const profiles = result.profiles || {};
    const profileData = profiles[currentProfile] || {
      portfolio: [],
      balance: 100000,
      transactions: []
    };

    const portfolio = profileData.portfolio || [];
    const balance = profileData.balance || 100000;

    // Check if stock already exists in portfolio
    const existingStock = portfolio.find(s => s.symbol === symbol.toUpperCase());
    if (existingStock) {
      return { 
        success: false, 
        error: `${symbol} is already in your portfolio`,
        alreadyExists: true
      };
    }

    // Create API service instance
    if (typeof StockAPIService === 'undefined') {
      throw new Error('API service not available');
    }
    
    const apiService = new StockAPIService(apiProvider, apiKey);

    // Fetch stock quote and profile
    const [quote, profile] = await Promise.all([
      apiService.fetchQuote(symbol).catch(() => null),
      apiService.fetchCompanyProfile(symbol).catch(() => null)
    ]);

    if (!quote) {
      throw new Error(`Could not find stock information for ${symbol}`);
    }

    const stockName = quote.name || profile?.name || symbol;
    const stockPrice = quote.price;

    // Add stock to portfolio with 0 shares (user can buy later)
    // Or we could add 1 share automatically - let's add 1 share for quick-add
    const quantity = 1;
    const totalCost = stockPrice * quantity;

    if (totalCost > balance) {
      // Add with 0 shares if insufficient funds
      portfolio.push({
        symbol: symbol.toUpperCase(),
        name: stockName,
        shares: 0,
        purchasePrice: stockPrice,
        currentPrice: stockPrice
      });
    } else {
      // Add with 1 share
      portfolio.push({
        symbol: symbol.toUpperCase(),
        name: stockName,
        shares: quantity,
        purchasePrice: stockPrice,
        currentPrice: stockPrice
      });

      // Update balance
      profileData.balance = balance - totalCost;

      // Record transaction
      const transactions = profileData.transactions || [];
      transactions.push({
        type: 'BUY',
        symbol: symbol.toUpperCase(),
        name: stockName,
        quantity: quantity,
        price: stockPrice,
        totalValue: totalCost,
        date: new Date().toISOString(),
        timestamp: Date.now(),
        source: 'content_script'
      });
      profileData.transactions = transactions;
    }

    // Update profile data
    profileData.portfolio = portfolio;
    profiles[currentProfile] = profileData;
    
    await chrome.storage.local.set({ profiles: profiles });

    // Record snapshot directly (no need to send message to self)
    recordPortfolioSnapshot();

    return { 
      success: true, 
      symbol: symbol.toUpperCase(),
      name: stockName,
      price: stockPrice,
      shares: totalCost <= balance ? quantity : 0,
      message: totalCost <= balance 
        ? `Added ${quantity} share of ${symbol.toUpperCase()} to your portfolio`
        : `Added ${symbol.toUpperCase()} to watchlist (insufficient funds for purchase)`
    };
  } catch (error) {
    console.error('Error adding stock to portfolio:', error);
    return { 
      success: false, 
      error: error.message || 'Failed to add stock to portfolio'
    };
  }
}


