# Stock Simulator Chrome Extension

A Chrome extension for simulating stock market trading and portfolio management.

## Features

- **Portfolio Management**: Track your stock portfolio with real-time price updates
- **Stock Search**: Search and buy stocks using the Financial Modeling Prep API
- **Balance Tracking**: Monitor your portfolio value and gains/losses
- **Modern UI**: Beautiful and intuitive user interface

## Setup

1. **Load the Extension**:
   - Open Chrome and navigate to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)
   - Click "Load unpacked"
   - Select this directory

2. **Get API Key**:
   - Visit [Financial Modeling Prep](https://site.financialmodelingprep.com/developer/docs/)
   - Sign up for a free account and get your API key
   - Open the extension popup and click "Settings"
   - Enter your API key and save

3. **Start Trading**:
   - Click the extension icon to open the popup
   - Use the "Search" tab to find stocks
   - Buy stocks and manage your portfolio in the "Portfolio" tab

## Project Structure

```
ChromeExtensionStockSimulator/
├── manifest.json          # Extension manifest (Manifest V3)
├── popup.html            # Main popup UI
├── popup.css             # Popup styles
├── popup.js              # Popup logic
├── service_worker.js     # Background service worker
├── options.html          # Settings page
├── options.js            # Settings page logic
├── icons/                # Extension icons (to be added)
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md             # This file
```

## Icons

You need to add icon files to the `icons/` directory:
- `icon16.png` (16×16 pixels)
- `icon48.png` (48×48 pixels)
- `icon128.png` (128×128 pixels)

### Generating Icons

1. Open `generate-icons.html` in your web browser
2. Click on each icon (or right-click and "Save image as...")
3. Save them as `icon16.png`, `icon48.png`, and `icon128.png` in the `icons/` folder

Alternatively, you can create your own icons using any image editor or icon generator.

## Permissions

- **storage**: Used to save portfolio data, balance, and API key locally

## API

This extension uses the [Financial Modeling Prep API](https://site.financialmodelingprep.com/) for stock data.

## Development

The extension uses Manifest V3, which requires:
- Service worker instead of background scripts
- Updated permission structure
- Modern Chrome extension APIs

## License

MIT License

