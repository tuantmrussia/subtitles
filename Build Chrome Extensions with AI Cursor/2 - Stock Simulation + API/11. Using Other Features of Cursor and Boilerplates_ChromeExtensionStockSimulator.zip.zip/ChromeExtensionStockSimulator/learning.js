// Learning & Quiz System for Stock Simulator

// Quiz questions about investing
const QUIZ_QUESTIONS = [
  {
    id: 'q1',
    category: 'Basics',
    question: 'What does "buy low, sell high" mean?',
    options: [
      'Purchase stocks when prices are low and sell when they rise',
      'Always buy the cheapest stocks',
      'Only trade during market lows',
      'Buy stocks once and never sell'
    ],
    correct: 0,
    explanation: 'The principle of buying low and selling high means purchasing assets when their prices are relatively low and selling them when prices have increased, aiming to profit from the price difference.'
  },
  {
    id: 'q2',
    category: 'Basics',
    question: 'What is diversification?',
    options: [
      'Investing all your money in one stock',
      'Spreading investments across different assets to reduce risk',
      'Only investing in technology stocks',
      'Trading every day'
    ],
    correct: 1,
    explanation: 'Diversification is an investment strategy that involves spreading your investments across different assets, sectors, or markets to reduce the risk of loss from any single investment.'
  },
  {
    id: 'q3',
    category: 'Basics',
    question: 'What is a portfolio?',
    options: [
      'A single stock investment',
      'A collection of investments owned by an individual',
      'A type of savings account',
      'A company\'s annual report'
    ],
    correct: 1,
    explanation: 'A portfolio is a collection of financial investments like stocks, bonds, and other assets owned by an individual or institution.'
  },
  {
    id: 'q4',
    category: 'Risk',
    question: 'What does P/E ratio stand for?',
    options: [
      'Price/Equity ratio',
      'Profit/Expense ratio',
      'Price/Earnings ratio',
      'Performance/Evaluation ratio'
    ],
    correct: 2,
    explanation: 'P/E ratio (Price-to-Earnings ratio) compares a company\'s stock price to its earnings per share, helping investors evaluate if a stock is overvalued or undervalued.'
  },
  {
    id: 'q5',
    category: 'Risk',
    question: 'What is market volatility?',
    options: [
      'How stable a stock price is',
      'The degree of variation in stock prices over time',
      'The total value of the market',
      'The number of trades per day'
    ],
    correct: 1,
    explanation: 'Market volatility refers to the degree of variation in stock prices over time. High volatility means prices change dramatically, while low volatility means prices are relatively stable.'
  },
  {
    id: 'q6',
    category: 'Risk',
    question: 'What is a stop-loss order?',
    options: [
      'An order to buy stocks at a specific price',
      'An order to automatically sell a stock if it drops to a certain price',
      'An order to stop trading for the day',
      'An order to double your position'
    ],
    correct: 1,
    explanation: 'A stop-loss order is a risk management tool that automatically sells a stock when it reaches a predetermined price, helping limit potential losses.'
  },
  {
    id: 'q7',
    category: 'Strategy',
    question: 'What is dollar-cost averaging?',
    options: [
      'Investing a fixed amount regularly regardless of price',
      'Investing only when prices are lowest',
      'Investing all money at once',
      'Only investing in expensive stocks'
    ],
    correct: 0,
    explanation: 'Dollar-cost averaging is an investment strategy where you invest a fixed amount of money at regular intervals, regardless of the stock price, which can help reduce the impact of volatility.'
  },
  {
    id: 'q8',
    category: 'Strategy',
    question: 'What does "long-term investing" typically mean?',
    options: [
      'Holding investments for a few days',
      'Holding investments for months or years',
      'Trading multiple times per day',
      'Only investing in short-term bonds'
    ],
    correct: 1,
    explanation: 'Long-term investing involves holding investments for extended periods (typically years) to benefit from compound growth and ride out short-term market fluctuations.'
  },
  {
    id: 'q9',
    category: 'Analysis',
    question: 'What is fundamental analysis?',
    options: [
      'Analyzing stock price charts only',
      'Evaluating a company\'s financial health and business fundamentals',
      'Following market trends',
      'Copying other investors\' trades'
    ],
    correct: 1,
    explanation: 'Fundamental analysis involves evaluating a company\'s financial statements, management, competitive advantages, and industry conditions to determine its intrinsic value.'
  },
  {
    id: 'q10',
    category: 'Analysis',
    question: 'What does "beta" measure in stocks?',
    options: [
      'A stock\'s total return',
      'A stock\'s volatility relative to the market',
      'A stock\'s dividend yield',
      'A stock\'s market capitalization'
    ],
    correct: 1,
    explanation: 'Beta measures a stock\'s volatility relative to the overall market. A beta of 1 means the stock moves with the market, while a beta greater than 1 means it\'s more volatile.'
  },
  {
    id: 'q11',
    category: 'Basics',
    question: 'What is the difference between a stock and a bond?',
    options: [
      'There is no difference',
      'Stocks represent ownership in a company; bonds are loans to a company',
      'Stocks are risk-free; bonds are risky',
      'Stocks pay dividends; bonds don\'t'
    ],
    correct: 1,
    explanation: 'Stocks represent ownership shares in a company, while bonds are debt instruments where you lend money to a company or government in exchange for interest payments.'
  },
  {
    id: 'q12',
    category: 'Risk',
    question: 'What is an emergency fund?',
    options: [
      'Money invested in stocks',
      'Savings set aside for unexpected expenses or emergencies',
      'A special trading account',
      'Money borrowed for investments'
    ],
    correct: 1,
    explanation: 'An emergency fund is cash savings set aside to cover unexpected expenses or financial emergencies, typically 3-6 months of living expenses, before investing in stocks.'
  },
  {
    id: 'q13',
    category: 'Strategy',
    question: 'What is compound interest?',
    options: [
      'Interest calculated only on the principal',
      'Interest calculated on both principal and previously earned interest',
      'Interest that compounds daily',
      'Interest from multiple sources'
    ],
    correct: 1,
    explanation: 'Compound interest is interest calculated on the initial principal and also on accumulated interest from previous periods, allowing investments to grow exponentially over time.'
  },
  {
    id: 'q14',
    category: 'Analysis',
    question: 'What does "market cap" mean?',
    options: [
      'The maximum price a stock can reach',
      'The total value of all a company\'s outstanding shares',
      'The capital needed to start trading',
      'The number of shares available'
    ],
    correct: 1,
    explanation: 'Market capitalization (market cap) is the total dollar market value of a company\'s outstanding shares, calculated by multiplying share price by number of shares.'
  },
  {
    id: 'q15',
    category: 'Basics',
    question: 'What is a dividend?',
    options: [
      'The total return on an investment',
      'A payment made by a company to its shareholders from profits',
      'The difference between buy and sell price',
      'A type of stock order'
    ],
    correct: 1,
    explanation: 'A dividend is a payment made by a corporation to its shareholders, usually as a distribution of profits, typically paid quarterly.'
  }
];

// Learning tips and educational content
const LEARNING_TIPS = [
  {
    title: 'Start with Diversification',
    content: 'Don\'t put all your eggs in one basket. Spread your investments across different sectors and companies to reduce risk.',
    category: 'Basics'
  },
  {
    title: 'Understand Risk vs. Reward',
    content: 'Higher potential returns usually come with higher risk. Assess your risk tolerance before investing.',
    category: 'Risk'
  },
  {
    title: 'Invest for the Long Term',
    content: 'Time in the market beats timing the market. Long-term investing typically yields better results than frequent trading.',
    category: 'Strategy'
  },
  {
    title: 'Do Your Research',
    content: 'Before investing, research the company\'s financials, management, competitive position, and industry trends.',
    category: 'Analysis'
  },
  {
    title: 'Practice Makes Perfect',
    content: 'This is a virtual trading simulator - perfect for learning without real financial risk. Experiment and learn from your decisions!',
    category: 'Basics'
  },
  {
    title: 'Avoid Emotional Trading',
    content: 'Don\'t let fear or greed drive your decisions. Stick to your strategy and avoid impulsive trades.',
    category: 'Strategy'
  },
  {
    title: 'Keep Learning',
    content: 'The stock market is complex. Continuously educate yourself about investing, market trends, and financial concepts.',
    category: 'Basics'
  },
  {
    title: 'Monitor Your Portfolio',
    content: 'Regularly review your investments, but avoid over-monitoring. Daily price fluctuations are normal.',
    category: 'Strategy'
  }
];

// Initialize learning/quiz data
async function initializeLearning() {
  const result = await chrome.storage.local.get(['quizScores', 'quizProgress', 'learningTips']);
  
  if (!result.quizScores) {
    await chrome.storage.local.set({
      quizScores: {},
      quizProgress: {},
      learningTips: []
    });
  }
}

// Get quiz scores
async function getQuizScores() {
  const result = await chrome.storage.local.get(['quizScores']);
  return result.quizScores || {};
}

// Save quiz score
async function saveQuizScore(quizId, score, totalQuestions) {
  const result = await chrome.storage.local.get(['quizScores']);
  const quizScores = result.quizScores || {};
  
  quizScores[quizId] = {
    score: score,
    totalQuestions: totalQuestions,
    percentage: Math.round((score / totalQuestions) * 100),
    completedAt: new Date().toISOString(),
    timestamp: Date.now()
  };
  
  await chrome.storage.local.set({ quizScores: quizScores });
  
  // Check for achievements related to learning
  const newAchievements = await checkAchievements();
  if (newAchievements.length > 0) {
    showAchievementNotification(newAchievements);
  }
}

// Get quiz progress
async function getQuizProgress() {
  const result = await chrome.storage.local.get(['quizProgress']);
  return result.quizProgress || {};
}

// Save quiz progress
async function saveQuizProgress(quizId, questionIndex, answers) {
  const result = await chrome.storage.local.get(['quizProgress']);
  const quizProgress = result.quizProgress || {};
  
  quizProgress[quizId] = {
    currentQuestion: questionIndex,
    answers: answers,
    lastUpdated: Date.now()
  };
  
  await chrome.storage.local.set({ quizProgress: quizProgress });
}

// Get all questions by category
function getQuestionsByCategory(category) {
  if (!category || category === 'All') {
    return QUIZ_QUESTIONS;
  }
  return QUIZ_QUESTIONS.filter(q => q.category === category);
}

// Get categories
function getCategories() {
  const categories = [...new Set(QUIZ_QUESTIONS.map(q => q.category))];
  return categories;
}

// Get random question
function getRandomQuestion() {
  const index = Math.floor(Math.random() * QUIZ_QUESTIONS.length);
  return QUIZ_QUESTIONS[index];
}

// Get learning tips
function getLearningTips(category = null) {
  if (!category || category === 'All') {
    return LEARNING_TIPS;
  }
  return LEARNING_TIPS.filter(tip => tip.category === category);
}

