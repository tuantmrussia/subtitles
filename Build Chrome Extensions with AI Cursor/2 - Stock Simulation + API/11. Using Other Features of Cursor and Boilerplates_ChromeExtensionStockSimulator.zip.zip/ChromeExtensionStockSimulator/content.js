// Content script for detecting stock symbols on web pages
// Detects stock tickers and shows "Add to Portfolio" buttons

(function() {
  'use strict';

  // Stock symbol pattern - matches common ticker formats (1-5 uppercase letters, possibly with dots)
  const STOCK_SYMBOL_PATTERN = /\b([A-Z]{1,5}(?:\.[A-Z]{1,3})?)\b/g;
  
  // Common finance sites where we should be more aggressive
  const FINANCE_SITES = [
    'finance.yahoo.com',
    'marketwatch.com',
    'bloomberg.com',
    'cnbc.com',
    'investing.com',
    'nasdaq.com',
    'nyse.com',
    'reuters.com',
    'wsj.com'
  ];

  // Known stock exchanges and common symbols to filter false positives
  const COMMON_TICKERS = new Set([
    'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'META', 'NVDA', 'BRK.B', 'UNH', 'JNJ',
    'V', 'PG', 'MA', 'HD', 'DIS', 'PYPL', 'BAC', 'VZ', 'ADBE', 'CMCSA',
    'KO', 'AVGO', 'COST', 'XOM', 'WMT', 'NFLX', 'CRM', 'CSCO', 'PEP', 'ABT',
    'NKE', 'MRK', 'TMO', 'ABBV', 'DHR', 'ACN', 'MCD', 'CVX', 'NEE', 'LLY',
    'SPY', 'QQQ', 'DIA', 'IWM', 'VTI', 'VOO', 'IVV', 'GLD', 'SLV', 'BTC'
  ]);

  // Symbols we've already processed (to avoid duplicates)
  const processedSymbols = new Set();
  
  // Buttons we've created
  const createdButtons = new Map();

  // Check if current site is a finance site
  function isFinanceSite() {
    const hostname = window.location.hostname.toLowerCase();
    return FINANCE_SITES.some(site => hostname.includes(site));
  }

  // Validate if a symbol looks like a real stock ticker
  function isValidTicker(symbol) {
    // Remove dots for validation
    const cleanSymbol = symbol.replace('.', '');
    
    // Basic checks
    if (cleanSymbol.length < 1 || cleanSymbol.length > 5) return false;
    if (!/^[A-Z]+$/.test(cleanSymbol)) return false;
    
    // If it's a known ticker, it's valid
    if (COMMON_TICKERS.has(symbol.toUpperCase())) return true;
    
    // For finance sites, be more lenient
    if (isFinanceSite()) {
      // Symbols in specific contexts are more likely to be real
      return cleanSymbol.length >= 2 && cleanSymbol.length <= 5;
    }
    
    // For other sites, require at least 2 characters and be more conservative
    return cleanSymbol.length >= 2 && cleanSymbol.length <= 5;
  }

  // Extract stock symbols from text
  function extractSymbols(text, element) {
    const symbols = new Set();
    const matches = text.matchAll(STOCK_SYMBOL_PATTERN);
    
    for (const match of matches) {
      const symbol = match[1].toUpperCase();
      
      // Skip if already processed or invalid
      if (processedSymbols.has(symbol) || !isValidTicker(symbol)) {
        continue;
      }
      
      // Skip common words that match the pattern
      const commonWords = ['HTML', 'CSS', 'API', 'URL', 'PDF', 'CEO', 'CFO', 'IPO', 'SEC', 'IRS', 'GDP', 'USA', 'UK', 'EU'];
      if (commonWords.includes(symbol)) {
        continue;
      }
      
      symbols.add(symbol);
    }
    
    return Array.from(symbols);
  }

  // Create "Add to Portfolio" button
  function createAddButton(symbol, element) {
    // Check if button already exists for this symbol+element combo
    const key = `${symbol}-${element.getBoundingClientRect().top}-${element.getBoundingClientRect().left}`;
    if (createdButtons.has(key)) {
      return;
    }

    const button = document.createElement('button');
    button.className = 'stock-simulator-add-btn';
    button.textContent = '+ Add to Portfolio';
    button.dataset.symbol = symbol;
    button.title = `Add ${symbol} to your portfolio`;
    
    // Style the button
    button.style.cssText = `
      position: absolute;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      border-radius: 4px;
      padding: 4px 8px;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      z-index: 10000;
      box-shadow: 0 2px 4px rgba(0,0,0,0.2);
      transition: all 0.2s;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      white-space: nowrap;
      pointer-events: auto;
    `;

    // Hover effects
    button.addEventListener('mouseenter', () => {
      button.style.transform = 'scale(1.05)';
      button.style.boxShadow = '0 4px 8px rgba(0,0,0,0.3)';
    });

    button.addEventListener('mouseleave', () => {
      button.style.transform = 'scale(1)';
      button.style.boxShadow = '0 2px 4px rgba(0,0,0,0.2)';
    });

    // Click handler
    button.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      button.disabled = true;
      button.textContent = 'Adding...';
      button.style.opacity = '0.7';

      try {
        await addStockToPortfolio(symbol);
        button.textContent = '✓ Added!';
        button.style.background = '#28a745';
        
        // Remove button after 2 seconds
        setTimeout(() => {
          button.remove();
          createdButtons.delete(key);
        }, 2000);
      } catch (error) {
        console.error('Error adding stock:', error);
        button.textContent = 'Error';
        button.style.background = '#dc3545';
        button.disabled = false;
        
        setTimeout(() => {
          button.textContent = '+ Add to Portfolio';
          button.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
          button.style.opacity = '1';
        }, 2000);
      }
    });

    // Position button relative to element
    const rect = element.getBoundingClientRect();
    const scrollX = window.pageXOffset || document.documentElement.scrollLeft;
    const scrollY = window.pageYOffset || document.documentElement.scrollTop;
    
    // Position to the right of the symbol
    button.style.left = `${rect.right + scrollX + 8}px`;
    button.style.top = `${rect.top + scrollY - 2}px`;

    // Add to page
    document.body.appendChild(button);
    createdButtons.set(key, button);

    // Clean up on scroll/resize
    const cleanup = () => {
      if (button.parentNode) {
        button.remove();
        createdButtons.delete(key);
      }
    };
    
    window.addEventListener('scroll', cleanup, { once: true });
    window.addEventListener('resize', cleanup, { once: true });
  }

  // Add stock to portfolio via message to background script
  async function addStockToPortfolio(symbol) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        {
          action: 'addStockToPortfolio',
          symbol: symbol
        },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else if (response && response.success) {
            resolve(response);
          } else {
            reject(new Error(response?.error || 'Failed to add stock'));
          }
        }
      );
    });
  }

  // Process text nodes and elements for stock symbols
  function processElement(element) {
    // Skip if already processed or in a button
    if (element.dataset.stockSimulatorProcessed || 
        element.closest('.stock-simulator-add-btn') ||
        element.classList.contains('stock-simulator-add-btn')) {
      return;
    }

    const text = element.textContent || '';
    const symbols = extractSymbols(text, element);

    if (symbols.length > 0) {
      // Mark as processed
      element.dataset.stockSimulatorProcessed = 'true';

      // For finance sites, be more selective - only show buttons on prominent elements
      if (isFinanceSite()) {
        const tagName = element.tagName?.toLowerCase();
        const isProminent = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'strong', 'b', 'span', 'a'].includes(tagName) ||
                           element.classList.contains('quote') ||
                           element.classList.contains('symbol') ||
                           element.classList.contains('ticker');
        
        if (!isProminent && symbols.length > 3) {
          // Too many symbols, likely not a stock reference
          return;
        }
      }

      // Create buttons for found symbols
      symbols.forEach(symbol => {
        // Check if symbol appears in a clickable link (common on finance sites)
        const linkElement = element.closest('a') || element;
        createAddButton(symbol, linkElement);
        processedSymbols.add(symbol);
      });
    }
  }

  // Observer for dynamically added content
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          // Process the new node
          processElement(node);
          
          // Process all text nodes within
          const walker = document.createTreeWalker(
            node,
            NodeFilter.SHOW_TEXT,
            null,
            false
          );

          let textNode;
          while (textNode = walker.nextNode()) {
            if (textNode.parentElement) {
              processElement(textNode.parentElement);
            }
          }
        } else if (node.nodeType === Node.TEXT_NODE && node.parentElement) {
          processElement(node.parentElement);
        }
      });
    });
  });

  // Initial scan of the page
  function scanPage() {
    // Process headings and prominent elements first
    const prominentSelectors = isFinanceSite() 
      ? 'h1, h2, h3, h4, h5, h6, [class*="symbol"], [class*="ticker"], [class*="quote"], a[href*="/quote/"], a[href*="/symbol/"]'
      : 'h1, h2, h3, h4, h5, h6, strong, b';

    document.querySelectorAll(prominentSelectors).forEach(processElement);

    // Then process other text elements (but limit on non-finance sites)
    if (isFinanceSite()) {
      document.querySelectorAll('p, span, div, td, th').forEach((el, index) => {
        // Limit processing to avoid performance issues
        if (index < 100) {
          processElement(el);
        }
      });
    }
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(scanPage, 1000); // Wait a bit for dynamic content
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    });
  } else {
    setTimeout(scanPage, 1000);
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  // Clean up buttons on navigation (for SPAs)
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      // Clear processed symbols and buttons
      processedSymbols.clear();
      createdButtons.forEach(button => button.remove());
      createdButtons.clear();
      // Rescan after a delay
      setTimeout(scanPage, 1000);
    }
  }).observe(document, { subtree: true, childList: true });

})();

