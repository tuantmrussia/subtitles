// Achievements & Gamification System for Stock Simulator

// Achievement definitions
const ACHIEVEMENTS = {
  FIRST_TRADE: {
    id: 'first_trade',
    name: 'First Trade',
    description: 'Complete your first stock trade',
    icon: '🎯',
    points: 10,
    check: async (data) => {
      const transactions = data.transactions || [];
      return transactions.length > 0;
    }
  },
  INVESTED_1000: {
    id: 'invested_1000',
    name: 'Investor',
    description: 'Invest $1,000 in stocks',
    icon: '💰',
    points: 25,
    check: async (data) => {
      const portfolio = data.portfolio || [];
      const initialBalance = data.initialBalance || 100000;
      const balance = data.balance || initialBalance;
      const invested = initialBalance - balance;
      return invested >= 1000;
    }
  },
  INVESTED_10000: {
    id: 'invested_10000',
    name: 'Big Investor',
    description: 'Invest $10,000 in stocks',
    icon: '💎',
    points: 50,
    check: async (data) => {
      const portfolio = data.portfolio || [];
      const initialBalance = data.initialBalance || 100000;
      const balance = data.balance || initialBalance;
      const invested = initialBalance - balance;
      return invested >= 10000;
    }
  },
  PORTFOLIO_PLUS_10: {
    id: 'portfolio_plus_10',
    name: 'Green Portfolio',
    description: 'Achieve +10% portfolio return',
    icon: '📈',
    points: 30,
    check: async (data) => {
      const portfolio = data.portfolio || [];
      const balance = data.balance || 100000;
      const initialBalance = data.initialBalance || 100000;
      
      // Calculate portfolio value using current prices
      let portfolioValue = balance;
      portfolio.forEach(stock => {
        // Use currentPrice if available, otherwise use purchasePrice
        const price = stock.currentPrice || stock.purchasePrice;
        portfolioValue += price * stock.shares;
      });
      
      const returnPercent = initialBalance > 0 ? ((portfolioValue - initialBalance) / initialBalance) * 100 : 0;
      return returnPercent >= 10;
    }
  },
  PORTFOLIO_PLUS_25: {
    id: 'portfolio_plus_25',
    name: 'Rising Star',
    description: 'Achieve +25% portfolio return',
    icon: '⭐',
    points: 75,
    check: async (data) => {
      const portfolio = data.portfolio || [];
      const balance = data.balance || 100000;
      const initialBalance = data.initialBalance || 100000;
      
      let portfolioValue = balance;
      portfolio.forEach(stock => {
        const price = stock.currentPrice || stock.purchasePrice;
        portfolioValue += price * stock.shares;
      });
      
      const returnPercent = initialBalance > 0 ? ((portfolioValue - initialBalance) / initialBalance) * 100 : 0;
      return returnPercent >= 25;
    }
  },
  PORTFOLIO_PLUS_50: {
    id: 'portfolio_plus_50',
    name: 'Market Master',
    description: 'Achieve +50% portfolio return',
    icon: '🏆',
    points: 150,
    check: async (data) => {
      const portfolio = data.portfolio || [];
      const balance = data.balance || 100000;
      const initialBalance = data.initialBalance || 100000;
      
      let portfolioValue = balance;
      portfolio.forEach(stock => {
        const price = stock.currentPrice || stock.purchasePrice;
        portfolioValue += price * stock.shares;
      });
      
      const returnPercent = initialBalance > 0 ? ((portfolioValue - initialBalance) / initialBalance) * 100 : 0;
      return returnPercent >= 50;
    }
  },
  PORTFOLIO_PLUS_100: {
    id: 'portfolio_plus_100',
    name: 'Legend',
    description: 'Double your portfolio! (+100% return)',
    icon: '👑',
    points: 300,
    check: async (data) => {
      const portfolio = data.portfolio || [];
      const balance = data.balance || 100000;
      const initialBalance = data.initialBalance || 100000;
      
      let portfolioValue = balance;
      portfolio.forEach(stock => {
        const price = stock.currentPrice || stock.purchasePrice;
        portfolioValue += price * stock.shares;
      });
      
      const returnPercent = initialBalance > 0 ? ((portfolioValue - initialBalance) / initialBalance) * 100 : 0;
      return returnPercent >= 100;
    }
  },
  TEN_TRADES: {
    id: 'ten_trades',
    name: 'Active Trader',
    description: 'Complete 10 trades',
    icon: '🔄',
    points: 20,
    check: async (data) => {
      const transactions = data.transactions || [];
      return transactions.length >= 10;
    }
  },
  FIFTY_TRADES: {
    id: 'fifty_trades',
    name: 'Power Trader',
    description: 'Complete 50 trades',
    icon: '⚡',
    points: 60,
    check: async (data) => {
      const transactions = data.transactions || [];
      return transactions.length >= 50;
    }
  },
  HUNDRED_TRADES: {
    id: 'hundred_trades',
    name: 'Trading Veteran',
    description: 'Complete 100 trades',
    icon: '🎖️',
    points: 100,
    check: async (data) => {
      const transactions = data.transactions || [];
      return transactions.length >= 100;
    }
  },
  DIVERSIFIED: {
    id: 'diversified',
    name: 'Diversified',
    description: 'Hold 5 different stocks at once',
    icon: '📊',
    points: 40,
    check: async (data) => {
      const portfolio = data.portfolio || [];
      return portfolio.length >= 5;
    }
  },
  PROFIT_1000: {
    id: 'profit_1000',
    name: 'Profit Maker',
    description: 'Realize $1,000 in profit',
    icon: '💵',
    points: 50,
    check: async (data) => {
      const transactions = data.transactions || [];
      const totalProfit = transactions
        .filter(t => t.type === 'SELL' && t.realizedPL)
        .reduce((sum, t) => sum + (t.realizedPL || 0), 0);
      return totalProfit >= 1000;
    }
  },
  PROFIT_10000: {
    id: 'profit_10000',
    name: 'Big Winner',
    description: 'Realize $10,000 in profit',
    icon: '💸',
    points: 150,
    check: async (data) => {
      const transactions = data.transactions || [];
      const totalProfit = transactions
        .filter(t => t.type === 'SELL' && t.realizedPL)
        .reduce((sum, t) => sum + (t.realizedPL || 0), 0);
      return totalProfit >= 10000;
    }
  }
};

// Initialize achievements storage
async function initializeAchievements() {
  const result = await chrome.storage.local.get(['achievements', 'totalPoints']);
  
  if (!result.achievements) {
    await chrome.storage.local.set({
      achievements: [],
      totalPoints: 0
    });
  }
}

// Get earned achievements
async function getEarnedAchievements() {
  const result = await chrome.storage.local.get(['achievements']);
  return result.achievements || [];
}

// Check for new achievements
async function checkAchievements() {
  // Get current profile to check achievements for the active profile
  const profileResult = await chrome.storage.local.get(['currentProfile', 'profiles']);
  const currentProfile = profileResult.currentProfile || 'default';
  const profiles = profileResult.profiles || {};
  const profileData = profiles[currentProfile] || {};
  
  // Get current portfolio data from active profile
  const data = {
    portfolio: profileData.portfolio || [],
    balance: profileData.balance || 100000,
    initialBalance: profileData.initialBalance || 100000,
    transactions: profileData.transactions || []
  };
  
  // Get already earned achievements (global, not per-profile)
  const earned = await getEarnedAchievements();
  const earnedIds = new Set(earned.map(a => a.id));
  
  // Check each achievement
  const newAchievements = [];
  
  for (const [key, achievement] of Object.entries(ACHIEVEMENTS)) {
    // Skip if already earned
    if (earnedIds.has(achievement.id)) {
      continue;
    }
    
    // Check if achievement is earned
    try {
      const isEarned = await achievement.check(data);
      if (isEarned) {
        const achievementData = {
          id: achievement.id,
          name: achievement.name,
          description: achievement.description,
          icon: achievement.icon,
          points: achievement.points,
          earnedAt: new Date().toISOString(),
          timestamp: Date.now(),
          profile: currentProfile // Track which profile earned it
        };
        
        newAchievements.push(achievementData);
        
        // Add to earned achievements
        earned.push(achievementData);
      }
    } catch (error) {
      console.error(`Error checking achievement ${achievement.id}:`, error);
    }
  }
  
  // Update storage if new achievements - save to chrome.storage.local
  if (newAchievements.length > 0) {
    const result = await chrome.storage.local.get(['totalPoints']);
    const totalPoints = (result.totalPoints || 0) + newAchievements.reduce((sum, a) => sum + a.points, 0);
    
    await chrome.storage.local.set({
      achievements: earned,
      totalPoints: totalPoints
    });
  }
  
  return newAchievements;
}

// Get total points
async function getTotalPoints() {
  const result = await chrome.storage.local.get(['totalPoints']);
  return result.totalPoints || 0;
}

// Get achievement progress (for achievements with multiple levels)
function getAchievementProgress(achievementId, data) {
  // This can be extended for achievements with progress tracking
  return null;
}

