// Options page script

document.addEventListener('DOMContentLoaded', async () => {
  // Load saved settings
  const result = await chrome.storage.local.get(['apiKey', 'apiProvider']);
  
  // Set default to Alpha Vantage if not set
  if (!result.apiProvider) {
    document.getElementById('apiProvider').value = 'alphavantage';
  } else {
    document.getElementById('apiProvider').value = result.apiProvider;
  }
  
  // Load existing API key if set
  if (result.apiKey) {
    document.getElementById('apiKey').value = result.apiKey;
  }

  // Update help text when provider changes
  document.getElementById('apiProvider').addEventListener('change', updateAPIKeyHelp);

  // Save button
  document.getElementById('saveButton').addEventListener('click', saveSettings);

  // Reset button
  document.getElementById('resetButton').addEventListener('click', resetPortfolio);

  // Initialize help text
  updateAPIKeyHelp();
});

function updateAPIKeyHelp() {
  const provider = document.getElementById('apiProvider').value;
  const helpText = document.getElementById('apiKeyHelp');
  
  if (provider === 'alphavantage') {
    helpText.innerHTML = `
      Get your free API key from 
      <a href="https://www.alphavantage.co/support/#api-key" target="_blank">Alpha Vantage</a>
      <br>
      <small style="color: #6c757d;">Note: Free tier allows 5 API calls per minute and 500 calls per day</small>
    `;
  } else {
    helpText.innerHTML = `
      Get your free API key from 
      <a href="https://site.financialmodelingprep.com/developer/docs/" target="_blank">Financial Modeling Prep</a>
      <br>
      <small style="color: #6c757d;">Note: Free tier offers 250 requests per day</small>
    `;
  }
}

async function saveSettings() {
  const apiKey = document.getElementById('apiKey').value.trim();
  const apiProvider = document.getElementById('apiProvider').value;
  
  if (!apiKey) {
    alert('Please enter an API key');
    return;
  }

  // Validate API key if possible
  try {
    if (typeof StockAPIService !== 'undefined') {
      const apiService = new StockAPIService(apiProvider, apiKey);
      const isValid = await apiService.validateAPIKey();
      
      if (!isValid) {
        if (!confirm('API key validation failed. Do you want to save it anyway?')) {
          return;
        }
      }
    }
  } catch (error) {
    console.error('Error validating API key:', error);
    // Continue anyway - user might have entered a valid key
  }
  
  await chrome.storage.local.set({ 
    apiKey: apiKey,
    apiProvider: apiProvider
  });
  
  // Show success message
  const successMessage = document.getElementById('successMessage');
  successMessage.textContent = 'Settings saved successfully!';
  successMessage.classList.add('show');
  
  setTimeout(() => {
    successMessage.classList.remove('show');
  }, 3000);
}

async function resetPortfolio() {
  if (confirm('Are you sure you want to reset your portfolio? This will delete all your stocks and reset your balance to $10,000. This action cannot be undone.')) {
    // Get current profile to reset the correct profile
    const result = await chrome.storage.local.get(['currentProfile', 'profiles']);
    const currentProfile = result.currentProfile || 'default';
    const profiles = result.profiles || {};
    
    // Reset the current profile's data
    if (!profiles[currentProfile]) {
      profiles[currentProfile] = {};
    }
    
    profiles[currentProfile].portfolio = [];
    profiles[currentProfile].balance = 10000;
    profiles[currentProfile].initialBalance = 10000;
    profiles[currentProfile].transactions = [];
    profiles[currentProfile].portfolioHistory = [];
    
    // Save to chrome.storage.local
    await chrome.storage.local.set({ profiles: profiles });
    
    alert('Portfolio has been reset successfully!');
  }
}

