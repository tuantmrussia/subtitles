// API Service for Stock Simulator Extension
// Supports both Alpha Vantage and Financial Modeling Prep APIs

class StockAPIService {
  constructor(provider, apiKey) {
    this.provider = provider || 'alphavantage'; // 'alphavantage' or 'fmp'
    this.apiKey = apiKey;
  }

  // Fetch real-time quote for a stock symbol
  async fetchQuote(symbol) {
    try {
      if (this.provider === 'alphavantage') {
        return await this.fetchAlphaVantageQuote(symbol);
      } else {
        return await this.fetchFMPQuote(symbol);
      }
    } catch (error) {
      console.error('Error fetching quote:', error);
      throw error;
    }
  }

  // Fetch multiple quotes at once
  async fetchQuotes(symbols) {
    try {
      if (this.provider === 'alphavantage') {
        // Alpha Vantage doesn't support batch quotes, fetch individually
        const promises = symbols.map(symbol => this.fetchAlphaVantageQuote(symbol));
        return await Promise.all(promises);
      } else {
        return await this.fetchFMPQuotes(symbols);
      }
    } catch (error) {
      console.error('Error fetching quotes:', error);
      throw error;
    }
  }

  // Fetch company profile/overview
  async fetchCompanyProfile(symbol) {
    try {
      if (this.provider === 'alphavantage') {
        return await this.fetchAlphaVantageOverview(symbol);
      } else {
        return await this.fetchFMPProfile(symbol);
      }
    } catch (error) {
      console.error('Error fetching company profile:', error);
      throw error;
    }
  }

  // Fetch historical data
  async fetchHistoricalData(symbol, range = '6M') {
    try {
      if (this.provider === 'alphavantage') {
        return await this.fetchAlphaVantageHistorical(symbol, range);
      } else {
        return await this.fetchFMPHistorical(symbol, range);
      }
    } catch (error) {
      console.error('Error fetching historical data:', error);
      throw error;
    }
  }

  // Alpha Vantage API Methods
  // Fetches real-time quote data using GLOBAL_QUOTE endpoint
  async fetchAlphaVantageQuote(symbol) {
    if (!this.apiKey) {
      throw new Error('API key not configured');
    }

    const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${this.apiKey}`;
    
    try {
      const response = await fetch(url);
      
      if (!response.ok) {
        // Handle rate limiting (429 Too Many Requests)
        if (response.status === 429) {
          throw new Error('API rate limit exceeded. Please wait a moment and try again.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();

      // Check for API errors
      if (data['Error Message'] || data['Note']) {
        throw new Error(data['Error Message'] || data['Note'] || 'API Error');
      }

      const quote = data['Global Quote'];
      if (!quote || !quote['05. price']) {
        throw new Error('Invalid response from API - missing quote data');
      }

      // Parse and extract all quote fields (price, volume, OHLC)
      return {
        symbol: quote['01. symbol'] || symbol,
        name: quote['01. symbol'] || symbol, // Alpha Vantage quote doesn't include company name
        price: parseFloat(quote['05. price']) || 0,
        change: parseFloat(quote['09. change']) || 0,
        changePercent: parseFloat((quote['10. change percent'] || '0').replace('%', '')) || 0,
        volume: parseInt(quote['06. volume']) || 0,
        high: parseFloat(quote['03. high']) || 0,
        low: parseFloat(quote['04. low']) || 0,
        open: parseFloat(quote['02. open']) || 0,
        previousClose: parseFloat(quote['08. previous close']) || 0
      };
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error('Invalid JSON response from API');
      }
      throw error;
    }
  }

  async fetchAlphaVantageOverview(symbol) {
    if (!this.apiKey) {
      throw new Error('API key not configured');
    }

    const url = `https://www.alphavantage.co/query?function=OVERVIEW&symbol=${symbol}&apikey=${this.apiKey}`;
    const response = await fetch(url);
    const data = await response.json();

    if (data['Error Message'] || data['Note']) {
      throw new Error(data['Error Message'] || data['Note'] || 'API Error');
    }

    if (!data.Symbol) {
      throw new Error('Invalid response from API');
    }

    return {
      symbol: data.Symbol,
      name: data.Name || symbol,
      description: data.Description || '',
      sector: data.Sector || '',
      industry: data.Industry || '',
      marketCap: parseFloat(data.MarketCapitalization) || 0,
      peRatio: parseFloat(data.PERatio) || 0,
      dividendYield: parseFloat(data.DividendYield) || 0,
      eps: parseFloat(data.EPS) || 0,
      beta: parseFloat(data.Beta) || 0,
      ceo: data.CEO || '',
      address: data.Address || '',
      exchange: data.Exchange || ''
    };
  }

  // Fetches historical time-series data with OHLCV (Open/High/Low/Close/Volume)
  async fetchAlphaVantageHistorical(symbol, range) {
    if (!this.apiKey) {
      throw new Error('API key not configured');
    }

    // Map range to Alpha Vantage function
    let functionName = 'TIME_SERIES_DAILY'; // Default
    const rangeMap = {
      '1W': 'TIME_SERIES_INTRADAY',
      '1M': 'TIME_SERIES_DAILY',
      '6M': 'TIME_SERIES_DAILY',
      '1Y': 'TIME_SERIES_DAILY',
      '5Y': 'TIME_SERIES_DAILY'
    };

    functionName = rangeMap[range] || 'TIME_SERIES_DAILY';

    let url;
    if (functionName === 'TIME_SERIES_INTRADAY') {
      url = `https://www.alphavantage.co/query?function=${functionName}&symbol=${symbol}&interval=60min&apikey=${this.apiKey}`;
    } else {
      url = `https://www.alphavantage.co/query?function=${functionName}&symbol=${symbol}&apikey=${this.apiKey}`;
    }

    try {
      const response = await fetch(url);
      
      if (!response.ok) {
        // Handle rate limiting (429 Too Many Requests)
        if (response.status === 429) {
          throw new Error('API rate limit exceeded. Please wait a moment and try again.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();

      if (data['Error Message'] || data['Note']) {
        throw new Error(data['Error Message'] || data['Note'] || 'API Error');
      }

      // Extract time series data - look for the time series key in response
      const timeSeriesKey = Object.keys(data).find(key => key.includes('Time Series'));
      if (!timeSeriesKey || !data[timeSeriesKey]) {
        throw new Error('Invalid response from API - missing time series data');
      }

      const timeSeries = data[timeSeriesKey];
      const dates = Object.keys(timeSeries).sort().reverse();

      // Limit to requested range (extract appropriate amount of daily data)
      let limit = 252; // Default to 1 year of trading days
      if (range === '1W') limit = 7;
      else if (range === '1M') limit = 30;
      else if (range === '6M') limit = 126;
      else if (range === '1Y') limit = 252;
      else if (range === '5Y') limit = 1260;

      // Parse JSON and extract OHLCV fields for each date
      const historicalData = dates.slice(0, limit).map(date => {
        const dayData = timeSeries[date];
        return {
          date: date,
          open: parseFloat(dayData['1. open']) || 0,
          high: parseFloat(dayData['2. high']) || 0,
          low: parseFloat(dayData['3. low']) || 0,
          close: parseFloat(dayData['4. close']) || 0,
          volume: parseInt(dayData['5. volume']) || 0
        };
      }).filter(item => item.close > 0); // Filter out invalid data points

      return historicalData.reverse(); // Return chronological order (oldest first)
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error('Invalid JSON response from API');
      }
      throw error;
    }
  }

  // Financial Modeling Prep API Methods
  // Fetches real-time quote data with volume and OHLC
  async fetchFMPQuote(symbol) {
    if (!this.apiKey) {
      throw new Error('API key not configured');
    }

    const url = `https://financialmodelingprep.com/api/v3/quote/${symbol}?apikey=${this.apiKey}`;
    
    try {
      const response = await fetch(url);
      
      if (!response.ok) {
        // Handle rate limiting (429 Too Many Requests)
        if (response.status === 429) {
          throw new Error('API rate limit exceeded. Please wait a moment and try again.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();

      if (data['Error Message'] || (Array.isArray(data) && data.length === 0)) {
        throw new Error(data['Error Message'] || 'Stock not found');
      }

      if (!Array.isArray(data) || !data[0]) {
        throw new Error('Invalid response from API - expected array with quote data');
      }

      // Parse JSON and extract quote fields (price, volume, OHLC)
      const quote = data[0];
      return {
        symbol: quote.symbol || symbol,
        name: quote.name || symbol,
        price: parseFloat(quote.price) || 0,
        change: parseFloat(quote.change) || 0,
        changePercent: parseFloat(quote.changesPercentage) || 0,
        volume: parseInt(quote.volume) || 0,
        high: parseFloat(quote.dayHigh || quote.high) || 0,
        low: parseFloat(quote.dayLow || quote.low) || 0,
        open: parseFloat(quote.open) || 0,
        previousClose: parseFloat(quote.previousClose) || 0,
        marketCap: parseFloat(quote.marketCap) || 0,
        yearHigh: parseFloat(quote.yearHigh) || 0,
        yearLow: parseFloat(quote.yearLow) || 0,
        peRatio: parseFloat(quote.pe) || 0,
        eps: parseFloat(quote.eps) || 0
      };
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error('Invalid JSON response from API');
      }
      throw error;
    }
  }

  async fetchFMPQuotes(symbols) {
    if (!this.apiKey) {
      throw new Error('API key not configured');
    }

    const symbolsStr = Array.isArray(symbols) ? symbols.join(',') : symbols;
    const url = `https://financialmodelingprep.com/api/v3/quote/${symbolsStr}?apikey=${this.apiKey}`;
    
    try {
      const response = await fetch(url);
      
      if (!response.ok) {
        // Handle rate limiting (429 Too Many Requests)
        if (response.status === 429) {
          throw new Error('API rate limit exceeded. Please wait a moment and try again.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();

      if (data['Error Message'] || !Array.isArray(data)) {
        throw new Error(data['Error Message'] || 'Invalid response from API');
      }

      return data.map(quote => ({
        symbol: quote.symbol,
        name: quote.name || quote.symbol,
        price: quote.price || 0,
        change: quote.change || 0,
        changePercent: quote.changesPercentage || 0,
        volume: quote.volume || 0,
        high: quote.dayHigh || quote.high || 0,
        low: quote.dayLow || quote.low || 0,
        open: quote.open || 0,
        previousClose: quote.previousClose || 0
      }));
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error('Invalid JSON response from API');
      }
      throw error;
    }
  }

  async fetchFMPProfile(symbol) {
    if (!this.apiKey) {
      throw new Error('API key not configured');
    }

    const url = `https://financialmodelingprep.com/api/v3/profile/${symbol}?apikey=${this.apiKey}`;
    
    try {
      const response = await fetch(url);
      
      if (!response.ok) {
        // Handle rate limiting (429 Too Many Requests)
        if (response.status === 429) {
          throw new Error('API rate limit exceeded. Please wait a moment and try again.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();

      if (data['Error Message'] || (Array.isArray(data) && data.length === 0)) {
        throw new Error(data['Error Message'] || 'Company profile not found');
      }

      if (!Array.isArray(data) || !data[0]) {
        throw new Error('Invalid response from API');
      }

      const profile = data[0];
      return {
        symbol: profile.symbol,
        name: profile.companyName || profile.symbol,
        description: profile.description || '',
        sector: profile.sector || '',
        industry: profile.industry || '',
        marketCap: profile.mktCap || 0,
        peRatio: profile.pe || 0,
        dividendYield: profile.lastDiv || 0,
        beta: profile.beta || 0,
        ceo: profile.ceo || '',
        address: `${profile.address || ''} ${profile.city || ''} ${profile.state || ''} ${profile.zip || ''}`.trim(),
        exchange: profile.exchangeShortName || '',
        website: profile.website || '',
        image: profile.image || '',
        fullTimeEmployees: profile.fullTimeEmployees || 0
      };
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error('Invalid JSON response from API');
      }
      throw error;
    }
  }

  // Fetches historical daily data with OHLCV for requested time range
  async fetchFMPHistorical(symbol, range) {
    if (!this.apiKey) {
      throw new Error('API key not configured');
    }

    // Determine date range based on requested period
    const endDate = new Date();
    const startDate = new Date();
    
    if (range === '1W') {
      startDate.setDate(endDate.getDate() - 7);
    } else if (range === '1M') {
      startDate.setMonth(endDate.getMonth() - 1);
    } else if (range === '6M') {
      startDate.setMonth(endDate.getMonth() - 6);
    } else if (range === '1Y') {
      startDate.setFullYear(endDate.getFullYear() - 1);
    } else if (range === '5Y') {
      startDate.setFullYear(endDate.getFullYear() - 5);
    }

    // Format dates as YYYY-MM-DD for API request
    const formatDate = (date) => {
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    };

    const fromDate = formatDate(startDate);
    const toDate = formatDate(endDate);

    // Call historical-price-full endpoint to get daily OHLCV data
    const url = `https://financialmodelingprep.com/api/v3/historical-price-full/${symbol}?from=${fromDate}&to=${toDate}&apikey=${this.apiKey}`;
    
    try {
      const response = await fetch(url);
      
      if (!response.ok) {
        // Handle rate limiting (429 Too Many Requests)
        if (response.status === 429) {
          throw new Error('API rate limit exceeded. Please wait a moment and try again.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();

      if (data['Error Message'] || !data.historical) {
        throw new Error(data['Error Message'] || 'Historical data not found');
      }

      if (!Array.isArray(data.historical)) {
        throw new Error('Invalid response from API - expected historical array');
      }

      // Parse JSON and extract OHLCV fields for each date
      return data.historical.map(item => ({
        date: item.date || '',
        open: parseFloat(item.open) || 0,
        high: parseFloat(item.high) || 0,
        low: parseFloat(item.low) || 0,
        close: parseFloat(item.close) || 0,
        volume: parseInt(item.volume) || 0
      })).filter(item => item.close > 0) // Filter out invalid data points
        .reverse(); // Return chronological order (oldest first)
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error('Invalid JSON response from API');
      }
      throw error;
    }
  }

  // Search for stocks by symbol or company name
  async searchStocks(query) {
    try {
      if (this.provider === 'alphavantage') {
        return await this.searchAlphaVantage(query);
      } else {
        return await this.searchFMP(query);
      }
    } catch (error) {
      console.error('Error searching stocks:', error);
      throw error;
    }
  }

  // Alpha Vantage search (uses SYMBOL_SEARCH endpoint)
  async searchAlphaVantage(query) {
    if (!this.apiKey) {
      throw new Error('API key not configured');
    }

    const url = `https://www.alphavantage.co/query?function=SYMBOL_SEARCH&keywords=${encodeURIComponent(query)}&apikey=${this.apiKey}`;
    
    try {
      const response = await fetch(url);
      if (!response.ok) {
        // Handle rate limiting (429 Too Many Requests)
        if (response.status === 429) {
          throw new Error('API rate limit exceeded. Please wait a moment and try again.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data['Error Message'] || data['Note']) {
        throw new Error(data['Error Message'] || data['Note'] || 'API Error');
      }

      if (!data.bestMatches || !Array.isArray(data.bestMatches)) {
        return [];
      }

      return data.bestMatches.slice(0, 10).map(match => ({
        symbol: match['1. symbol'],
        name: match['2. name'],
        type: match['3. type'],
        region: match['4. region'],
        marketOpen: match['5. marketOpen'],
        marketClose: match['6. marketClose'],
        timezone: match['7. timezone'],
        currency: match['8. currency'],
        matchScore: parseFloat(match['9. matchScore']) || 0
      }));
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error('Invalid JSON response from API');
      }
      throw error;
    }
  }

  // Financial Modeling Prep search
  async searchFMP(query) {
    if (!this.apiKey) {
      throw new Error('API key not configured');
    }

    const url = `https://financialmodelingprep.com/api/v3/search?query=${encodeURIComponent(query)}&limit=10&apikey=${this.apiKey}`;
    
    try {
      const response = await fetch(url);
      if (!response.ok) {
        // Handle rate limiting (429 Too Many Requests)
        if (response.status === 429) {
          throw new Error('API rate limit exceeded. Please wait a moment and try again.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data['Error Message'] || !Array.isArray(data)) {
        return [];
      }

      return data.map(match => ({
        symbol: match.symbol,
        name: match.name,
        currency: match.currency,
        stockExchange: match.stockExchange,
        exchangeShortName: match.exchangeShortName
      }));
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error('Invalid JSON response from API');
      }
      throw error;
    }
  }

  // Validate API key
  async validateAPIKey() {
    try {
      // Test with a common stock symbol
      const testSymbol = 'AAPL';
      await this.fetchQuote(testSymbol);
      return true;
    } catch (error) {
      return false;
    }
  }
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
  module.exports = StockAPIService;
}

