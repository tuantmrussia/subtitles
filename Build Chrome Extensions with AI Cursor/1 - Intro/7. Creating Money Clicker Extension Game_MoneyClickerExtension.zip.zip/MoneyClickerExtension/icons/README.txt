Place your extension icons here:
- icon16.png (16x16 pixels)
- icon48.png (48x48 pixels)
- icon128.png (128x128 pixels)

You can create these icons using any image editor, or use online icon generators.
The icons should represent your extension's theme (money, clicking, gambling, etc.).


