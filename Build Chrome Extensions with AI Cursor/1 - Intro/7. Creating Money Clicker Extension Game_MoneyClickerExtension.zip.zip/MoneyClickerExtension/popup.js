// Sound Manager using Web Audio API
const SoundManager = {
  audioContext: null,
  
  init() {
    try {
      this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
    } catch (e) {
      console.warn('Web Audio API not supported:', e);
    }
  },
  
  playTone(frequency, duration, type = 'sine', volume = 0.3) {
    if (!this.audioContext) {
      this.init();
      if (!this.audioContext) return;
    }
    
    // Resume audio context if suspended (required by browser autoplay policies)
    if (this.audioContext.state === 'suspended') {
      this.audioContext.resume();
    }
    
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);
    
    oscillator.frequency.value = frequency;
    oscillator.type = type;
    
    gainNode.gain.setValueAtTime(volume, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration);
    
    oscillator.start(this.audioContext.currentTime);
    oscillator.stop(this.audioContext.currentTime + duration);
  },
  
  playClickSound() {
    // Short, sharp click sound
    this.playTone(800, 0.05, 'square', 0.2);
    setTimeout(() => {
      this.playTone(1000, 0.05, 'square', 0.15);
    }, 10);
  },
  
  playPurchaseSound() {
    // Success/purchase sound - ascending tones
    this.playTone(400, 0.1, 'sine', 0.25);
    setTimeout(() => {
      this.playTone(600, 0.1, 'sine', 0.25);
    }, 80);
    setTimeout(() => {
      this.playTone(800, 0.15, 'sine', 0.3);
    }, 160);
  },
  
  playSlotsSpinSound() {
    // Spinning sound - descending tone
    this.playTone(300, 0.1, 'sawtooth', 0.2);
  },
  
  playSlotsWinSound() {
    // Victory fanfare
    this.playTone(523, 0.15, 'sine', 0.3); // C
    setTimeout(() => {
      this.playTone(659, 0.15, 'sine', 0.3); // E
    }, 100);
    setTimeout(() => {
      this.playTone(784, 0.2, 'sine', 0.35); // G
    }, 200);
  },
  
  playSlotsLoseSound() {
    // Disappointing sound
    this.playTone(200, 0.2, 'sawtooth', 0.2);
  },
  
  playScratchSound() {
    // Scratch/scratchy sound
    this.playTone(150, 0.05, 'sawtooth', 0.15);
    setTimeout(() => {
      this.playTone(180, 0.05, 'sawtooth', 0.15);
    }, 20);
    setTimeout(() => {
      this.playTone(200, 0.05, 'sawtooth', 0.15);
    }, 40);
  },
  
  playScratchWinSound() {
    // Winning sound for scratch card
    this.playTone(600, 0.1, 'sine', 0.3);
    setTimeout(() => {
      this.playTone(800, 0.15, 'sine', 0.35);
    }, 100);
    setTimeout(() => {
      this.playTone(1000, 0.2, 'sine', 0.4);
    }, 200);
  },
  
  playScratchLoseSound() {
    // Losing sound for scratch card
    this.playTone(250, 0.15, 'sawtooth', 0.2);
  },
  
  playRouletteSpinSound() {
    // Roulette wheel spinning sound
    this.playTone(250, 0.08, 'sawtooth', 0.2);
    setTimeout(() => {
      this.playTone(280, 0.08, 'sawtooth', 0.2);
    }, 50);
  },
  
  playRouletteWinSound() {
    // Big win sound
    this.playTone(440, 0.1, 'sine', 0.3); // A
    setTimeout(() => {
      this.playTone(554, 0.1, 'sine', 0.3); // C#
    }, 80);
    setTimeout(() => {
      this.playTone(659, 0.15, 'sine', 0.35); // E
    }, 160);
    setTimeout(() => {
      this.playTone(880, 0.2, 'sine', 0.4); // A (octave)
    }, 280);
  },
  
  playRouletteLoseSound() {
    // Losing sound
    this.playTone(180, 0.2, 'sawtooth', 0.2);
  }
};

// Initialize sound manager
SoundManager.init();

// Game State
let gameState = {
  money: 0,
  clickPower: 1,
  passiveIncome: 0,
  upgrades: {},
  prestigeLevel: 0,
  prestigeMultiplier: 1,
  totalEarned: 0,
  totalClicks: 0,
  lastSave: Date.now()
};

// Upgrade Definitions
const upgrades = [
  {
    id: 'click1',
    name: 'Better Cursor',
    description: 'Increases click power by 1',
    baseCost: 10,
    type: 'click',
    effect: 1,
    costMultiplier: 1.5
  },
  {
    id: 'click2',
    name: 'Golden Cursor',
    description: 'Increases click power by 5',
    baseCost: 100,
    type: 'click',
    effect: 5,
    costMultiplier: 1.5
  },
  {
    id: 'click3',
    name: 'Diamond Cursor',
    description: 'Increases click power by 25',
    baseCost: 1000,
    type: 'click',
    effect: 25,
    costMultiplier: 1.5
  },
  {
    id: 'passive1',
    name: 'Auto Clicker',
    description: 'Generates $1 per second',
    baseCost: 50,
    type: 'passive',
    effect: 1,
    costMultiplier: 1.5
  },
  {
    id: 'passive2',
    name: 'Factory',
    description: 'Generates $10 per second',
    baseCost: 500,
    type: 'passive',
    effect: 10,
    costMultiplier: 1.5
  },
  {
    id: 'passive3',
    name: 'Business Empire',
    description: 'Generates $100 per second',
    baseCost: 5000,
    type: 'passive',
    effect: 100,
    costMultiplier: 1.5
  },
  {
    id: 'multiplier1',
    name: 'Income Boost',
    description: 'Increases all income by 10%',
    baseCost: 200,
    type: 'multiplier',
    effect: 0.1,
    costMultiplier: 2.0
  },
  {
    id: 'multiplier2',
    name: 'Super Boost',
    description: 'Increases all income by 25%',
    baseCost: 2000,
    type: 'multiplier',
    effect: 0.25,
    costMultiplier: 2.0
  }
];

// Utility Functions
function formatMoney(amount) {
  if (amount >= 1e12) return '$' + (amount / 1e12).toFixed(2) + 'T';
  if (amount >= 1e9) return '$' + (amount / 1e9).toFixed(2) + 'B';
  if (amount >= 1e6) return '$' + (amount / 1e6).toFixed(2) + 'M';
  if (amount >= 1e3) return '$' + (amount / 1e3).toFixed(2) + 'K';
  return '$' + amount.toFixed(2);
}

function formatNumber(num) {
  if (num >= 1e12) return (num / 1e12).toFixed(2) + 'T';
  if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
  if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
  if (num >= 1e3) return (num / 1e3).toFixed(2) + 'K';
  return num.toFixed(2);
}

// Save/Load Functions
function saveGame() {
  gameState.lastSave = Date.now();
  chrome.storage.local.set({ gameState: gameState }, () => {
    if (chrome.runtime.lastError) {
      console.error('Error saving game:', chrome.runtime.lastError);
    }
  });
}

function loadGame() {
  chrome.storage.local.get(['gameState'], (result) => {
    if (result.gameState) {
      gameState = { ...gameState, ...result.gameState };
      updateUI();
    }
  });
}

// Calculate upgrade cost
function getUpgradeCost(upgradeId) {
  const upgrade = upgrades.find(u => u.id === upgradeId);
  if (!upgrade) return 0;
  
  const owned = gameState.upgrades[upgradeId] || 0;
  return Math.floor(upgrade.baseCost * Math.pow(upgrade.costMultiplier, owned));
}

// Calculate total passive income
function calculatePassiveIncome() {
  let income = 0;
  let multiplier = 1 + (gameState.prestigeMultiplier - 1);
  
  // Add base passive income from upgrades
  upgrades.forEach(upgrade => {
    if (upgrade.type === 'passive') {
      const owned = gameState.upgrades[upgrade.id] || 0;
      income += upgrade.effect * owned;
    }
  });
  
  // Apply multiplier upgrades
  upgrades.forEach(upgrade => {
    if (upgrade.type === 'multiplier') {
      const owned = gameState.upgrades[upgrade.id] || 0;
      multiplier += upgrade.effect * owned;
    }
  });
  
  return income * multiplier;
}

// Calculate total click power
function calculateClickPower() {
  let power = 1;
  let multiplier = 1 + (gameState.prestigeMultiplier - 1);
  
  // Add click power from upgrades
  upgrades.forEach(upgrade => {
    if (upgrade.type === 'click') {
      const owned = gameState.upgrades[upgrade.id] || 0;
      power += upgrade.effect * owned;
    }
  });
  
  // Apply multiplier upgrades
  upgrades.forEach(upgrade => {
    if (upgrade.type === 'multiplier') {
      const owned = gameState.upgrades[upgrade.id] || 0;
      multiplier += upgrade.effect * owned;
    }
  });
  
  return power * multiplier;
}

// Purchase Upgrade
function purchaseUpgrade(upgradeId) {
  const upgrade = upgrades.find(u => u.id === upgradeId);
  if (!upgrade) return false;
  
  const cost = getUpgradeCost(upgradeId);
  if (gameState.money < cost) return false;
  
  gameState.money -= cost;
  gameState.upgrades[upgradeId] = (gameState.upgrades[upgradeId] || 0) + 1;
  
  // Play purchase sound
  SoundManager.playPurchaseSound();
  
  // Recalculate stats
  gameState.clickPower = calculateClickPower();
  gameState.passiveIncome = calculatePassiveIncome();
  
  saveGame();
  updateUI();
  return true;
}

// Click Handler
function handleClick() {
  const earnings = gameState.clickPower;
  gameState.money += earnings;
  gameState.totalEarned += earnings;
  gameState.totalClicks++;
  
  // Play click sound
  SoundManager.playClickSound();
  
  // Visual feedback
  showClickFeedback(earnings);
  
  saveGame();
  updateUI();
}

function showClickFeedback(amount) {
  const feedback = document.getElementById('clickFeedback');
  const element = document.createElement('div');
  element.className = 'click-feedback-item';
  element.textContent = '+' + formatMoney(amount);
  feedback.appendChild(element);
  
  setTimeout(() => {
    element.remove();
  }, 1000);
}

// Prestige System
function getPrestigeRequirement() {
  return 1000000 * Math.pow(10, gameState.prestigeLevel);
}

function calculatePrestigeBonus() {
  const requirement = getPrestigeRequirement();
  if (gameState.totalEarned < requirement) return 0;
  
  const bonus = 1 + (Math.log10(gameState.totalEarned / requirement) * 0.1);
  return Math.max(1, bonus);
}

function performPrestige() {
  const requirement = getPrestigeRequirement();
  if (gameState.totalEarned < requirement) return false;
  
  const bonus = calculatePrestigeBonus();
  gameState.prestigeLevel++;
  gameState.prestigeMultiplier *= bonus;
  
  // Reset progress
  gameState.money = 0;
  gameState.upgrades = {};
  gameState.clickPower = 1;
  gameState.passiveIncome = 0;
  gameState.totalClicks = 0;
  
  // Recalculate
  gameState.clickPower = calculateClickPower();
  gameState.passiveIncome = calculatePassiveIncome();
  
  saveGame();
  updateUI();
  return true;
}

// Casino Games
function playSlots(betAmount) {
  if (gameState.money < betAmount) {
    alert('Not enough money!');
    return false;
  }
  
  const spinButton = document.getElementById('spinButton');
  spinButton.disabled = true;
  spinButton.textContent = 'Spinning...';
  
  gameState.money -= betAmount;
  updateUI();
  
  const symbols = ['🍒', '🍋', '🍊', '🍇', '🔔', '⭐', '💎'];
  const reel1El = document.getElementById('reel1');
  const reel2El = document.getElementById('reel2');
  const reel3El = document.getElementById('reel3');
  
  // Spinning animation
  let spinCount = 0;
  const spinDuration = 2000; // 2 seconds
  const spinInterval = 50; // Update every 50ms
  const totalSpins = spinDuration / spinInterval;
  
  const spinIntervalId = setInterval(() => {
    reel1El.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    reel2El.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    reel3El.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    
    // Play spin sound periodically during spinning
    if (spinCount % 10 === 0) {
      SoundManager.playSlotsSpinSound();
    }
    
    spinCount++;
    
    if (spinCount >= totalSpins) {
      clearInterval(spinIntervalId);
      
      // Final results
      const reel1 = symbols[Math.floor(Math.random() * symbols.length)];
      const reel2 = symbols[Math.floor(Math.random() * symbols.length)];
      const reel3 = symbols[Math.floor(Math.random() * symbols.length)];
      
      reel1El.textContent = reel1;
      reel2El.textContent = reel2;
      reel3El.textContent = reel3;
      
      // Add winning animation
      if (reel1 === reel2 && reel2 === reel3) {
        reel1El.classList.add('winning');
        reel2El.classList.add('winning');
        reel3El.classList.add('winning');
        setTimeout(() => {
          reel1El.classList.remove('winning');
          reel2El.classList.remove('winning');
          reel3El.classList.remove('winning');
        }, 1000);
      }
      
      // Calculate winnings
      let winnings = 0;
      if (reel1 === reel2 && reel2 === reel3) {
        // Three of a kind
        if (reel1 === '💎') {
          winnings = betAmount * 100; // Jackpot
        } else if (reel1 === '⭐') {
          winnings = betAmount * 50;
        } else if (reel1 === '🔔') {
          winnings = betAmount * 25;
        } else {
          winnings = betAmount * 10;
        }
      } else if (reel1 === reel2 || reel2 === reel3 || reel1 === reel3) {
        // Two of a kind
        winnings = betAmount * 2;
      }
      
      gameState.money += winnings;
      gameState.totalEarned += winnings - betAmount;
      
      const resultEl = document.getElementById('slotsResult');
      if (winnings > 0) {
        resultEl.textContent = `You won ${formatMoney(winnings)}!`;
        resultEl.className = 'casino-result win';
        // Play win sound
        SoundManager.playSlotsWinSound();
      } else {
        resultEl.textContent = 'No win this time!';
        resultEl.className = 'casino-result loss';
        // Play lose sound
        SoundManager.playSlotsLoseSound();
      }
      
      spinButton.disabled = false;
      spinButton.textContent = 'Spin';
      
      saveGame();
      updateUI();
    }
  }, spinInterval);
  
  return true;
}

// Scratch Card Canvas Manager
const ScratchCardManager = {
  canvas: null,
  ctx: null,
  isScratching: false,
  revealedPercentage: 0,
  winnings: 0,
  betAmount: 0,
  resultShown: false,
  scratchButton: null,
  scratchCard: null,
  scratchContent: null,
  scratchResult: null,
  lastX: null,
  lastY: null,
  
  init() {
    this.canvas = document.getElementById('scratchCanvas');
    if (!this.canvas) return;
    
    this.ctx = this.canvas.getContext('2d');
    this.scratchButton = document.getElementById('scratchButton');
    this.scratchCard = document.getElementById('scratchCard');
    this.scratchContent = document.getElementById('scratchContent');
    this.scratchResult = document.getElementById('scratchResult');
    
    // Set canvas size
    this.resizeCanvas();
    
    // Add event listeners
    this.setupEventListeners();
  },
  
  resizeCanvas() {
    if (!this.canvas) return;
    const rect = this.canvas.getBoundingClientRect();
    this.canvas.width = rect.width;
    this.canvas.height = rect.height;
    this.drawCover();
  },
  
  drawCover() {
    if (!this.ctx) return;
    
    const width = this.canvas.width;
    const height = this.canvas.height;
    
    // Create scratch-off pattern
    this.ctx.fillStyle = '#f0f0f0';
    this.ctx.fillRect(0, 0, width, height);
    
    // Add diagonal stripe pattern
    this.ctx.strokeStyle = '#d0d0d0';
    this.ctx.lineWidth = 2;
    
    for (let i = -height; i < width + height; i += 20) {
      this.ctx.beginPath();
      this.ctx.moveTo(i, 0);
      this.ctx.lineTo(i + height, height);
      this.ctx.stroke();
    }
    
    // Add text hint
    this.ctx.fillStyle = '#999';
    this.ctx.font = 'bold 16px Arial';
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    this.ctx.fillText('Scratch Here!', width / 2, height / 2);
  },
  
  setupEventListeners() {
    if (!this.canvas) return;
    
    // Mouse events
    this.canvas.addEventListener('mousedown', (e) => this.startScratching(e));
    this.canvas.addEventListener('mousemove', (e) => this.scratch(e));
    this.canvas.addEventListener('mouseup', () => this.stopScratching());
    this.canvas.addEventListener('mouseleave', () => this.stopScratching());
    
    // Touch events for mobile
    this.canvas.addEventListener('touchstart', (e) => {
      e.preventDefault();
      const touch = e.touches[0];
      const mouseEvent = new MouseEvent('mousedown', {
        clientX: touch.clientX,
        clientY: touch.clientY
      });
      this.canvas.dispatchEvent(mouseEvent);
    });
    
    this.canvas.addEventListener('touchmove', (e) => {
      e.preventDefault();
      const touch = e.touches[0];
      const mouseEvent = new MouseEvent('mousemove', {
        clientX: touch.clientX,
        clientY: touch.clientY
      });
      this.canvas.dispatchEvent(mouseEvent);
    });
    
    this.canvas.addEventListener('touchend', (e) => {
      e.preventDefault();
      this.stopScratching();
    });
    
    // Resize handler
    window.addEventListener('resize', () => {
      setTimeout(() => this.resizeCanvas(), 100);
    });
  },
  
  getMousePos(e) {
    const rect = this.canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  },
  
  startScratching(e) {
    if (this.revealedPercentage >= 100) return;
    
    this.isScratching = true;
    const pos = this.getMousePos(e);
    this.lastX = pos.x;
    this.lastY = pos.y;
    this.scratchAt(pos.x, pos.y);
    SoundManager.playScratchSound();
  },
  
  scratch(e) {
    if (!this.isScratching || this.revealedPercentage >= 100) return;
    
    const pos = this.getMousePos(e);
    
    // Draw line between last position and current position for smooth scratching
    if (this.lastX !== null && this.lastY !== null) {
      this.scratchLine(this.lastX, this.lastY, pos.x, pos.y);
    }
    
    this.scratchAt(pos.x, pos.y);
    this.lastX = pos.x;
    this.lastY = pos.y;
  },
  
  scratchLine(x1, y1, x2, y2) {
    if (!this.ctx) return;
    
    // Use destination-out to erase the cover
    this.ctx.globalCompositeOperation = 'destination-out';
    
    const radius = 25;
    const distance = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
    const steps = Math.max(1, Math.floor(distance / (radius * 0.5)));
    
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const x = x1 + (x2 - x1) * t;
      const y = y1 + (y2 - y1) * t;
      
      this.ctx.beginPath();
      this.ctx.arc(x, y, radius, 0, Math.PI * 2);
      this.ctx.fill();
    }
  },
  
  scratchAt(x, y) {
    if (!this.ctx) return;
    
    // Use destination-out to erase the cover
    this.ctx.globalCompositeOperation = 'destination-out';
    
    // Draw a circle to erase (scratch effect)
    const radius = 25;
    this.ctx.beginPath();
    this.ctx.arc(x, y, radius, 0, Math.PI * 2);
    this.ctx.fill();
    
    // Play scratch sound occasionally
    if (Math.random() < 0.1) {
      SoundManager.playScratchSound();
    }
    
    // Calculate revealed percentage (throttled for performance)
    if (!this.lastCalcTime || Date.now() - this.lastCalcTime > 100) {
      this.calculateRevealedPercentage();
      this.lastCalcTime = Date.now();
      
      // Check if enough is revealed to show result
      if (this.revealedPercentage >= 50 && this.winnings !== undefined) {
        this.checkCompletion();
      }
    }
  },
  
  calculateRevealedPercentage() {
    if (!this.ctx || !this.canvas) return;
    
    // Read image data once and sample pixels for better performance
    const sampleRate = 5; // Sample every 5th pixel (good balance between accuracy and performance)
    const width = this.canvas.width;
    const height = this.canvas.height;
    
    // Read entire canvas once (for small canvases this is still fast)
    const imageData = this.ctx.getImageData(0, 0, width, height);
    const pixels = imageData.data;
    
    let transparentSamples = 0;
    let totalSamples = 0;
    
    // Sample pixels in a grid pattern
    for (let y = 0; y < height; y += sampleRate) {
      for (let x = 0; x < width; x += sampleRate) {
        // Calculate pixel index: (y * width + x) * 4 + 3 (alpha channel)
        const pixelIdx = (y * width + x) * 4 + 3;
        if (pixelIdx < pixels.length) {
          const alpha = pixels[pixelIdx];
          if (alpha < 128) { // Mostly transparent
            transparentSamples++;
          }
          totalSamples++;
        }
      }
    }
    
    if (totalSamples > 0) {
      this.revealedPercentage = (transparentSamples / totalSamples) * 100;
    }
  },
  
  checkCompletion() {
    if (this.revealedPercentage >= 50 && this.winnings !== undefined && this.scratchButton && this.scratchButton.disabled && !this.resultShown) {
      this.resultShown = true;
      
      // Show result when 50% is revealed
      if (this.winnings > 0) {
        this.scratchCard.classList.add('winning');
        setTimeout(() => {
          this.scratchCard.classList.remove('winning');
        }, 1000);
        SoundManager.playScratchWinSound();
      } else {
        SoundManager.playScratchLoseSound();
      }
      
      // Update result display
      if (this.winnings > 0) {
        this.scratchResult.textContent = `You won ${formatMoney(this.winnings)}!`;
        this.scratchResult.className = 'casino-result win';
      } else {
        this.scratchResult.textContent = 'Better luck next time!';
        this.scratchResult.className = 'casino-result loss';
      }
      
      // Update game state
      gameState.money += this.winnings;
      gameState.totalEarned += this.winnings - this.betAmount;
      
      this.scratchButton.disabled = false;
      saveGame();
      updateUI();
    }
  },
  
  stopScratching() {
    this.isScratching = false;
    this.lastX = null;
    this.lastY = null;
  },
  
  reset() {
    if (!this.canvas) return;
    
    this.isScratching = false;
    this.revealedPercentage = 0;
    this.winnings = 0;
    this.betAmount = 0;
    this.resultShown = false;
    this.lastX = null;
    this.lastY = null;
    this.lastCalcTime = null;
    
    // Clear canvas
    if (this.ctx) {
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      this.drawCover();
    }
    
    // Reset content
    if (this.scratchContent) {
      this.scratchContent.textContent = '';
    }
    
    if (this.scratchResult) {
      this.scratchResult.textContent = '';
      this.scratchResult.className = 'casino-result';
    }
  },
  
  setupCard(winnings, betAmount) {
    // Reset state variables
    this.isScratching = false;
    this.revealedPercentage = 0;
    this.resultShown = false;
    this.lastX = null;
    this.lastY = null;
    this.lastCalcTime = null;
    
    // Set new card values
    this.winnings = winnings;
    this.betAmount = betAmount;
    
    // Ensure canvas is properly sized
    this.resizeCanvas();
    
    // Set the winning amount
    if (this.scratchContent) {
      this.scratchContent.textContent = formatMoney(winnings);
    }
    
    // Reset canvas with cover
    if (this.ctx) {
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      this.drawCover();
    }
    
    // Clear previous result
    if (this.scratchResult) {
      this.scratchResult.textContent = '';
      this.scratchResult.className = 'casino-result';
    }
  }
};

function playScratchCard(betAmount) {
  if (gameState.money < betAmount) {
    alert('Not enough money!');
    return false;
  }
  
  const scratchButton = document.getElementById('scratchButton');
  scratchButton.disabled = true;
  
  gameState.money -= betAmount;
  updateUI();
  
  const prizes = [
    { amount: betAmount * 0, probability: 0.5 },
    { amount: betAmount * 2, probability: 0.3 },
    { amount: betAmount * 5, probability: 0.15 },
    { amount: betAmount * 10, probability: 0.04 },
    { amount: betAmount * 50, probability: 0.01 }
  ];
  
  const random = Math.random();
  let cumulative = 0;
  let winnings = 0;
  
  for (const prize of prizes) {
    cumulative += prize.probability;
    if (random <= cumulative) {
      winnings = prize.amount;
      break;
    }
  }
  
  // Setup the scratch card with canvas
  ScratchCardManager.setupCard(winnings, betAmount);
  
  // Reset scratch card after 5 seconds if not fully revealed
  setTimeout(() => {
    if (ScratchCardManager.revealedPercentage < 50) {
      ScratchCardManager.reset();
      scratchButton.disabled = false;
    }
  }, 30000); // 30 seconds timeout
  
  return true;
}

function playRoulette(betAmount, betType) {
  if (gameState.money < betAmount) {
    alert('Not enough money!');
    return false;
  }
  
  // Disable all bet buttons
  const betButtons = document.querySelectorAll('.roulette-bet-btn');
  betButtons.forEach(btn => btn.disabled = true);
  
  gameState.money -= betAmount;
  updateUI();
  
  const wheel = document.getElementById('rouletteWheel');
  const resultNumber = Math.floor(Math.random() * 37); // 0-36
  const isRed = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36].includes(resultNumber);
  const isBlack = resultNumber !== 0 && !isRed;
  const isGreen = resultNumber === 0;
  
  // Spinning animation
  let spinCount = 0;
  const spinDuration = 2500; // 2.5 seconds
  const spinInterval = 30;
  const totalSpins = spinDuration / spinInterval;
  const numbers = Array.from({ length: 37 }, (_, i) => i);
  
  // Determine color for final number
  let finalColor = 'black';
  if (isRed) finalColor = 'red';
  if (isGreen) finalColor = 'green';
  
  const spinIntervalId = setInterval(() => {
    const randomNum = numbers[Math.floor(Math.random() * numbers.length)];
    wheel.textContent = randomNum;
    
    // Color animation
    const tempIsRed = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36].includes(randomNum);
    const tempIsBlack = randomNum !== 0 && !tempIsRed;
    const tempIsGreen = randomNum === 0;
    
    if (tempIsRed) {
      wheel.style.background = 'linear-gradient(135deg, #dc3545 0%, #c82333 100%)';
    } else if (tempIsBlack) {
      wheel.style.background = 'linear-gradient(135deg, #212529 0%, #000000 100%)';
    } else {
      wheel.style.background = 'linear-gradient(135deg, #2d8659 0%, #1e5d3f 100%)';
    }
    
    // Add rotation effect
    wheel.style.transform = `rotate(${spinCount * 10}deg)`;
    
    // Play spin sound periodically during spinning
    if (spinCount % 15 === 0) {
      SoundManager.playRouletteSpinSound();
    }
    
    spinCount++;
    
    if (spinCount >= totalSpins) {
      clearInterval(spinIntervalId);
      
      // Final result
      wheel.textContent = resultNumber;
      wheel.style.transform = `rotate(${resultNumber * 9.73}deg)`;
      
      // Set final color
      if (isRed) {
        wheel.style.background = 'linear-gradient(135deg, #dc3545 0%, #c82333 100%)';
      } else if (isBlack) {
        wheel.style.background = 'linear-gradient(135deg, #212529 0%, #000000 100%)';
      } else {
        wheel.style.background = 'linear-gradient(135deg, #2d8659 0%, #1e5d3f 100%)';
      }
      
      // Add winning pulse animation
      if ((betType === 'red' && isRed) || (betType === 'black' && isBlack) || (betType === 'green' && isGreen)) {
        wheel.classList.add('winning');
        setTimeout(() => {
          wheel.classList.remove('winning');
        }, 1000);
      }
      
      // Calculate winnings
      let won = false;
      let multiplier = 1;
      
      if (betType === 'red' && isRed) {
        won = true;
        multiplier = 2;
      } else if (betType === 'black' && isBlack) {
        won = true;
        multiplier = 2;
      } else if (betType === 'green' && isGreen) {
        won = true;
        multiplier = 35;
      }
      
      const winnings = won ? betAmount * multiplier : 0;
      gameState.money += winnings;
      gameState.totalEarned += winnings - betAmount;
      
      const resultEl = document.getElementById('rouletteResult');
      if (won) {
        resultEl.textContent = `Number ${resultNumber} (${finalColor}) - You won ${formatMoney(winnings)}!`;
        resultEl.className = 'casino-result win';
        // Play win sound
        SoundManager.playRouletteWinSound();
      } else {
        resultEl.textContent = `Number ${resultNumber} (${finalColor}) - You lost!`;
        resultEl.className = 'casino-result loss';
        // Play lose sound
        SoundManager.playRouletteLoseSound();
      }
      
      // Re-enable buttons
      betButtons.forEach(btn => btn.disabled = false);
      
      saveGame();
      updateUI();
    }
  }, spinInterval);
  
  return true;
}

// UI Update Functions
// Generate funny statistics based on current money
function getFunnyStatistic(money) {
  const stats = [];
  
  // Very poor
  if (money < 1) {
    return "You're broke! Can't even afford a gumball! 😅";
  }
  if (money < 5) {
    return "You could buy... a coffee? Maybe? ☕";
  }
  if (money < 20) {
    return "You're below the poverty line in most countries! 💸";
  }
  if (money < 100) {
    return "You could buy a nice meal... in a developing country! 🍛";
  }
  if (money < 500) {
    return "You're earning less than minimum wage in the US! 🇺🇸";
  }
  if (money < 1000) {
    return "You could buy a smartphone... a very old one! 📱";
  }
  if (money < 5000) {
    return "You're earning below average in Poland! 🇵🇱";
  }
  if (money < 10000) {
    return "You could buy a used car... if it's from 1995! 🚗";
  }
  if (money < 50000) {
    return "You're earning more than the average salary in India! 🇮🇳";
  }
  if (money < 100000) {
    return "You could buy a small apartment... in rural areas! 🏠";
  }
  if (money < 500000) {
    return "You're earning more than the average in many European countries! 🇪🇺";
  }
  if (money < 1000000) {
    return "You could buy a luxury car! Or a house in some places! 🏎️";
  }
  if (money < 5000000) {
    return "You're earning more than most doctors! 🩺";
  }
  if (money < 10000000) {
    return "You could buy a private jet... a small one! ✈️";
  }
  if (money < 50000000) {
    return "You're earning more than some CEOs! 💼";
  }
  if (money < 100000000) {
    return "You could buy a yacht! A nice one! 🛥️";
  }
  if (money < 500000000) {
    return "You're in the top 1% globally! 🌍";
  }
  if (money < 1000000000) {
    return "You could buy a private island! 🏝️";
  }
  if (money < 5000000000) {
    return "You're earning more than some small countries' GDP! 💰";
  }
  if (money < 10000000000) {
    return "You could buy a space rocket! 🚀";
  }
  if (money < 50000000000) {
    return "You're richer than some billionaires! 💎";
  }
  if (money < 100000000000) {
    return "You could buy a small country! 🗺️";
  }
  
  return "You're basically a god of money! Worship yourself! 🙏💰";
}

function updateUI() {
  // Update money display
  document.getElementById('money').textContent = formatMoney(gameState.money);
  
  // Update stats
  document.getElementById('incomePerSecond').textContent = formatMoney(gameState.passiveIncome);
  document.getElementById('clickPower').textContent = formatMoney(gameState.clickPower);
  document.getElementById('totalClicks').textContent = formatNumber(gameState.totalClicks);
  document.getElementById('prestigeLevel').textContent = gameState.prestigeLevel;
  document.getElementById('prestigeMultiplier').textContent = gameState.prestigeMultiplier.toFixed(2) + 'x';
  document.getElementById('totalEarned').textContent = formatMoney(gameState.totalEarned);
  
  // Update funny statistics
  document.getElementById('funnyStatText').textContent = getFunnyStatistic(gameState.money);
  
  // Update upgrades list
  updateUpgradesList();
}

function updateUpgradesList() {
  const upgradesList = document.getElementById('upgradesList');
  upgradesList.innerHTML = '';
  
  upgrades.forEach(upgrade => {
    const owned = gameState.upgrades[upgrade.id] || 0;
    const cost = getUpgradeCost(upgrade.id);
    const canAfford = gameState.money >= cost;
    
    const upgradeEl = document.createElement('div');
    upgradeEl.className = `upgrade-item ${canAfford ? '' : 'disabled'}`;
    upgradeEl.innerHTML = `
      <div class="upgrade-info">
        <h3>${upgrade.name}</h3>
        <p>${upgrade.description}</p>
        <p class="upgrade-owned">Owned: ${owned}</p>
      </div>
      <div class="upgrade-purchase">
        <span class="upgrade-cost">${formatMoney(cost)}</span>
        <button class="upgrade-button" data-upgrade="${upgrade.id}" ${canAfford ? '' : 'disabled'}>
          Buy
        </button>
      </div>
    `;
    
    upgradesList.appendChild(upgradeEl);
  });
  
  // Add event listeners to upgrade buttons
  document.querySelectorAll('.upgrade-button').forEach(button => {
    button.addEventListener('click', (e) => {
      const upgradeId = e.target.dataset.upgrade;
      if (purchaseUpgrade(upgradeId)) {
        // Button will be updated by updateUpgradesList
      }
    });
  });
}

// Tab Switching
function initTabs() {
  const tabButtons = document.querySelectorAll('.tab-button');
  const tabContents = document.querySelectorAll('.tab-content');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const targetTab = button.dataset.tab;
      
      // Update button states
      tabButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
      
      // Update content visibility
      tabContents.forEach(content => {
        content.classList.remove('active');
        if (content.id === targetTab + 'Tab') {
          content.classList.add('active');
        }
      });
    });
  });
}

// Initialize Event Listeners
function initEventListeners() {
  // Click button
  document.getElementById('clickButton').addEventListener('click', handleClick);
  
  // Casino games
  document.getElementById('spinButton').addEventListener('click', () => {
    const bet = parseInt(document.getElementById('slotsBet').value) || 10;
    playSlots(bet);
  });
  
  document.getElementById('scratchButton').addEventListener('click', () => {
    const bet = parseInt(document.getElementById('scratchBet').value) || 5;
    playScratchCard(bet);
  });
  
  document.querySelectorAll('.roulette-bet-btn').forEach(button => {
    button.addEventListener('click', () => {
      const bet = parseInt(document.getElementById('rouletteBet').value) || 20;
      const betType = button.dataset.bet;
      playRoulette(bet, betType);
    });
  });
  
  // Tab switching
  initTabs();
}

// Passive Income Loop
let passiveIncomeInterval;

function startPassiveIncome() {
  if (passiveIncomeInterval) {
    clearInterval(passiveIncomeInterval);
  }
  
  passiveIncomeInterval = setInterval(() => {
    const income = calculatePassiveIncome();
    if (income > 0) {
      gameState.money += income;
      gameState.totalEarned += income;
      gameState.passiveIncome = income;
      updateUI();
      
      // Auto-save every 5 seconds
      if (Date.now() - gameState.lastSave > 5000) {
        saveGame();
      }
    }
  }, 1000);
}

// Auto-save on close
window.addEventListener('beforeunload', () => {
  saveGame();
});

// Initialize Game
function init() {
  loadGame();
  gameState.clickPower = calculateClickPower();
  gameState.passiveIncome = calculatePassiveIncome();
  updateUI();
  initEventListeners();
  startPassiveIncome();
  
  // Initialize scratch card manager
  setTimeout(() => {
    ScratchCardManager.init();
  }, 100);
}

// Start the game when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

