# Gambling Clicker - Chrome Extension

A simple clicking game Chrome extension where you try to earn as much money as possible! Progress from being broke to becoming the richest person on Earth with upgrades, passive income, and a prestige system.

## Features

### Core Gameplay
- **Clicking Mechanics**: Click the main button to earn money
- **Income System**: Earn money both through clicking and passive income
- **Shop/Upgrades**: Purchase upgrades to increase your click power and passive income
- **Prestige System**: Reset your progress for permanent multipliers to earn even more
- **Progression**: Track your stats including total clicks, income per second, and prestige level

### Casino Games
- **Slots**: Spin the reels for a chance to win big (up to 100x your bet!)
- **Scratch Cards**: Buy scratch cards for instant wins
- **Roulette**: Bet on red, black, or green for different multipliers

## Installation

1. Clone or download this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" (toggle in the top right)
4. Click "Load unpacked"
5. Select the `GamblingClicker` folder
6. The extension icon should appear in your Chrome toolbar

## Usage

1. Click the extension icon in your Chrome toolbar
2. Click the main button to earn money
3. Purchase upgrades from the Shop tab to increase your income
4. Try your luck in the Casino tab with slots, scratch cards, or roulette
5. When you've earned enough, use Prestige to reset and gain permanent multipliers

## Game Mechanics

### Upgrades
- **Click Upgrades**: Increase the amount earned per click
- **Passive Income**: Generate money automatically every second
- **Multipliers**: Boost all income sources by a percentage

### Prestige
- Requires earning a certain amount (starts at $1,000,000)
- Resets all progress but grants permanent multipliers
- Each prestige level increases the requirement exponentially
- Prestige multipliers apply to all income sources

### Save System
- Game automatically saves your progress
- Data is stored locally using Chrome's storage API
- Progress persists between browser sessions

## Development

### File Structure
```
GamblingClicker/
├── manifest.json          # Chrome extension manifest (V3)
├── popup.html             # Main game UI
├── popup.css              # Game styling
├── popup.js               # Core game logic
├── icons/                 # Extension icons
└── README.md              # This file
```

### Technologies
- Vanilla JavaScript
- HTML5/CSS3
- Chrome Extension Manifest V3
- Chrome Storage API

## Notes

- Icons need to be added to the `icons/` directory (icon16.png, icon48.png, icon128.png)
- The extension uses Chrome's storage API for data persistence
- All game logic runs in the popup window

## License

This project is for educational purposes.


