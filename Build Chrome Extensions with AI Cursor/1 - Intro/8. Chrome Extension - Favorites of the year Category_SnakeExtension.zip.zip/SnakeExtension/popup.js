/**
 * Matrix Tetris Game
 * Classic Tetris implementation with Matrix-style terminal aesthetic
 */

// Game constants
const COLS = 10;
const ROWS = 20;
const BLOCK_SIZE = 20;
const COLORS = {
  I: '#00ff00',
  O: '#00ff00',
  T: '#00ff00',
  S: '#00ff00',
  Z: '#00ff00',
  J: '#00ff00',
  L: '#00ff00',
  EMPTY: '#000000',
  GHOST: '#003300'
};

// Tetris pieces (Tetrominoes)
const PIECES = {
  I: [
    [[1, 1, 1, 1]]
  ],
  O: [
    [[1, 1],
     [1, 1]]
  ],
  T: [
    [[0, 1, 0],
     [1, 1, 1]],
    [[1, 0],
     [1, 1],
     [1, 0]],
    [[1, 1, 1],
     [0, 1, 0]],
    [[0, 1],
     [1, 1],
     [0, 1]]
  ],
  S: [
    [[0, 1, 1],
     [1, 1, 0]],
    [[1, 0],
     [1, 1],
     [0, 1]]
  ],
  Z: [
    [[1, 1, 0],
     [0, 1, 1]],
    [[0, 1],
     [1, 1],
     [1, 0]]
  ],
  J: [
    [[1, 0, 0],
     [1, 1, 1]],
    [[1, 1],
     [1, 0],
     [1, 0]],
    [[1, 1, 1],
     [0, 0, 1]],
    [[0, 1],
     [0, 1],
     [1, 1]]
  ],
  L: [
    [[0, 0, 1],
     [1, 1, 1]],
    [[1, 0],
     [1, 0],
     [1, 1]],
    [[1, 1, 1],
     [1, 0, 0]],
    [[1, 1],
     [0, 1],
     [0, 1]]
  ]
};

// Game state
let board = [];
let currentPiece = null;
let nextPiece = null;
let holdPiece = null;
let canHold = true;
let score = 0;
let lines = 0;
let level = 1;
let bestScore = 0;
let gameRunning = false;
let gamePaused = false;
let dropTime = 0;
let lastTime = 0;
let dropInterval = 1000;

// Canvas contexts
let ctx;
let nextCtx;
let holdCtx;

// 7-bag system for piece generation
let bag = [];
let nextBag = [];

/**
 * Initialize the game
 */
function init() {
  // Get canvas contexts
  const gameBoard = document.getElementById('game-board');
  const nextCanvas = document.getElementById('next-piece');
  const holdCanvas = document.getElementById('hold-piece');
  
  ctx = gameBoard.getContext('2d');
  nextCtx = nextCanvas.getContext('2d');
  holdCtx = holdCanvas.getContext('2d');
  
  // Initialize board
  board = Array(ROWS).fill().map(() => Array(COLS).fill(0));
  
  // Load best score
  loadBestScore();
  
  // Initialize piece bags
  generateBag();
  generateBag();
  
  // Get first pieces
  currentPiece = createPiece(getNextPiece());
  nextPiece = getNextPiece();
  
  // Set up event listeners
  setupEventListeners();
  
  // Draw initial state
  draw();
  
  // Auto-start the game when popup opens
  startGame();
  
  // Start the game loop
  requestAnimationFrame(gameLoop);
}

/**
 * Generate a 7-bag of pieces
 */
function generateBag() {
  const pieces = ['I', 'O', 'T', 'S', 'Z', 'J', 'L'];
  // Fisher-Yates shuffle
  for (let i = pieces.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pieces[i], pieces[j]] = [pieces[j], pieces[i]];
  }
  bag.push(...pieces);
}

/**
 * Get next piece from bag
 */
function getNextPiece() {
  if (bag.length === 0) {
    generateBag();
  }
  return bag.shift();
}

/**
 * Create a piece object
 */
function createPiece(type) {
  return {
    type: type,
    matrix: JSON.parse(JSON.stringify(PIECES[type][0])),
    rotation: 0,
    x: Math.floor(COLS / 2) - Math.floor(PIECES[type][0][0].length / 2),
    y: 0
  };
}

/**
 * Draw a block on canvas
 */
function drawBlock(ctx, x, y, color, size = BLOCK_SIZE) {
  ctx.fillStyle = color;
  ctx.fillRect(x * size, y * size, size, size);
  
  // Matrix-style grid effect
  ctx.strokeStyle = '#001100';
  ctx.lineWidth = 1;
  ctx.strokeRect(x * size, y * size, size, size);
  
  // Glow effect for filled blocks
  if (color !== COLORS.EMPTY && color !== COLORS.GHOST) {
    ctx.shadowColor = '#00ff00';
    ctx.shadowBlur = 5;
    ctx.fillRect(x * size, y * size, size, size);
    ctx.shadowBlur = 0;
  }
}

/**
 * Draw the game board
 */
function drawBoard() {
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  
  // Draw board
  for (let y = 0; y < ROWS; y++) {
    for (let x = 0; x < COLS; x++) {
      const value = board[y][x];
      const color = value ? COLORS[value] : COLORS.EMPTY;
      drawBlock(ctx, x, y, color);
    }
  }
  
  // Draw ghost piece
  if (currentPiece) {
    const ghostY = getGhostY();
    drawPiece(ctx, currentPiece, currentPiece.x, ghostY, true);
  }
  
  // Draw current piece
  if (currentPiece) {
    drawPiece(ctx, currentPiece, currentPiece.x, currentPiece.y, false);
  }
}

/**
 * Draw a piece
 */
function drawPiece(ctx, piece, offsetX, offsetY, isGhost = false) {
  const color = isGhost ? COLORS.GHOST : COLORS[piece.type];
  
  for (let y = 0; y < piece.matrix.length; y++) {
    for (let x = 0; x < piece.matrix[y].length; x++) {
      if (piece.matrix[y][x]) {
        const drawX = offsetX + x;
        const drawY = offsetY + y;
        
        if (drawY >= 0) {
          if (isGhost) {
            ctx.fillStyle = COLORS.GHOST;
            ctx.fillRect(drawX * BLOCK_SIZE, drawY * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE);
            ctx.strokeStyle = '#00ff00';
            ctx.lineWidth = 1;
            ctx.strokeRect(drawX * BLOCK_SIZE, drawY * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE);
          } else {
            drawBlock(ctx, drawX, drawY, color);
          }
        }
      }
    }
  }
}

/**
 * Draw next piece preview
 */
function drawNextPiece() {
  nextCtx.clearRect(0, 0, nextCtx.canvas.width, nextCtx.canvas.height);
  
  if (nextPiece) {
    const preview = createPiece(nextPiece);
    const offsetX = (nextCtx.canvas.width / BLOCK_SIZE - preview.matrix[0].length) / 2;
    const offsetY = (nextCtx.canvas.height / BLOCK_SIZE - preview.matrix.length) / 2;
    
    for (let y = 0; y < preview.matrix.length; y++) {
      for (let x = 0; x < preview.matrix[y].length; x++) {
        if (preview.matrix[y][x]) {
          drawBlock(nextCtx, offsetX + x, offsetY + y, COLORS[preview.type], BLOCK_SIZE);
        }
      }
    }
  }
}

/**
 * Draw hold piece preview
 */
function drawHoldPiece() {
  holdCtx.clearRect(0, 0, holdCtx.canvas.width, holdCtx.canvas.height);
  
  if (holdPiece) {
    const preview = createPiece(holdPiece);
    const offsetX = (holdCtx.canvas.width / BLOCK_SIZE - preview.matrix[0].length) / 2;
    const offsetY = (holdCtx.canvas.height / BLOCK_SIZE - preview.matrix.length) / 2;
    
    for (let y = 0; y < preview.matrix.length; y++) {
      for (let x = 0; x < preview.matrix[y].length; x++) {
        if (preview.matrix[y][x]) {
          drawBlock(holdCtx, offsetX + x, offsetY + y, COLORS[preview.type], BLOCK_SIZE);
        }
      }
    }
  }
}

/**
 * Update score display
 */
function updateScore() {
  document.getElementById('score').textContent = score;
  document.getElementById('lines').textContent = lines;
  document.getElementById('level').textContent = level;
  document.getElementById('best-score').textContent = bestScore;
}

/**
 * Draw everything
 */
function draw() {
  drawBoard();
  drawNextPiece();
  drawHoldPiece();
  updateScore();
}

/**
 * Check collision
 */
function collide(piece, offsetX, offsetY) {
  for (let y = 0; y < piece.matrix.length; y++) {
    for (let x = 0; x < piece.matrix[y].length; x++) {
      if (piece.matrix[y][x]) {
        const newX = piece.x + x + offsetX;
        const newY = piece.y + y + offsetY;
        
        if (newX < 0 || newX >= COLS || newY >= ROWS) {
          return true;
        }
        
        if (newY >= 0 && board[newY][newX]) {
          return true;
        }
      }
    }
  }
  return false;
}

/**
 * Merge piece into board
 */
function mergePiece() {
  for (let y = 0; y < currentPiece.matrix.length; y++) {
    for (let x = 0; x < currentPiece.matrix[y].length; x++) {
      if (currentPiece.matrix[y][x]) {
        const boardY = currentPiece.y + y;
        const boardX = currentPiece.x + x;
        
        if (boardY >= 0) {
          board[boardY][boardX] = currentPiece.type;
        }
      }
    }
  }
}

/**
 * Clear full lines
 */
function clearLines() {
  let linesCleared = 0;
  
  for (let y = ROWS - 1; y >= 0; y--) {
    if (board[y].every(cell => cell !== 0)) {
      board.splice(y, 1);
      board.unshift(Array(COLS).fill(0));
      linesCleared++;
      y++; // Check same line again
    }
  }
  
  if (linesCleared > 0) {
    lines += linesCleared;
    
    // Scoring system
    const linePoints = [0, 100, 300, 500, 800];
    score += linePoints[linesCleared] * level;
    
    // Level up every 10 lines
    level = Math.floor(lines / 10) + 1;
    dropInterval = Math.max(100, 1000 - (level - 1) * 50);
    
    // Update best score
    if (score > bestScore) {
      bestScore = score;
      saveBestScore();
    }
  }
}

/**
 * Rotate piece
 */
function rotatePiece() {
  const pieceType = currentPiece.type;
  const rotations = PIECES[pieceType];
  
  if (rotations.length === 1) return; // O piece doesn't rotate
  
  const nextRotation = (currentPiece.rotation + 1) % rotations.length;
  const originalMatrix = currentPiece.matrix;
  const originalRotation = currentPiece.rotation;
  
  currentPiece.matrix = JSON.parse(JSON.stringify(rotations[nextRotation]));
  currentPiece.rotation = nextRotation;
  
  // Wall kick - try to adjust position if collision
  const offsets = [
    [0, 0], [-1, 0], [1, 0], [0, -1], [-1, -1], [1, -1]
  ];
  
  for (const [offsetX, offsetY] of offsets) {
    if (!collide(currentPiece, offsetX, offsetY)) {
      currentPiece.x += offsetX;
      currentPiece.y += offsetY;
      return;
    }
  }
  
  // If no valid position found, revert rotation
  currentPiece.matrix = originalMatrix;
  currentPiece.rotation = originalRotation;
}

/**
 * Get ghost piece Y position
 */
function getGhostY() {
  let ghostY = currentPiece.y;
  
  while (!collide(currentPiece, 0, ghostY - currentPiece.y + 1)) {
    ghostY++;
  }
  
  return ghostY;
}

/**
 * Move piece
 */
function movePiece(dx, dy) {
  if (!collide(currentPiece, dx, dy)) {
    currentPiece.x += dx;
    currentPiece.y += dy;
    return true;
  }
  return false;
}

/**
 * Hard drop
 */
function hardDrop() {
  while (movePiece(0, 1)) {
    score += 2;
  }
  dropPiece();
}

/**
 * Hold current piece
 */
function holdCurrentPiece() {
  if (!canHold) return;
  
  if (holdPiece === null) {
    holdPiece = currentPiece.type;
    currentPiece = createPiece(getNextPiece());
    nextPiece = getNextPiece();
  } else {
    const temp = holdPiece;
    holdPiece = currentPiece.type;
    currentPiece = createPiece(temp);
  }
  
  canHold = false;
}

/**
 * Drop piece
 */
function dropPiece() {
  mergePiece();
  clearLines();
  canHold = true;
  
  currentPiece = createPiece(nextPiece);
  nextPiece = getNextPiece();
  
  // Check game over
  if (collide(currentPiece, 0, 0)) {
    gameOver();
  }
}

/**
 * Game loop
 */
function gameLoop(time = 0) {
  if (!gameRunning || gamePaused) {
    requestAnimationFrame(gameLoop);
    return;
  }
  
  const deltaTime = time - lastTime;
  lastTime = time;
  dropTime += deltaTime;
  
  if (dropTime > dropInterval) {
    if (!movePiece(0, 1)) {
      dropPiece();
    }
    dropTime = 0;
  }
  
  draw();
  requestAnimationFrame(gameLoop);
}

/**
 * Start game
 */
function startGame() {
  if (gameRunning) return;
  
  // Reset game state
  board = Array(ROWS).fill().map(() => Array(COLS).fill(0));
  score = 0;
  lines = 0;
  level = 1;
  dropTime = 0;
  dropInterval = 1000;
  canHold = true;
  holdPiece = null;
  
  // Reset pieces
  bag = [];
  generateBag();
  generateBag();
  currentPiece = createPiece(getNextPiece());
  nextPiece = getNextPiece();
  
  // Hide game over screen
  document.getElementById('game-over').classList.add('hidden');
  document.getElementById('paused').classList.add('hidden');
  
  gameRunning = true;
  gamePaused = false;
  lastTime = performance.now();
  gameLoop();
}

/**
 * Pause/Resume game
 */
function togglePause() {
  if (!gameRunning) return;
  
  gamePaused = !gamePaused;
  document.getElementById('paused').classList.toggle('hidden', !gamePaused);
  
  if (!gamePaused) {
    lastTime = performance.now();
  }
}

/**
 * Game over
 */
function gameOver() {
  gameRunning = false;
  document.getElementById('final-score').textContent = score;
  document.getElementById('game-over').classList.remove('hidden');
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
  // Button events
  document.getElementById('start-btn').addEventListener('click', startGame);
  document.getElementById('pause-btn').addEventListener('click', togglePause);
  document.getElementById('restart-btn').addEventListener('click', startGame);
  
  // Keyboard events
  document.addEventListener('keydown', (e) => {
    if (!gameRunning || gamePaused) {
      if (e.code === 'Space' && gamePaused) {
        togglePause();
      }
      return;
    }
    
    switch (e.code) {
      case 'ArrowLeft':
        e.preventDefault();
        movePiece(-1, 0);
        draw();
        break;
      case 'ArrowRight':
        e.preventDefault();
        movePiece(1, 0);
        draw();
        break;
      case 'ArrowDown':
        e.preventDefault();
        if (movePiece(0, 1)) {
          score += 1;
        } else {
          dropPiece();
        }
        draw();
        break;
      case 'ArrowUp':
        e.preventDefault();
        rotatePiece();
        draw();
        break;
      case 'Space':
        e.preventDefault();
        hardDrop();
        draw();
        break;
      case 'KeyC':
        e.preventDefault();
        holdCurrentPiece();
        draw();
        break;
      case 'KeyP':
        e.preventDefault();
        togglePause();
        break;
    }
  });
}

/**
 * Load best score from storage
 */
function loadBestScore() {
  chrome.storage.local.get(['bestScore'], (result) => {
    if (result.bestScore !== undefined) {
      bestScore = result.bestScore;
      updateScore();
    }
  });
}

/**
 * Save best score to storage
 */
function saveBestScore() {
  chrome.storage.local.set({ bestScore: bestScore });
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

