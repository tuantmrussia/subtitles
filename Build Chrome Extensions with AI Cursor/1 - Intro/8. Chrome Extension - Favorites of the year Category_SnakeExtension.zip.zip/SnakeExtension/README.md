# Matrix Tetris - Chrome Extension

A classic Tetris game with a Matrix-style terminal aesthetic. Play offline in your Chrome browser with smooth controls and persistent score tracking.

## Features

- **Matrix Design**: Green-on-black terminal aesthetic with glowing effects
- **Classic Tetris Gameplay**: All 7 standard Tetris pieces (I, O, T, S, Z, J, L)
- **7-Bag Piece Generation**: Fair and consistent piece distribution
- **Hold Piece**: Strategically hold pieces for better placement
- **Ghost Piece**: Visual guide showing where the piece will land
- **Score Persistence**: Automatically saves your best score locally
- **Smooth Controls**: Responsive keyboard controls with soft/hard drop
- **Level System**: Difficulty increases as you clear more lines
- **Pause/Resume**: Take breaks without losing your progress

## Installation

1. Clone or download this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" (toggle in top right)
4. Click "Load unpacked"
5. Select the `SnakeExtension` folder
6. Chrome will use a default icon (first letter of extension name) - the extension is ready to use!

## Controls

- **←/→ Arrow Keys**: Move piece left/right
- **↓ Arrow Key**: Soft drop (faster fall, +1 point per cell)
- **↑ Arrow Key**: Rotate piece clockwise
- **SPACE**: Hard drop (instant drop, +2 points per cell)
- **C**: Hold current piece
- **P**: Pause/Resume game

## Scoring

- **Single line**: 100 × level
- **Double lines**: 300 × level
- **Triple lines**: 500 × level
- **Tetris (4 lines)**: 800 × level
- **Soft drop**: +1 point per cell
- **Hard drop**: +2 points per cell

## Game Rules

- Clear horizontal lines to score points
- Level increases every 10 lines cleared
- Game speed increases with each level
- Game ends when pieces reach the top
- Best score is automatically saved

## Development

### File Structure

```
SnakeExtension/
├── manifest.json       # Extension manifest (Manifest V3)
├── popup.html         # Main game interface
├── popup.css          # Matrix-style styling
├── popup.js           # Game logic and controls
└── README.md          # This file
```

### Technologies

- **Manifest V3**: Modern Chrome extension API
- **HTML5 Canvas**: Game rendering
- **Chrome Storage API**: Score persistence
- **Vanilla JavaScript**: No dependencies

## Privacy

This extension:
- Runs entirely offline
- Stores only your best score locally
- Does not collect or transmit any data
- Does not require internet connection

## License

Free to use and modify.

## Credits

Inspired by classic Tetris and The Matrix aesthetic.

