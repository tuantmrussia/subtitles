 
package android.app;
/**
* System private API for talking with the androidworld service.
* {@hide}
*/
interface IAndroidServiceManager{
   void printAndroid();
}