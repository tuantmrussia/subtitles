package com.android.server;
import android.app.IAndroidServiceManager;
import android.content.Context;
import android.os.RemoteException;
import android.util.Slog;
import android.content.Context;
import com.android.server.SystemService;
public class AndroidService extends IAndroidServiceManager.Stub {
    private final static String LOG_TAG = "AndroidService";
 
    private final Object mLock = new Object();
 
    private final Context mContext;
    
    AndroidService(Context context) {
        mContext = context;
    }   
    
    @Override
    public void printAndroid() throws RemoteException {
        Slog.i(LOG_TAG,"Android,World!");
    }   
}
