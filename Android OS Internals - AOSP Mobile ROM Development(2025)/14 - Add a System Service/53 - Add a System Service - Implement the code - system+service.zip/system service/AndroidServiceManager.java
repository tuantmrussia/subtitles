package android.app;
import android.os.RemoteException;
import android.annotation.SystemService;
import android.content.Context;
 
@SystemService(Context.ANDROID_SERVICE)
public final class AndroidServiceManager{
  private final IAndroidServiceManager mService;
  private Context mContext;
  /** 
   * @hide to prevent subclassing from outside of the framework
   */
  AndroidServiceManager(Context context,IAndroidServiceManager service){
        mContext = context;
        mService = service;
  }
  public void printAndroid(){
    try{
        mService.printAndroid();
    }catch (RemoteException ex){
    }   
  }  }
