using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json.Linq;

namespace MultiApp.Pages
{
    public class IndexModel : PageModel
    {
        public async Task OnGet()
        {
            using (var client = new System.Net.Http.HttpClient())
            {
                var request = new System.Net.Http.HttpRequestMessage();
                //request.RequestUri = new Uri("http://localhost:5024/api/Joke");
                request.RequestUri = new Uri("http://multiapi:8080/api/Joke");
                var response = await client.SendAsync(request);
                var joke = await response.Content.ReadAsStringAsync();

                var details = JObject.Parse(joke);
                ViewData["Joke"] = details["name"] + ";;" + details["text"] + ";;" + details["category"];
            }
        }
    }
}
